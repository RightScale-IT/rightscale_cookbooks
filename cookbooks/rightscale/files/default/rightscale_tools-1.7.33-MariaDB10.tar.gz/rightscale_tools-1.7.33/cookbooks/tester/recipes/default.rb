#
# Cookbook Name:: tester
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.
#
# Do Not Redistribute
#

rightscale_marker

# On CentOS 6.3 image uninstall ruby 1.9 version and install ruby 1.8
# On Ubuntu 12.04 image install ruby 1.8 and use update-alternatives
# to choose ruby 1.8
if node[:platform] =~ /centos|redhat/
  ruby_packages = ["ruby", "ruby-libs"]
  ruby_packages.each do |p|
    package p do
      action :remove
    end
  end

  # Install ruby 1.8 using bash block instead of package resource because
  # we can use wildcard to install the latest ruby 1.8 patch level.
  # Package resource requires ruby version to be hardcoded which won't
  # scale very well.
  bash "install ruby 1.8" do
    code <<-EOH
      yum install ruby-1.8.* --assumeyes
    EOH
  end

  ruby_packages = ["rubygems", "ruby-devel"]
  ruby_packages.each do |p|
    package p
  end

elsif node[:platform] =~ /ubuntu/
  ruby_packages = ["ruby1.8", "rubygems", "ruby-dev"]
  ruby_packages.each do |p|
    package p
  end

  bash "use ruby 1.8 version" do
    code <<-EOH
      update-alternatives --set ruby "/usr/bin/ruby1.8"
      update-alternatives --set gem "/usr/bin/gem1.8"
    EOH
  end
end

node[:tester][:ruby][:bin] = ::File.join(node[:tester][:ruby][:prefix], "bin")
node[:tester][:ruby][:gem] = ::File.join(node[:tester][:ruby][:bin], "gem")
node[:tester][:ruby][:ruby] = ::File.join(node[:tester][:ruby][:bin], "ruby")

# Populate gem environment
gemenv = Chef::ShellOut.new("#{node[:tester][:ruby][:gem]} env")
gemenv.run_command
gemenv.error!

node[:tester][:gem][:bin] = gemenv.stdout.match(/EXECUTABLE DIRECTORY: (.*)$/)[1]
node[:tester][:ruby][:bundle] = ::File.join(node[:tester][:gem][:bin], "bundle")
node[:tester][:ruby][:rake] = ::File.join(node[:tester][:gem][:bin], "rake")

gem_package "bundler" do
  gem_binary node[:tester][:ruby][:gem]
end

# Install lvm
package "lvm2"

package value_for_platform({
  ["centos", "redhat"] => {"default" => "mysql-devel"},
  "ubuntu" => {"default" => "libmysqlclient-dev"},
})
package value_for_platform({
  ["centos", "redhat"] => {"default" => "postgresql-devel"},
  "ubuntu" => {"default" => "libpq-dev"},
})

package value_for_platform({
  ["centos", "redhat"] => {"default" => "ruby-devel"},
  "ubuntu" => {"default" => "ruby-dev"},
})
