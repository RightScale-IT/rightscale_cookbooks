maintainer       "RightScale, Inc."
maintainer_email "white.sprint@rightscale.com"
license          "All rights reserved"
description      "Sets up and runs unit and functional tests for the RightScale Tools."
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.3.8"

depends "rightscale"
depends "repo"

recipe "tester::default", "Default recipe to setup provided resources."
recipe "tester::do_update", "Update RightScale Tools code."
recipe "tester::do_unit_tests", "Run unit tests."
recipe "tester::do_functional_tests", "Run function tests."
recipe "tester::do_block_device_api_tests", "Run function tests on block device to test our API."

attribute "tester/func/cloud_override",
  :display_name => "Cloud Override",
  :description => "Overrides the cloud type that is passed into the RightScale Tools.",
  :choice => ["ec2_gateway"],
  :required => "optional",
  :recipes => ["tester::do_block_device_api_tests"]

grouping "tester/func/cloud_capability",
  :title => "Cloud Capability Options.",
  :description => "Cloud capability options for block device."

attribute "tester/func/cloud_capability/volume",
  :display_name => "Volume Support",
  :description => "If cloud supports volume, set this option to 'true'.",
  :choice => [ "true", "false" ],
  :required => "required",
  :recipes => [ "tester::do_block_device_api_tests" ]

attribute "tester/func/cloud_capability/snapshot",
  :display_name => "Snapshot Support",
  :description => "If cloud supports snapshots, set this option to 'true'.",
  :choice => [ "true", "false" ],
  :required => "required",
  :recipes => [ "tester::do_block_device_api_tests" ]

grouping "tester/func/ros",
  :title => "ROS Options",
  :description => "Options for the Remote Object Store tests."

storage_clouds = [
  ['s3', 'S3'],
  ['cloudfiles', 'Cloud Files'],
  ['cloudfilesuk', 'Cloud Files UK'],
  ['swift', 'Swift'],
  ['softlayer_dallas', 'SoftLayer Dallas'],
  ['softlayer_amsterdam', 'SoftLayer Amsterdam'],
  ['softlayer_singapore', 'SoftLayer Singapore'],
  ['google', 'Google'],
  ['azure', 'Azure'],
]

storage_clouds.each do |storage_cloud, storage_cloud_name|
  grouping "tester/func/ros/#{storage_cloud}",
    :title => "#{storage_cloud_name} ROS Options",
    :description => "Options for the #{storage_cloud_name} Remote Object Store tests."

  attribute "tester/func/ros/#{storage_cloud}/enabled",
    :display_name => "#{storage_cloud_name} ROS Enabled",
    :description => "Enable running the #{storage_cloud_name} test.",
    :choice => ["true", "false"],
    :default => "true",
    :required => "recommended",
    :recipes => ["tester::do_functional_tests"]

  attribute "tester/func/ros/#{storage_cloud}/key",
    :display_name => "#{storage_cloud_name} ROS Key",
    :description => "Access key for #{storage_cloud_name}.",
    :required => "required",
    :recipes => ["tester::do_functional_tests"]

  attribute "tester/func/ros/#{storage_cloud}/secret",
    :display_name => "#{storage_cloud_name} ROS Secret",
    :description => "Access key for #{storage_cloud_name}.",
    :required => "required",
    :recipes => ["tester::do_functional_tests"]

  case storage_cloud
  when /^cloudfiles/
    attribute "tester/func/ros/#{storage_cloud}/use_snet",
      :display_name => "#{storage_cloud_name} Use Service Net",
      :description => "Use Storage Net for #{storage_cloud_name} test.",
      :choice => ["true", "false"],
      :default => "false",
      :required => "recommended",
      :recipes => ["tester::do_functional_tests"]
  when "swift"
    attribute "tester/func/ros/#{storage_cloud}/endpoint",
      :display_name => "#{storage_cloud_name} Endpoint",
      :description => "Endpoint URL for #{storage_cloud_name}.",
      :required => "required",
      :recipes => ["tester::do_functional_tests"]
  end
end
