#
# Cookbook Name:: tester
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.
#
# Do Not Redistribute
#

rightscale_marker

node[:tester][:func][:env] = ""
node[:tester][:func][:ros].each do |storage_cloud, values|
  values.each do |key, value|
    node[:tester][:func][:env] << "export #{storage_cloud.upcase}_#{key.upcase}=#{value.inspect}\n"
  end
end

bash "run functional tests" do
  flags "-e"
  code <<-EOS
    #{node[:tester][:func][:env].chomp}
    set -x
    cd "#{node[:repo][:default][:destination]}"
    #{node[:tester][:ruby][:bundle]} exec #{node[:tester][:ruby][:rake]} functional_tests
  EOS
  environment("PATH" => "#{ENV["PATH"]}:#{node[:tester][:gem][:bin]}")
end
