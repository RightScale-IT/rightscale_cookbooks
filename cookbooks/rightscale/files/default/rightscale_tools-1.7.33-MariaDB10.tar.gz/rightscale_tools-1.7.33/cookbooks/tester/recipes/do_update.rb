#
# Cookbook Name:: tester
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.
#
# Do Not Redistribute
#

rightscale_marker

repo "default" do
  destination node[:repo][:default][:destination]
  action :pull
end

bash "bundle install" do
  flags "-ex"
  code <<-EOS
    cd "#{node[:repo][:default][:destination]}"
    #{node[:tester][:ruby][:gem]} install deps/*.gem --no-ri --no-rdoc --no-update-sources
    #{node[:tester][:ruby][:bundle]} install --no-color
  EOS
end
