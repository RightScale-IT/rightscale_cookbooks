#
# Cookbook Name:: tester
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.
#
# Do Not Redistribute
#

rightscale_marker

node[:tester][:func][:env] = ""
node[:tester][:func][:cloud_capability].each do |capability, value|
  node[:tester][:func][:env] << "export API_TESTER_#{capability.upcase}=#{value}\n"
end

if node[:tester][:func][:cloud_override]
  node[:tester][:func][:env] << "export API_TESTER_CLOUD=#{node[:tester][:func][:cloud_override]}\n"
end

bash "run functional tests" do
  flags "-ex"
  code <<-EOS
    #{node[:tester][:func][:env].chomp}
    cd "#{node[:repo][:default][:destination]}"
    #{node[:tester][:ruby][:bundle]} exec #{node[:tester][:ruby][:rake]} block_device_tests
  EOS
  environment("PATH" => "#{ENV["PATH"]}:#{node[:tester][:gem][:bin]}")
end
