Description
===========

This cookbook contains recipes for running the unit and functional tests for the
RightScale tools.

Requirements
============

Requires a virtual machine launched from a RightScale managed RightImage.

Attributes
==========

Please see the `metadata.rb` file for the cookbook attributes.

Usage
=====

The `tester::default` recipe installs the main prerequisites for the RightScale
Tools including Bundler and the development libraries for MySQL and PostgreSQL.

The `tester::do_update` recipe pulls the RightScale Tools code from GitHub based
on the branch specified in the metadata attributes for the `repo` cookbook and
uses Bundler to install the rest of the prerequisites.

The `tester::do_unit_tests` recipe runs the unit tests for the RightScale Tools.

The `tester::do_functional_tests` recipe runs the functional tests for the
RightScale Tools; the functional tests that are run depend on the metadata
attributes and the cloud that the server is running on.

The `tester::do_block_device_api_tests` recipe runs the block device functional
tests to test RightScale API; the functional tests that are run depend on the
metadata attributes and the cloud that the server is running on.

License
=======

Copyright RightScale, Inc. All rights reserved.
All access and use subject to the RightScale Terms of Service available at
http://www.rightscale.com/terms.php and, if applicable, other agreements
such as a RightScale Master Subscription Agreement.
