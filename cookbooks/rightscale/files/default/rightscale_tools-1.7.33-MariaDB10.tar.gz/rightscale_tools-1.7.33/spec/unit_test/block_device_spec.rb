#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', '..', 'lib', 'rightscale_tools'))

require 'spec/spec_helper'
require 'fileutils'
require 'block_device'

# == Unit tests for the RightScale::Tools::BlockDevice object code
#
# There was nothing here, so at least init each type of subobject for a smoke test
#
describe RightScale::Tools::BlockDevice do
  before(:each) do
    @options = {}
    @options[:hypervisor] = "xen"
    
    @options[:primary_storage_cloud] = "s3"
    @options[:primary_storage_key] = "somekey"
    @options[:primary_storage_secret] = "supersecret"
    @options[:primary_storage_container] = "foo"
    
    @options[:secondary_storage_cloud] = "s3"
    @options[:secondary_storage_key] = "somekey"
    @options[:secondary_storage_secret] = "supersecret"
    @options[:secondary_storage_container] = "foo"
  end

  registry = RightScale::Tools::BlockDevice.send(:class_variable_get, :@@implementations)
  registry.each do |(type, cloud), clazz| # the key is a tuple

    it "factory create '#{type}' block_device on '#{cloud}' cloud" do
      api_mock = flexmock(RightScale::Tools::API)
      api_mock.should_receive(:factory).and_return(api_mock)

      platform_mock = flexmock(RightScale::Tools::Platform)
      platform_impl_mock = flexmock('platform')
      platform_impl_mock.should_receive(:get_lock_file_name)
      platform_impl_mock.should_receive(:get_device_for_mount_point)
      platform_mock.should_receive(:factory).and_return(platform_impl_mock)

      block_device = ::RightScale::Tools::BlockDevice.factory(type, cloud, "/mnt/somewherez", "nickname", "1234", @options)
      block_device.should be_an_instance_of(clazz)
    end

  end

end
