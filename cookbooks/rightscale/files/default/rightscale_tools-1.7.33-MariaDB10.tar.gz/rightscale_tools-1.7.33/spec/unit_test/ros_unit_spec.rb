#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'spec/spec_helper'
require 'rightscale_tools/ros'
require 'fileutils'
require 'tempfile'
require 'tmpdir'

storage_clouds = Hash[RightScale::Tools::ROS.send(
  :class_variable_get, "@@implementations"
).reject do |storage_cloud, clazz|
  case storage_cloud
  when :ec2, :rackspace, :rackspaceuk, :"rackspace-ng", :softlayer, :gc,
    :openstack, :cloudfiles, :cloudfilesuk
    # these are just aliases for other Storage Clouds
    true
  when :fog, :local
    # skip these for now
    true
  end
end.map {|storage_cloud, clazz| [storage_cloud.to_s, clazz]}]

describe RightScale::Tools::ROS do
  before :all do
    @key = 'XXXXXXXXXXXXXXXXXXXXX:XXXXXX'
    @secret = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
    @options = {:endpoint => "https://endpoint.example.com/"}
    @dir = Dir.mktmpdir ['ros_', '_unit']
    storage_clouds.each_key {|storage_cloud| Dir.mkdir(File.join(@dir, storage_cloud))}

    # fake Process::Status
    @status = Class.new do
      attr_reader :pid, :exitstatus

      def initialize(pid, exitstatus)
        @pid = pid
        @exitstatus = exitstatus
      end

      def self.wait2_0(pid)
        [pid, self.new(pid, 0)]
      end

      def self.wait2_1(pid)
        [pid, self.new(pid, 1)]
      end
    end

    # Turn on Fog mocking
    Fog.mock!
  end

  after :all do
    FileUtils.remove_entry_secure @dir
  end

  before :each do
    @s3 = flexmock(RightAws::S3Interface)

    @cloud_files = flexmock(Rightscale::Rackspace::CloudFilesInterface)

    @google = Fog::Storage.new(
      :provider => 'Google',
      :google_storage_access_key_id => @key,
      :google_storage_secret_access_key => @secret
    )

    @swift = Fog::Storage.new(
      :provider => 'HP',
      :hp_tenant_id => @key.split(':')[0],
      :hp_account_id => @key.split(':')[1],
      :hp_secret_key => @secret,
      :hp_auth_uri => @options[:endpoint]
    )

    @azure = flexmock(RightScale::CloudApi::Azure::Storage::Manager)
  end

  it 'returns the right object' do
    storage_clouds.each do |storage_cloud, clazz|
      RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options).should be_instance_of(clazz)
    end
  end

  storage_clouds.each do |storage_cloud, clazz|
    it "has methods on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:create_bucket)
          mock.should_receive(:list_all_my_buckets).and_return([])
          mock.should_receive(:get)
          mock.should_receive(:incrementally_list_bucket)
          mock.should_receive(:put)
          mock.should_receive(:delete)
        end
      when 'cloud_files', 'cloud_files_uk', /^softlayer/
        @cloud_files.new_instances do |mock|
          mock.should_receive(:create_container)
          mock.should_receive(:incrementally_list_containers)
          mock.should_receive(:get_object)
          mock.should_receive(:get_object_link)
          mock.should_receive(:put_object)
          mock.should_receive(:incrementally_list_objects)
          mock.should_receive(:put_object_link)
          mock.should_receive(:delete_object)
        end
      when 'azure'
        @azure.new_instances do |mock|
          mock.should_receive(:CreateContainer)
          mock.should_receive(:ListContainers).and_return({
            'EnumerationResults' => {
              'Containers' => { 'Container' => [] }
            }
          })
          mock.should_receive(:GetBlob)
          mock.should_receive(:GetBlob)
          mock.should_receive(:ListBlobs)
          mock.should_receive(:PutBlob)
          mock.should_receive(:DeleteBlob)
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      Tempfile.open(['bogus', 'txt'], File.join(@dir, storage_cloud)) do |local_file|
        lambda {
          ros.create_container('bogus')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.create_container_if_not_exists('bogus')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.get_object('bogus', 'bogus.txt')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.get_object_to_file('bogus', 'bogus.txt', local_file.path)
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.get_object_link('bogus', 'bogus.txt')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.get_latest_object_name('bogus', 'bogus_frag.txt')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.put_object('bogus', 'bogus.txt', "Bogus!\n")
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.put_object_from_file('bogus', 'bogus.txt', local_file.path)
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.put_object_link('bogus', 'bogus.txt')
        }.should_not raise_exception(NotImplementedError)
        # The list_object_names doesn't work with Fog Mocking and leads to an
        # infinite loop when iterating through the files. Since we are not
        # going to upgrade fog in v13.x this test is skipped in swift-based
        # ROS providers.
        #
        unless storage_cloud == 'swift' || storage_cloud == 'hp'
          lambda {
            ros.list_object_names('bogus')
          }.should_not raise_exception(NotImplementedError)
        end
        lambda {
          ros.delete_object('bogus', 'bogus.txt')
        }.should_not raise_exception(NotImplementedError)
        lambda {
          ros.delete_stale_object_fragments('bogus', 'bogus_frag.txt', 1)
        }.should_not raise_exception(NotImplementedError)
      end
    end

    it "should create and delete containers on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:create_bucket).with('one', Hash).once
          mock.should_receive(:list_all_my_buckets).and_return([{:name => 'one'}])
          mock.should_receive(:create_bucket).with('two', Hash)
          mock.should_receive(:delete_bucket).with('two')
        end
      when 'cloud_files', 'cloud_files_uk', /^softlayer/
        @cloud_files.new_instances do |mock|
          mock.should_receive(:create_container).with('one', Hash).once
          mock.should_receive(:incrementally_list_containers).and_yield([{'name' => 'one'}])
          mock.should_receive(:create_container).with('two', Hash)
          mock.should_receive(:delete_container).with('two')
        end
      when 'azure'
        @azure.new_instances do |mock|
          mock.should_receive(:CreateContainer).with({:Container => 'one'}).once
          mock.should_receive(:ListContainers).with(Hash).and_return({
            'EnumerationResults' => {
              'Containers' => {'Container' => {'Name' => 'one'}}
            }
          })
          mock.should_receive(:CreateContainer).with({:Container => 'two'})
          mock.should_receive(:DeleteContainer).with({:Container => 'two'})
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      ros.create_container('one')
      ros.create_container_if_not_exists('one').should == false
      ros.create_container_if_not_exists('two').should == true
      ros.delete_container('two')
    end

    # The following tests still need to be fixed up to work correctly.
=begin
    it "should get and delete objects on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:get).with('one', 'one.txt').and_return({:object => "1\n"})
          mock.should_receive(:get).with('one', 'one.txt', Proc).and_yield("1\n")
          mock.should_receive(:delete).with('one', 'one.txt')
        end
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          mock.should_receive(:get_object).with('one', 'one.txt').and_return("1\n")
          mock.should_receive(:get_object).with('one', 'one.txt', Proc).and_yield("1\n")
          mock.should_receive(:get_object_link).with('one', 'one.txt').and_return({:url => 'https://storage101.dfw1.clouddrive.com:443/v1/MossoCloudFS_67d2b630-0954-4368-92ea-f62f31e98f0c/one/one.txt'})
          mock.should_receive(:delete_object).with('one', 'one.txt')
        end
      when 'google'
        @google.directories.create(:key => 'one')
        @google.directories.get('one').files.create(:key => 'one.txt', :body => "1\n")
      when 'azure'
        @azure.new_instances do |mock|
          mock.should_receive(:GetBlob).with({:Container => 'one', :Blob => 'one.txt'}).and_return("1\n")
          mock.should_receive(:GetBlob).with(FlexMock.on do |options|
            FlexMock.hsh(:Container => 'one', :Blob => 'one.txt') === options && options.has_key?(:options) && options[:options].has_key?(:after_routine_callback)
          end).and_return do |options|
            options[:options][:after_routine_callback].call({
              :routine => RightScale::CloudApi::RequestAnalyzer.new,
              :manager => mock,
            })
          end
          mock.should_receive(:data).with.and_return({
            :connection => {
              :uri => 'safdsfd',
            },
            :request => {
              :instance => 'safdfsds'
            }
          })
          mock.should_receive(:DeleteBlob).with({:Container => 'one', :Blob => 'one.txt'})
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      ros.get_object('one', 'one.txt').should == "1\n"
      data = StringIO.new
      ros.get_object('one', 'one.txt', data)
      data.string.should == "1\n"
      data.string = ''
      ros.get_object('one', 'one.txt') {|chunk| data << chunk}
      data.string.should == "1\n"
      file = File.join(@dir, storage_cloud, 'one.txt')
      ros.get_object_to_file('one', 'one.txt', file)
      IO.read(file).should == "1\n"
      ros.get_object_link('one', 'one.txt').should have_key(:url)
      ros.delete_object('one', 'one.txt')
    end

    it "should list objects and get latest name on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:incrementally_list_bucket).with('two', Hash, Proc).and_yield({:contents => (1..5).map {|x| {:key => "two#{x}.txt"}}}).and_return(true)
        end
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          mock.should_receive(:incrementally_list_objects).with('two', Proc).and_yield((1..5).map {|x| {'name' => "two#{x}.txt"}})
        end
      when 'google'
        @google.directories.create(:key => 'two')
        (1..5).each do |x|
          @google.directories.get('two').files.create(:key => "two#{x}.txt")
        end
      when 'azure'
        @azure.new_instances do |mock|
          mock.should_receive(:ListBlobs).with(FlexMock.hsh(:Container => 'two')).and_return({
            'EnumerationResults' => {
              'Blobs' => {
                'Blob' => (1..5).map {|x| {'Name' => "two#{x}.txt"}}
              }
            }
          })
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      ros.list_object_names('two').should == (1..5).map {|x| "two#{x}.txt"}
      x = 0
      ros.list_object_names('two') {|object| object.should == "two#{x += 1}.txt"}
      ros.get_latest_object_name('two', 'two').should == 'two5.txt'
    end

    it "should put objects on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:put).with('three', 'three1.txt', "3\n").once.and_return(true)
          mock.should_receive(:put).with('three', 'three2.txt', File).once.and_return(true)
        end
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          mock.should_receive(:put_object).with('three', 'three1.txt', "3\n").once.and_return(true)
          mock.should_receive(:put_object).with('three', 'three2.txt', "3\n").once.and_return(true)
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      ros.put_object('three', 'three1.txt', "3\n").should == true
      local_file = open(File.join(@dir, storage_cloud, 'three2.txt'), 'w') {|file| file << "3\n"}
      ros.put_object_from_file('three', 'three2.txt', local_file.path)
    end

    it "should delete stale object fragments on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:incrementally_list_bucket).with('four', Hash, Proc).and_yield({:contents => (0..5).map {|x| {:key => "four.txt.part#{'%05d' % x}"}}}).and_return(true)
          0.upto 2 do |x|
            mock.should_receive(:delete).with('four', "four.txt.part#{'%05d' % x}").never.and_return(true)
          end
          3.upto 5 do |x|
            mock.should_receive(:delete).with('four', "four.txt.part#{'%05d' % x}").once.and_return(true)
          end
        end
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          mock.should_receive(:incrementally_list_objects).with('four', Proc).and_yield((0..5).map {|x| {'name' => "four.txt.part#{'%05d' % x}"}})
          0.upto 2 do |x|
            mock.should_receive(:delete_object).with('four', "four.txt.part#{'%05d' % x}").never.and_return(true)
          end
          3.upto 5 do |x|
            mock.should_receive(:delete_object).with('four', "four.txt.part#{'%05d' % x}").once.and_return(true)
          end
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      ros.delete_stale_object_fragments('four', 'four.txt', 3)
    end

    it "should get fragmented objects on #{storage_cloud}" do
      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:get).with('five', 'five.bin.info').and_return({:object => (0..10).map {|x| "five.bin.part#{'%05d' % x}"}.join("\n") + "\n"})
        end
        clazz = RightScale::Tools::ROS::S3
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          mock.should_receive(:get_object).with('five', 'five.bin.info').and_return((0..10).map {|x| "five.bin.part#{'%05d' % x}"}.join("\n") + "\n")
          0.upto 10 do |x|
            mock.should_receive(:get_object_link).with('five', "five.bin.part#{'%05d' % x}").and_return({:url => "https://storage101.dfw1.clouddrive.com:443/v1/MossoCloudFS_67d2b630-0954-4368-92ea-f62f31e98f0c/five/five.bin.part#{'%05d' % x}"})
          end
        end
        clazz = RightScale::Tools::ROS::CloudFiles
      end

      # make a sparse 10 MB file to use for fragments 0-9 and a 1 B file to use for fragment 10
      fragments_0_9 = File.join(@dir, storage_cloud, 'five.bin.part0-9')
      system "dd if=/dev/zero of=#{fragments_0_9} bs=1024 count=#{10 * 1024}"
      fragment_10 = File.join(@dir, storage_cloud, 'five.bin.part10')
      open(fragment_10, 'w') {|file| file << "\0"}

      flexmock(RightScale::Tools) do |mock|
        0.upto 10 do |x|
          mock.should_receive(:popen4_and_wait).with(/five\.bin\.part#{'%05d' % x}/, Proc).once.and_yield().and_return(@status.new(66600 + x, 0))
        end
      end

      # mock stdout and stderr on this so the popen4_and_wait mock above will have them when it yields
      flexmock(clazz).new_instances do |mock|
        mock.should_receive(:stdout).with(Proc).times(10).and_yield(IO.read(fragments_0_9))
        mock.should_receive(:stdout).with(Proc).times(1).and_yield(IO.read(fragment_10))
        mock.should_receive(:stderr).with(Proc).times(11)
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      local_filename = File.join(@dir, storage_cloud, 'five.bin')
      ros.get_object_to_file('five', 'five.bin', local_filename, true)
      File.size(local_filename).should == (100 * 1024 * 1024 + 1) # 100 MB and 1 byte
    end

    it "should put fragmented objects on #{storage_cloud}" do
      fragments = (0..10).map {|x| "six.bin.part#{'%05d' % x}"}

      case storage_cloud
      when 's3'
        @s3.new_instances do |mock|
          mock.should_receive(:incrementally_list_bucket).with('six', FlexMock.hsh(:prefix => 'six.bin.part'), Proc).and_yield({:contents => []}).and_return(true)
          mock.should_receive(:put).with('six', 'six.bin.info', fragments.join("\n") + "\n").once.and_return(true)
        end
        clazz = RightScale::Tools::ROS::S3
      when 'cloudfiles', 'cloudfilesuk', /^softlayer/, 'swift'
        @cloudfiles.new_instances do |mock|
          fragments.each do |fragment|
            mock.should_receive(:put_object_link).with('six', fragment).once.and_return({:url => "https://storage101.dfw1.clouddrive.com:443/v1/MossoCloudFS_67d2b630-0954-4368-92ea-f62f31e98f0c/six/#{fragment}"})
          end
          mock.should_receive(:incrementally_list_objects).with('six', Proc).and_yield([])
          mock.should_receive(:put_object).with('six', 'six.bin.info', fragments.join("\n") + "\n").once.and_return(true)
        end
        clazz = RightScale::Tools::ROS::CloudFiles
      end

      flexmock(Process) do |mock|
        mock.should_receive(:fork).times(11).and_yield.and_return(99900, 99901, 99902, 99903, 99904, 99905, 99906, 99907, 99908, 99909, 99910)
        mock.should_receive(:exit!).with(0).times(11)
        mock.should_receive(:exit!).with.never
        mock.should_receive(:wait2).with.times(3).and_return(@status.wait2_1(77700), @status.wait2_0(99900), @status.wait2_0(99901))
        99902.upto 99910 do |pid|
          mock.should_receive(:wait2).with(pid).once.and_return(@status.wait2_0(pid))
        end
      end

      flexmock(RightScale::Tools) do |mock|
        fragments_0_9 = FlexMock.on do |options|
          stdin = options[:stdin]
          return false unless stdin
          stdin.size == 10 * 1024 * 1024 # 10 MB each
        end

        fragment_10 = FlexMock.on do |options|
          stdin = options[:stdin]
          return false unless stdin
          stdin.size == 1 # 1 byte
        end

        fragments.each_with_index do |fragment, x|
          mock.should_receive(:popen4_and_wait).with(/#{Regexp.escape(fragment)}/, x != 10 ? fragments_0_9 : fragment_10, Proc).once.and_return(@status.new(88800 + x, 0))
        end
      end

      ros = RightScale::Tools::ROS.factory(storage_cloud, @key, @secret, @options)
      local_filename = File.join(@dir, storage_cloud, 'six.bin')
      system "dd if=/dev/zero of=#{local_filename} bs=1024 count=#{100 * 1024}"
      open(local_filename, 'a') {|file| file << "\0"}
      ros.put_object_from_file('six', 'six.bin', local_filename, true)
    end
=end
  end
end
