#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'spec/spec_helper'
require 'fileutils'

# == Include database object hierarchy files
dirs = [
  File.join(File.dirname(__FILE__), '..', '..', 'lib', 'rightscale_tools', 'database', '**', '*.rb'),
  File.join(File.dirname(__FILE__), '..', '..', 'lib', 'rightscale_tools', 'premium', 'db', 'common', '**', '*.rb')
].each do |d|
  Dir[d].each {|f| require f }
end

# == Unit tests for the RightScale::Tools::Database object code
#
# These test the logic and methods contained in the object hierarchy
# it is not intended to test interation with a real system.
#
# Use a funtional test for that once all these test pass.
#
describe RightScale::Tools::Database do
  before(:each) do
    @user = "root"
    @passwd = ""
    @data_dir = "/mnt/foo"
    @log = Logger.new(STDOUT)

    # Mock creation of premium dbutil object -- since it is platform
    # dependent and requires mysql to be installed and running
    flexmock(RightScale::DBUtilsMysql).should_receive(:new).and_return(true)
  end

  it "can create a MySQL database object from the factory method" do
    @db = RightScale::Tools::Database.factory(:mysql, @user, @passwd, @data_dir, @log)
    @db.class.should == RightScale::Tools::DatabaseMysql
  end

  it "should parse rs_tag output and find master database info" do
    @db = RightScale::Tools::Database.factory(:mysql, @user, @passwd, @data_dir, @log)
    rs_tag_data = '{
      "rs-instance-6f8f3045f30b936597fa5bdb35842db6649de782-5162819": {
        "tags": [
          "database:active=true",
          "rs_agent_dev:download_cookbooks_once=true",
          "rs_dbrepl:master_active=20110926220906",
          "rs_dbrepl:master_instance_uuid=00-06EB2QF",
          "rs_logging:state=active",
          "rs_login:state=active",
          "rs_monitoring:state=active",
          "server:private_ip_0=10.242.219.192",
          "server:public_ip_0=184.72.134.67",
          "server:uuid=00-06EB2QF"
        ]
      },
      "rs-instance-04afaf943b32770becfccff9ff052e14f9730f73-5162954": {
        "tags": [
          "database:active=true",
          "rs_agent_dev:download_cookbooks_once=true",
          "rs_logging:state=active",
          "rs_login:state=active",
          "rs_monitoring:state=active",
          "server:private_ip_0=10.85.151.170",
          "server:public_ip_0=174.129.126.182",
          "server:uuid=00-0JTT7B1"
        ]
      },
      "rs-instance-7c595f6271f210fd3313741902bbb03f3014990d-5162821": {
        "tags": [
          "database:active=true",
          "rs_agent_dev:download_cookbooks_once=true",
          "rs_logging:state=active",
          "rs_login:state=active",
          "rs_monitoring:state=active",
          "server:private_ip_0=10.205.5.130",
          "server:public_ip_0=107.20.118.250",
          "server:uuid=00-25D97NC"
        ]
      }
    }'
    tag_hash = JSON.parse(rs_tag_data)
    is_master, uuid, ip = @db.master_info_from_tags(tag_hash, "00-06EB2QF", true)
    is_master.should == true
    uuid.should == "00-06EB2QF"
    ip.should == "10.242.219.192"
  end

  it "should parse server_collection output and find master database info" do
    @db = RightScale::Tools::Database.factory(:mysql, @user, @passwd, @data_dir, @log)
    server_collection = {"rs-instance-6c40c27e51944c1a8a8530c6aa8c3c3ba62c4f2d-5169536"=>["database:active=true",       "rs_agent_dev:download_cookbooks_once=true", "rs_dbrepl:master_active=20110927160039", "rs_dbrepl:master_instance_uuid=00-30LLU0E", "rs_login:state=active", "rs_monitoring:state=active", "server:private_ip_0=10.181.3.192", "server:public_ip_0=184.106.105.199", "server:uuid=00-30LLU0E"]}
    is_master, uuid, ip = @db.master_info_from_tags(server_collection, "foo")
    is_master.should == false
    uuid.should == "00-30LLU0E"
    ip.should == "10.181.3.192"
  end

end
