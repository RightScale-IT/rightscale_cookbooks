#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.
#
# Test various levels of block_device support


require File.expand_path(File.join(File.dirname(__FILE__), "..", "..", "spec", "spec_helper"))
require 'fileutils'
require "mixlib/shellout"

module RightScale
  module Tools
    module Test
      class Hypervisor
        def initialize(hypervisor)
          @hypervisor = hypervisor
        end

        def init_options
          {
            :hypervisor => @hypervisor,
            :secondary_storage_cloud => "s3",
            :secondary_storage_key => ENV['S3_KEY'],
            :secondary_storage_secret => ENV['S3_SECRET'],
            :secondary_storage_container =>"test-rstools-#{Time.now.to_i}"
          }
        end

        def create_options
          {
            :volume_size => 1,
            :stripe_count => 2,
            :vg_data_percentage => 90
          }
        end
      end

      # Generic block device testing object
      class BlockDevice
        attr_reader :cloud, :create_options, :block_device

        def initialize(mount_point, nickname)
          @mount_point = mount_point
          @nickname = nickname
          @cloud = ENV['API_TESTER_CLOUD'] || IO.read('/etc/rightscale.d/cloud').chomp
          @host = Hypervisor.new(query_for_hypervisor)
          @options = @host.init_options
          @options[:disable_backup_options] = true if ENV['API_TESTER_SNAPSHOT'] == "false"
          @block_device = RightScale::Tools::BlockDevice.factory(
            :lvm,
            @cloud,
            @mount_point,
            @nickname,
            '12345',
            @options
          )
        end

        def create_options
          options = @host.create_options
          if @cloud == "rackspace-ng"
            options[:volume_size] = 200
            options[:volume_type] = "SATA"
          end
          options
        end

        def primary_backup_options
          {
            :max_snapshots => 1,
            :keep_daily => 1,
            :keep_weekly => 1,
            :keep_monthly => 1,
            :keep_yearly => 1
          }
        end

        def primary_restore_options
          options = {
            :timestamp => nil
          }
          options[:volume_type] = create_options[:volume_type] if @cloud == "rackspace-ng"
          options
        end

        protected

        def query_for_hypervisor
          cmd = Mixlib::ShellOut.new(
            "/opt/rightscale/sandbox/bin/ohai --log_level error virtualization 2>/dev/null"
          )
          cmd.run_command
          virtualization = Hash[JSON.load cmd.stdout]

          # In Chef 0.9, hypervisor is obtained from 'virtualization/emulator'
          # In Chef 0.10 and higher, hypervisor is obtained from
          # 'virtualization/system'
          @hypervisor = virtualization['system'] || virtualization['emulator']
          @hypervisor
        end
      end
    end
  end
end

def create_test_file(testfile)
  puts "  Generating new testfile..."
  raise "#{testfile} not created" unless system("dd if=/dev/urandom of=#{testfile} bs=16M count=8")
  puts "  Calculate fingerprint of testfile..."
  r = `md5sum #{testfile}`
  r.split(" ").first
end

describe RightScale::Tools::BlockDevice do
  WAIT_TIME = 60

  support_options = {
    :volume => (ENV['API_TESTER_VOLUME_DISABLE'] ? false : true),
    :snapshot => (ENV['API_TESTER_SNAPSHOT_DISABLE'] ? false : true)
  }
  capability = RightScale::Tools::CloudCapability.new(support_options)

  before(:all) do
    @mount_point = "/mnt/storage0"
    @lineage = "test_rstools"
    @nickname = "test_rstools_deleteme"
    @test_obj = RightScale::Tools::Test::BlockDevice.new(
      @mount_point,
      @nickname
    )
  end

  before(:each) do
    # reset state to pristine
    # unmount, detach, delete any volumes
    @block_device = @test_obj.block_device
    @block_device.reset
  end

  if capability.support_volume?
    it "attach/detach", :api_tester => true do
      puts "============================================="
      puts "*****    Running attach/detach tests    *****"
      puts "============================================="
      puts "Creating volumes..."
      @block_device.create(@test_obj.create_options)

      # Waits for specified time before detach. This wait time is intended to
      # mimic real world use case instead of running attach and detach volumes
      # in quick succession.
      puts "Sleeping for #{WAIT_TIME} seconds..."
      sleep WAIT_TIME

      puts "Resetting block device..."
      @block_device.reset    # performs detach
    end

    if capability.support_snapshot?
      it "primary backup and restore", :api_tester => true do
        puts "================================================"
        puts "*** Running primary backup and restore tests ***"
        puts "================================================"
        testfile = "#{@mount_point}/testfile"

        puts "Creating volumes..."
        @block_device.create(@test_obj.create_options)
        md5_orig = create_test_file(testfile)
        puts "Taking snapshot..."
        @block_device.snapshot(:primary, @lineage, @test_obj.primary_backup_options)
        puts "Backing up snapshot..."
        @block_device.primary_backup(@lineage, @test_obj.primary_backup_options)
        puts "Resetting block device..."
        @block_device.reset
        puts @mount_point

        # Waits for specified time before detach. This wait time is intended to
        # mimic real world use case instead of running backup and restore in
        # quick succession.
        puts "Sleeping for #{WAIT_TIME} seconds..."
        sleep WAIT_TIME

        puts "Restoring block device..."
        @block_device.primary_restore(@lineage, @test_obj.primary_restore_options)

        puts "  Verify the fingerprint of testfile..."
        r = `md5sum #{testfile}`
        md5_snap = r.split(" ").first
        raise "Signatures don't match. Orig:#{md5_orig}, From Snapshot:#{md5_snap}" unless md5_orig == md5_snap
      end
    end
  end

  it "secondary backup and restore", :api_tester => false do

    options = {
      :max_snapshots => 1,
      :keep_dailies => 1,
      :keep_weeklies => 1,
      :keep_monthlies => 1,
      :keep_yearlies => 1,
      :force => "true"
    }
    testfile = "#{@mount_point}/testfile"

    puts "Creating volumes..."
    @block_device.create(@test_obj.create_options)

    md5_orig = create_test_file(testfile)

    puts "Taking snapshot..."
    @block_device.snapshot(:secondary, @lineage)
    puts "Creating backup snapshot..."
    @block_device.secondary_backup(@lineage, options)
    puts "Resetting block device"
    @block_device.reset
    puts @mount_point
    puts "Restoring block device"
    @block_device.secondary_restore(@lineage, @test_obj.create_options)

    puts " Verify the fingerprint of testfile..."
    r = `md5sum #{testfile}`
    md5_snap = r.split(" ").first
    raise "Signatures don't match. Orig:#{md5_orig}, From Snapshot:#{md5_snap}" unless md5_orig == md5_snap
  end
end
