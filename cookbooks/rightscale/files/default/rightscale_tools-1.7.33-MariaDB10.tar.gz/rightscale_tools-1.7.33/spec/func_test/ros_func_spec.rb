#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'spec/spec_helper'
require 'rightscale_tools/ros'
require 'fileutils'
#require 'tempfile'
require 'tmpdir'

storage_clouds = ['s3', 'cloudfiles']

# TODO: align enviroment variables with those in the tester cookbook

describe RightScale::Tools::ROS do
  before :all do
    [
      'S3_KEY', 'S3_SECRET',
      'CLOUDFILES_KEY', 'CLOUDFILES_SECRET', 'CLOUDFILES_USE_SNET'
    ].each do |variable|
      value = ENV[variable]
      raise "#{variable} is not set!" unless value
    end

    @keys = {
      's3' => ENV['S3_KEY'],
      'cloudfiles' => ENV['CLOUDFILES_KEY']
    }
    @secrets = {
      's3' => ENV['S3_SECRET'],
      'cloudfiles' => ENV['CLOUDFILES_SECRET']
    }
    @options = {
      :cloud => IO.read('/etc/rightscale.d/cloud').chomp,
      :rackspace_use_snet => ENV['CLOUDFILES_USE_SNET']
    }
    @dir = Dir.mktmpdir ['ros_', '_func']
    storage_clouds.each {|storage_cloud| Dir.mkdir(File.join(@dir, storage_cloud))}

    @test_container = "test-rstools-#{Time.now.to_i}"
    @test_file = "README.txt"
    @test_data = "this container was for a test which didn't clean up after itself.  Please delete me!"
  end

  after :all do
    FileUtils.remove_entry_secure @dir
  end

  storage_clouds.each do |storage_cloud|

    context "on #{storage_cloud}" do

      let(:ros) do
        RightScale::Tools::ROS.factory(storage_cloud,
                                       @keys[storage_cloud],
                                       @secrets[storage_cloud],
                                       @options)
      end

      it "should create containers" do
        ros.create_container(@test_container)
      end

      it "should not create containers if already exists" do
        ros.create_container_if_not_exists(@test_container)
      end

      it "should put an object to a container" do
        ros.put_object(@test_container, @test_file, @test_data)
      end

      it "should get an object from a container" do
        obj = ros.get_object_to_file(@test_container, @test_file, File.join(@dir, "local_file.txt"))
        File.exists?(File.join(@dir, "local_file.txt")).should == true
      end

      it "should get latest object from a container" do
        obj = ros.get_latest_object_name(@test_container, @test_file)
        obj.should == @test_file
      end

      it "should delete object" do
        r = ros.delete_object(@test_container, @test_file)
        r.should == true
      end

      it "should delete container" do
        r = ros.delete_container(@test_container)
        r.should == true
      end

    end
  end

end
