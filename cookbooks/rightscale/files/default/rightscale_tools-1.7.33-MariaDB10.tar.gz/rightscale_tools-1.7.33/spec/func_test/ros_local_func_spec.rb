#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', '..', 'lib'))

require 'rightscale_tools/ros'
require 'fileutils'
require 'tmpdir'

storage_cloud = 'local'

describe RightScale::Tools::ROS::Local do

  before :all do
    @test_container = "test-rstools-#{Time.now.to_i}"
    @test_file = "README.txt"
    @test_data = "this container was for a test which didn't clean up after itself.  Please delete me!"

    @dir = Dir.mktmpdir("fog")
    @ros = RightScale::Tools::ROS.factory(storage_cloud, "you", "wish", {:local_root => @dir})
  end

  after :all do
    FileUtils.remove_entry_secure @dir
  end

  it "should create containers" do
    @ros.create_container(@test_container)
    File.directory?(File.join(@dir, @test_container)).should == true
  end

  it "should not create containers if already exists" do
    @ros.create_container_if_not_exists(@test_container)
  end

  it "should put an object to a container" do
    @ros.put_object(@test_container, @test_file, @test_data)
    File.exists?(File.join(@dir, @test_container, @test_file)).should == true
  end

  it "should get an object from a container" do
    obj = @ros.get_object_to_file(@test_container, @test_file, File.join(@dir, "local_file.txt"))
    File.exists?(File.join(@dir, "local_file.txt")).should == true
  end

  it "should get latest object from a container" do
    obj = @ros.get_latest_object_name(@test_container, @test_file)
    obj.should == @test_file
  end

  it "should delete object" do
    r = @ros.delete_object(@test_container, @test_file)
    r.should == true
  end

  it "should delete container" do
    r = @ros.delete_container(@test_container)
    r.should == true
  end

end
