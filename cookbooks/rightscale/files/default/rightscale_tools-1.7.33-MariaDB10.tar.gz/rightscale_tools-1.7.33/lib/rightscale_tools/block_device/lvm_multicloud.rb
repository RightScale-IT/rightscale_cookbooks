#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'set'
require 'timeout'

require 'rightscale_tools/block_device/lvm'

module RightScale
  module Tools
      module BlockDevice
      class LVMMultiCloud < LVM
        register :lvm, :cloudstack, :eucalyptus, :openstack, :azure,
          :"rackspace-ng", :ec2_gateway, :gc, :google

        include LVMAPIMixin

        def initialize(cloud, mount_point, nickname, uuid, options)
          super(cloud, mount_point, nickname, uuid, options)

          @api = RightScale::Tools::API.factory('1.5', options)
          @hypervisor = options[:hypervisor]

          # Use volume backup/restore unless it is not supported
          # "disable_backup_options" is used by API Tester to disable initializing backups when not required.
          unless options[:disable_backup_options]
            if !create_before_restore?(:primary)
              @backup[:primary] = RightScale::Tools::Backup.factory(:volume, @cloud, @mount_point, @snapshot_mount_point, unique_volume_nickname, options)
            else
              primary_options = options.merge({
                :endpoint => options[:primary_endpoint],
                :storage_cloud => options[:primary_storage_cloud] || @cloud,
                :storage_key => options[:primary_storage_key],
                :storage_secret => options[:primary_storage_secret],
                :storage_container => options[:primary_storage_container] || nickname
              })
              @backup[:primary] = RightScale::Tools::Backup.factory(:ros, @cloud, @mount_point, @snapshot_mount_point, unique_volume_nickname, primary_options)
            end
          end
        end

        def create(options = {})
          mount_point_check

          stripe_count, volume_size, vg_data_percentage = check_create_options(options)

          reset if options[:force]

          devices = @platform.get_next_devices(
            stripe_count,
            device_letter_exclusions
          )

          each_volume_size = (volume_size.to_f / stripe_count.to_f).ceil
          devices.map! do |device|
            instance = @api.client.get_instance
            # create the volume
            params = {
              :volume => {
                :name => unique_volume_nickname
              }
            }

            datacenter_href = instance.links.detect do |link|
              link['rel'] == 'datacenter'
            end

            if datacenter_href
              params[:volume][:datacenter_href] = datacenter_href['href']
            end

            if @cloud == :"rackspace-ng"
              # Rackspace Open cloud supports a minimum volume size of 100GB
              if each_volume_size < 100
                raise "Minimum volume size supported by this cloud is 100 GB." +
                  " Volume size requested #{each_volume_size.to_s} GB."
              end
              params[:volume][:size] = each_volume_size.to_s

              # Rackspace Open Cloud offers two volume types - SATA and SSD
              volume_types = @api.client.volume_types.index
              volume_type = volume_types.detect do |type|
                type.name == options[:volume_type]
              end
              params[:volume][:volume_type_href] = volume_type.href

            elsif @cloud == :cloudstack
              # CloudStack has the concept of a "custom" disk offering
              # Anything that is not a custom type is a fixed size.
              # If there is not a custom type, we will use the closest size
              # which is greater than or equal to the requested size.
              # If there are multiple custom volume types or multiple
              # volume types with the closest size, the one with the
              # greatest resource_uid will be used.
              # If the resource_uid is non-numeric (e.g. a UUID), the first
              # returned valid volume type will be used.

              volume_types = @api.client.volume_types.index
              custom_volume_types = volume_types.select do |type|
                type.size.to_i == 0
              end

              unless custom_volume_types.empty?
                volume_types = custom_volume_types
              else
                volume_types.reject! {|type| type.size.to_i < each_volume_size}
                minimum_size = volume_types.map {|type| type.size.to_i}.min
                volume_types.reject! {|type| type.size.to_i != minimum_size}
              end

              if volume_types.empty?
                raise "Could not find a volume type that is large enough" +
                  " for #{each_volume_size} GB"
              elsif volume_types.size == 1
                volume_type = volume_types.first
              elsif volume_types.first.resource_uid =~ /^[0-9]+$/
                @logger.info "Found multiple valid volume types, using the" +
                  " volume type with the greatest numeric resource_uid"
                volume_type = volume_types.max_by do |type|
                  type.resource_uid.to_i
                end
              else
                @logger.info "Found multiple valid volume types, using the" +
                  " first returned valid volume type"
                volume_type = volume_types.first
              end

              if volume_type.size.to_i == 0
                @logger.info "Found volume type that supports custom sizes:" +
                  " #{volume_type.name} (#{volume_type.resource_uid})"
                params[:volume][:size] = each_volume_size.to_s
              else
                @logger.info "Did not find volume type that supports custom" +
                  " sizes, using closest volume type: #{volume_type.name}" +
                  " (#{volume_type.resource_uid}) which is" +
                  " #{volume_type.size} GB"
              end

              params[:volume][:volume_type_href] = volume_type.href
            else
              params[:volume][:size] = each_volume_size.to_s
            end

            # hold on to the list of current devices
            current_devices = @platform.get_current_devices

            @logger.debug "Requesting volume creation." +
              " params = #{params.inspect}"
            volume = @api.client.volumes.create(params)
            @logger.info "waiting for volume to create -" +
              " initial current status = #{volume.show.status}"
            status = volume.show.status
            # 15 minute timeout
            Timeout::timeout(900) do
              while status != 'available' && status != 'provisioned'
                @logger.info "waiting for volume to create status is #{status}"
                raise "Creation of volume has failed." if status == "failed"
                sleep 2
                status = volume.show.status
              end
            end

            # attach the new volume
            params = {
              :volume_attachment => {
                :volume_href => volume.show.href,
                :instance_href => instance.href,
                :device => device
              }
            }

            # Use the lowest available LUN if we are on Azure/HyperV/VirtualPC.
            #
            # If we are on google the device parameter must be between 1 and 255
            # alphanumeric characters, dots, and dashes, starting with an
            # alphanumeric character. We will use numbers starting from 0.
            # Example: persistent-disk-1, 1
            if @hypervisor == 'virtualpc' || @cloud == :google
              luns = @api.attached_devices.map do |attached_device|
                attached_device.to_i
              end.to_set
              lun = 0
              params[:volume_attachment][:device] = loop do
                break lun unless luns.include? lun
                lun += 1
              end
            end

            # on EC2 device must be /dev/sdX
            if [:ec2, :ec2_gateway].include? @cloud
              params[:volume_attachment][:device].gsub!(
                /^\/dev\/[a-z]+d/,
                '/dev/sd'
              )
            end

            @logger.debug "Request volume attachment." +
              " params = #{params.inspect}"

            # hold on to the list of current devices
            current_devices = @platform.get_current_devices
            actual_device = nil

            Timeout::timeout(900) do # 15 Minute timeout
              begin
                attachment = @api.client.volume_attachments.create(params)
              rescue RestClient::Exception => e
                if e.http_code == 504
                  @logger.warn "timeout creating attachment - #{e.message}," +
                    " retrying..."
                  sleep 2
                  retry
                end
                raise
              end

              @logger.info "waiting for volume to attach -" +
                " initial current status = #{volume.show.status}"
              begin
                status = volume.show.status
                state = attachment.show.state
                while status != 'in-use' && state != 'attached'
                  @logger.info "attaching - waiting for volume to attach -" +
                    " status is #{status} / #{state}"
                  sleep 2
                  status = volume.show.status
                  state = attachment.show.state
                end
              rescue RestClient::Exception => e
                if e.http_code == 504
                  @logger.warn "timeout waiting for attachment -" +
                    " #{e.message}, retrying..."
                  sleep 2
                  retry
                end
                raise
              end
              @platform.scan_for_attachments

            end

            # A 2-minute wait loop to discover newly created device.
            # This is required for Eucalyptus cloud.
            Timeout::timeout(120) do # 2 minute timeout
              @platform.scan_for_attachments
              while @platform.get_current_devices.size == current_devices.size
                @logger.info "Waiting to discover newly created device"
                sleep 2
                @platform.scan_for_attachments
              end
            end

            # Determine the actual device name
            actual_device = (
              Set.new(@platform.get_current_devices) - current_devices
            ).first

            if device != actual_device
              @logger.warn "Device = #{device} Actual_device = #{actual_device}"
            end

            # pass device to devices.map!
            actual_device
          end

          initialize_stripe(devices,vg_data_percentage)
        end

        def reset
          # we can't trust the api to give us correct device names
          devices = @platform.get_devices_for_volume(@device)
          reset_devices(devices)
          @api.reset_attachments(unique_volume_nickname)

          # vmware/esx requires the following 'hack' to make OS/Linux aware of removed device.
          # Check for /sys/block/#{each_device}/device/delete if need to run.
          devices.each do |each_device|
            each_device.sub!(/^\/dev\//,"")
            if File.exist?("/sys/block/#{each_device}/device/delete")
              execute("echo 1 > /sys/block/#{each_device}/device/delete")
            end
          end

        end

        protected

        # Use the hypervisor to determine if ROS backup/restore will be needed
        def create_before_restore?(level)
          if level == :primary
            # There is a bug in ohai that causes it to not detect KVM in some
            # cases, if the hypervisor is nil we assume it is KVM
            if @hypervisor.nil? || @hypervisor == 'kvm'
              @logger.info "Ohai did not detect the hypervisor." +
                " Setting the hypervisor to 'kvm' by default."
              # Google cloud supports live snapshots even though it uses KVM
              # hypervisor. Hence we should return 'false' here.
              @cloud == :google ? false : true
            else
              false
            end
          else
            true
          end
        end

        # Some hypervisors have 'holes' in their attachable device list
        # This method returns an list of those exclusions
        def device_letter_exclusions
          exclusions = []
          # /dev/xvdd is assigned to the cdrom device
          # eg., xentools iso (xe-guest-utilities)
          # that is likely a xenserver-ism
          exclusions = [ 'd' ] if @cloud == :cloudstack
          exclusions
        end

      end
    end
  end
end
