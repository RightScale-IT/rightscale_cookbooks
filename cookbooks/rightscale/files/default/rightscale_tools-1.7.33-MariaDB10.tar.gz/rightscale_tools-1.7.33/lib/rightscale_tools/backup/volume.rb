#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/backup'

module RightScale
  module Tools
    module Backup
      class Volume < Backup

        def backup(lineage, options = {})
          description = options[:description] ||
            "Snapshot created by RightScale tools."

          # Perform backup
          backup_volume(
            lineage,
            description,
            options[:from_master]
          )
        end

        def cleanup(lineage, options = {})
          # Set rotation defaults
          rotation_options = {
            :max_snapshots => options[:max_snapshots] || 60,
            # the 1.5 API calls max_snapshots by the name keep_last
            :keep_last => options[:max_snapshots] || 60,
            :keep_dailies => options[:keep_dailies] || 14,
            :keep_weeklies => options[:keep_weeklies] || 6,
            :keep_monthlies => options[:keep_monthlies] || 12,
            :keep_yearlies => options[:keep_yearlies] || 2
          }

          # Perform volume cleanup
          cleanup_volume(
            lineage,
            rotation_options
          )
        end

        def restore(lineage, options = {})
          restore_volume(lineage, options)
        end
      end
    end
  end
end
