#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/fog'

module RightScale
  module Tools
    module ROS
      class Local < Fog

      register :local
      
      protected
      
        def config_hash(key, secret, ros_options)
          local_root = ros_options[:local_root]
          raise "ERROR: you must supply :local_root option." unless local_root
          { 
            :provider   => 'Local',
            :local_root => local_root 
          }
        end
        
      end
    end
  end
end
