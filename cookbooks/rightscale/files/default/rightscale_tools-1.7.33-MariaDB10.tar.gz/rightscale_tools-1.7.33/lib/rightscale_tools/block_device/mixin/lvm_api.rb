#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

module RightScale
  module Tools
    module BlockDevice
      module LVMAPIMixin
        def reset
          devices = @api.attached_devices(unique_volume_nickname)
          reset_devices(devices)
          @api.reset_attachments(unique_volume_nickname)
        end
      end
    end
  end
end
