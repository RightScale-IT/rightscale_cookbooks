#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

module RightScale
  module Tools
    module FileSystem
      class EXT3 < FileSystem
        def name
          "ext3"
        end

        def mkfs_command
          "mkfs.ext3"
        end

        def growfs_command
          "resize2fs"
        end

        def growfs_parameter_type
          :device
        end

        def mount_snapshot_options
          nil
        end
      end
    end
  end
end
