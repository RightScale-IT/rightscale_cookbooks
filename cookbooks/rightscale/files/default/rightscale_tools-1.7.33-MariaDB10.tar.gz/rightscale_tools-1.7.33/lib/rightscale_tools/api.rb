#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/mixin/common'


module RightScale
  module Tools
    module API
      class Client
        include RightScale::Tools::Common

        # Register this RightScale instance facing API client implementation class; this should only be called in the definition of subclasses.
        #
        # @param [String] version the version of the RightScale instance facing API this implementation class supports
        #
        def self.register(version)
          RightScale::Tools::API.register(version, self)
        end
        private_class_method :register

        # Constructs the RightScale instance facing API client; this should only be called by subclasses and the factory.
        #
        # @param [Hash] options optional parameters
        #  * for version '1.5' options is also passed into {RightAPI::Client}
        #
        def initialize(options)
          @logger = logger
        end
      end

      # Regiser a RightScale instance facing API client implementation class.
      #
      # @param [String] version the version of the RightScale instance facing API the implementation class supports
      # @param [Class] implementation RightScale instance facing API client implementation class
      #
      def self.register(version, implementation)
        @@implementations ||= {}
        @@implementations[version.to_s] = implementation
      end

      # Factory for creating RightScale instance facing API client objects.
      #
      # @param [String] version the version of the RightScale instance facing API the object should support, currently '1.0' or '1.5'
      # @param [Hash] options optional parameters
      #  * for version '1.5' options is also passed into {RightAPI::Client}
      #
      # @return [RightScale::Tools::API::Client] the RightScale instance facing API client object
      #
      def self.factory(version, options = {})
        require '/var/spool/cloud/user-data.rb'
        implementation = @@implementations[version.to_s]
        raise "unsupported API version: #{version}" unless implementation
        implementation.new options
      end
    end
  end
end

require 'rightscale_tools/api/10.rb'
require 'rightscale_tools/api/15.rb'
