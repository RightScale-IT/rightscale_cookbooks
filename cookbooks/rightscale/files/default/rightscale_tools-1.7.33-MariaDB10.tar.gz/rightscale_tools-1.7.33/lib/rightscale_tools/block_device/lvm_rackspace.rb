#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/block_device/lvm'

module RightScale
  module Tools
    module BlockDevice
      class LVMRackspace < LVM
        register :lvm, :rackspace, :rackspaceuk

        def initialize(cloud, mount_point, nickname, uuid, options)
          super(cloud, mount_point, nickname, uuid, options)

          primary_options = options.merge({
            :endpoint => options[:primary_endpoint],
            :storage_cloud => options[:primary_storage_cloud] || @cloud,
            :storage_key => options[:primary_storage_key],
            :storage_secret => options[:primary_storage_secret],
            :storage_container => options[:primary_storage_container] || unique_volume_nickname
          })
          @backup[:primary] = RightScale::Tools::Backup.factory(:ros, @cloud, @mount_point, @snapshot_mount_point, unique_volume_nickname, primary_options)
        end

        def create(options = {})
          mount_point_check
          vg_data_percentage = options[:vg_data_percentage].to_i
          @logger.info "Creating Rackspace LVM snapshot percentage: #{vg_data_percentage}"
          raise 'Invalid volume group data percentage' unless vg_data_percentage >= 50 and vg_data_percentage <= 100
          @logger.warn "WARNING: Allocating more than 90% of volume group for data.  There may not be enough space remaining for snapshots" if vg_data_percentage > 90 and vg_data_percentage < 100
          @logger.warn "WARNING: Allocating more than %100 of volume group for data.  Snapshots will fail" if vg_data_percentage > 100
          root_device = @platform.get_root_device
          info = @platform.get_device_partition_info(root_device)
          @logger.info "partition info for #{root_device}: #{info.inspect}"
          available = info[:size] - info[:partitions][1][:size]
          @logger.info "available space: #{available}"

          raise "not enough space to create a block device: #{available} bytes; a disk with at least 1GB of space is required" if available < 1024 ** 3 # 1GB

          device = @platform.create_partition(root_device, info[:partitions][1][:end] + 1, info[:size] - 1)

          initialize_stripe([device],vg_data_percentage)
        end

        def reset
          devices = @platform.get_devices_for_volume(@device)
          reset_devices(devices)
          devices.each {|device| @platform.destroy_partition(device)}
        end

        protected

        def create_before_restore?(level)
          true
        end
      end
    end
  end
end
