#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'fileutils'
require 'rightscale_tools/database/database_mysql'

module RightScale
  module Tools
    class DatabaseMysql55 < RightScale::Tools::DatabaseMysql
      
      private
      
      # Instantiates our premium DB tools class
      #
      # This is out premium DBtools class that is shared with our RightScript 
      # based 11H1 ServerTemplates.
      #
      # See the premium/README.rdoc for more information.
      #
      def create_shared_premium_util
        require 'rightscale_tools/premium/db/common/d_b_utils_mysql55'
        RightScale::DBUtilsMysql55.new
      end

    end
  end
end

