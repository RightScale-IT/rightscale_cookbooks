#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

module RightScale
  module Tools

    class CloudCapability
      def initialize(support_options = {})
        @volume_support = support_options[:volume]
        @snapshot_support = support_options[:snapshot]
      end

      def support_volume?
        @volume_support
      end

      def support_snapshot?
        @snapshot_support
      end
    end
  end
end
