#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rubygems'
require 'mysql'
require 'system_timer'

require File.dirname(__FILE__) +  '/../common/d_b_utils.rb'

module RightScale
  class DBUtilsMysql
    include RightScale::DBUtils

    DBMountPoint = "/mnt/mysql"
    # Filename (from the root of the mysql datafile) where the tools will save the file/position of the master at the point of the backup
    SAVED_MASTER_POS_FILE="rs_snapshot_position.yaml"
    attr_reader :rep_user, :rep_pass, :mycnf_filename, :binlog_prefix
    
    def initialize(params = {})
      ### Variables
      # MySQL user and password to use at the slave DB to perform replication
      # This needs to match the deltaset that configure the master DB...
      # This user just needs replication access
      @rep_user=params[:rep_user]
      @rep_pass=params[:rep_pass]

      # if running outside runrightscripts.rb, this variable is unset.
      ENV['RS_DISTRO'] = `lsb_release -is`.chomp.downcase unless ENV['RS_DISTRO']
      
      # Default position of the my.cnf configuration file
      case ENV['RS_DISTRO'].to_s
        when "ubuntu"; @mycnf_filename = "/etc/mysql/my.cnf"
        when "centos"; @mycnf_filename = "/etc/my.cnf"
        when "redhatenterpriseserver"; @mycnf_filename = "/etc/my.cnf"
        else; raise "FATAL: Unsupported Distro: #{ENV['RS_DISTRO']}"
      end    
           
      @binlog_prefix = params[:binlog_prefix]
    end

    ### RS Tools 2.0 interface methods

    # Get database connection
    #
    # === Parameters
    # host(String):: hostname or ip of database
    # user(String):: user to connect as
    #
    # === Return
    # (Connection):: connection to database   
    def get_connection(host = "", user = "root" )
      Mysql.new(host, user)
    end
    
    # Query database for version string
    #
    # === Return
    # (String):: database version   
    def get_version
      rs = dbcon.query('SELECT version()').fetch_hash
      db_version = rs["version()"]
      puts "Detected MySQL version at #{db_version}."
      db_version
    end
    
    # Update permission so all files are owned by database service
    #
    # === Parameters
    # data_dir(String):: path to MySQl data dir
    def update_permissions(data_dir)
      FileUtils.chown_R 'mysql', 'mysql', data_dir
    end


    ### Miscelaneous  ###
    
    def write_backup_info_file(filepath)
      slavestatus = dbcon.query('SHOW SLAVE STATUS').fetch_hash
      # if slavestatus is nil this would indicate we are on a master instance
      # This tool is designed to be called with optional options[:from_master].  If we receive this option then we can safely use the check below since we know the caller (in this case the cron template script) has done a DNS check and set options[:from_master]
      if slavestatus == nil && options[:from_master] == "true"
        masterstatus = dbcon.query('SHOW MASTER STATUS').fetch_hash
        puts "Detected this is a Master instance"
        masterstatus['Master_IP'] = db.get_ip_from_ifconfig(nil)
        masterstatus['Master_instance_id'] = ENV['EC2_INSTANCE_ID']
      else
        puts "Detected this is a Slave instance"
        masterstatus = Hash.new
        # Need to get the master hostname from slave status and then resolve to get the IP
        masterhost = slavestatus['Master_Host']
        if masterhost =~ /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/
          # masterhost is an IP already
          masterip = masterhost
        else
          # masterhost is a hostname
          masterip = masterstatus['Master_IP'] = `host -4 -t A #{masterhost}`.split(/ /)[3].chomp
        end
        masterstatus['Master_IP'] = masterip
        masterstatus['Master_instance_id'] = `ssh #{masterhost} 'source /var/spool/cloud/meta-data.sh  2>&1 > /dev/null&& echo $EC2_INSTANCE_ID'`.chomp
        masterstatus['File'] = slavestatus['Relay_Master_Log_File']
        masterstatus['Position'] = slavestatus['Exec_Master_Log_Pos']
      end
      
      # Add db version to masterstatus
      r = dbcon.query('SELECT version()').fetch_hash
      masterstatus['DB_version'] = r["version()"]

      puts "Saving master info...:\n#{masterstatus.to_yaml}"
      File.open(filepath, File::CREAT|File::TRUNC|File::RDWR) do |out|
       YAML.dump(masterstatus, out)
      end
    end

    # Util function that returns true if Major.Minor version numbers are the same
    # Intended for the results of "SELECT version()" to be passed as version params.
    # NOTE: legacy snapshots will have a snapshot version of nil, assume MySQL 5.0 in that case.
    def compatible_versions?(db_version, snapshot_version)
      # raise "ERROR: unexpected version format for db_version param (#{db_version})" unless db_version =~ /[0-9]\.[0-9]\..*-.*/
      raise "ERROR: unexpected version format for db_version param (#{db_version})" unless db_version =~ /\d+\.\d+\..*-.*/
      if snapshot_version == nil 
        # If no snapshot version, assume 5.0 snapshot
        snapshot_version = "5.0.9999-legacy_rightscale_snapshot_detected"
      end
      # raise "ERROR: unexpected version format for snapshot_version param (#{snapshot_version})" unless snapshot_version =~ /[0-9]\.[0-9]\..*-.*/
      raise "ERROR: unexpected version format for snapshot_version param (#{snapshot_version})" unless snapshot_version =~ /\d+\.\d+\..*-.*/
      # compare version array containing only Major and Minor numbers
      db_version.split('.').slice(0,2) == snapshot_version.split('.').slice(0,2) 
    end
    
    
    def sanity_checks(host=nil)
      # Check Gem
      mysql_gem_check
      
      # Perform an initial connection forcing to accept the keys...to avoid interaction.
      accept_ssh_key(host) if host 

      # Check if the host has mysql running (abort if not)
      raise "DB is not up... Aborting." unless  is_started?(host)
    end
    
    
    # Util function that prints the version of Mysql class the current script is using
    # It warns about the non-C version (in case it it the one installed)
    def mysql_gem_check
      # Verify mysql client version
      mysql_native_1 = true
      Mysql.debug("test") rescue mysql_native_1 = false
      mysql_native_2 = Mysql.client_info =~ /\A[0-9.]+.\Z/
      if mysql_native_1 && mysql_native_2
        puts "Using C interface for mysql, client version #{Mysql.client_info}"
      else
        puts "***** USING RUBY INTERFACE FOR MYSQL: consider installing C version (gem install mysql), client version #{Mysql.client_info}"
      end
    end

    # It will attempt to delete a typical list of files that MySQL stores about its
    # current runtime config...
    # These could cause problem if left in a node for which a new DB is copied over
    def wipe_existing_runtime_config_files( host , datadir )
      prefix = (host!=nil) ? "ssh #{host} ":""
  
      files_to_delete = [ "master.info","relay-log.info","mysql-bin.*","*relay-bin.*"]
      files_to_delete.collect! {|f| "#{datadir}/#{f}"}
      files_to_delete.each do |f|
        puts "deleting stale file: #{f} (if exists)"
        output = `#{prefix} rm -f #{f}`
        raise RemoteExecException.new(host,$?,output) if $? != 0
      end
    end
  
    # Attempts to start the DB several times (sleeping in between)
    def ensure_db_started(host=nil)      
      success = false
      5.times {|attempt|
        success = ensure_db_started_internal(host)
        break if success 
        puts "Error starting DB: attempt #{attempt}. Trying again..."
        attempt +=1
        sleep 2
      }
      
      if( success == true )
        puts "Database started OK."
      else
        puts "Error starting DB. Giving up..."
        raise RemoteExecException.new(nil,$?,"Error starting DB") 
      end  
      success      
    end



    def ensure_db_up_with_binlog
      begin
        # 1- Check if the host has mysql running 
        raise "DB was not up and couldn't be started. Aborting..." if  ensure_db_started == false
        con = Mysql.new("", "root" )
        # Dummy query to ensure we generate an exception if the DB is down
        con.query("SELECT NOW()")
        # If we don't jump out of here it means the DB is UP..
        # Check if it's doing binary logging
        result = con.query("SHOW VARIABLES LIKE 'log_bin'").fetch_hash
        # We're good if the DB is up and binlog is enabled
        return if result && result['Value'].downcase == "on"
    
        puts "Server doesn't appear to be logging binary logs, configuring and restarting server with binary logging"
        #If we're here, the DB is up, but no binlog...shutdown, reconfigure and start
        db_service_stop
        configure_mycnf_for_master_operation(@mycnf_filename)
        db_service_start
      rescue Mysql::Error => e
        # DB is down...enable log_bin and server-id (if not done yet) and restart it
        puts "DB seems to be down...: #{e.error}"
        puts "Reconfiguring #{@mycnf_filename} with log-bin=#{@binlog_prefix}"
        configure_mycnf_for_master_operation(@mycnf_filename)
        # Start the server
        db_service_start
      end
      #TODO: We could do a last check here to make sure that the running server has log_bin enabled
    end
    
    
    
    # It executes a service mysql stop on the specified node
    # It returns the output of the status command on success or an exception if failure
    def db_service_stop( host=nil )
      return execute_db_service_command( host , "stop" )
    end

    # It executes a service mysql start on the specified node (if it's not running already)
    # It returns the output of the status command on success or an exception if failure
    def db_service_start( host=nil )
      return execute_db_service_command( host , "start" )
    end

    # It executes a service mysql 'command' on the specified node
    # It returns the output of the status command after performing the action (or a RemoteExecException if an error or inconsistency is detected
    def execute_db_service_command( host , action )
     
      os_vals = get_os_service_values(host)

      exec_prefix = (host!=nil) ? "ssh #{host} ":"" 
        action_res = `#{exec_prefix} service #{os_vals[:mysql_service]} #{action}`
      action_errno = $?
      status_res = `#{exec_prefix} service #{os_vals[:mysql_service]} status`
  
      if( action == "stop" )
        #If we stopped the DB but the status says it is running, throw an exception with the output of the initial action
        raise RemoteExecException.new(host,action_errno,"Error stopping DB:\n"+action_res) if status_res =~ /#{os_vals[:mysql_started_tag1]}/ || status_res =~ /#{os_vals[:mysql_started_tag2]}/
      elsif (action == "start")
        #If we started the DB but the status says it is stopped, throw an exception with the output of the initial action
        raise RemoteExecException.new(host,action_errno,"Error starting DB:\n"+action_res) if status_res =~ /#{os_vals[:mysql_stoped_tag1]}/ || status_res =~ /#{os_vals[:mysql_stoped_tag2]}/
      end
      #if the action succesded (or it is another not stop/start action), just return the result of the status
      return status_res
    end

    # Sets the replication grants according to the global variables (set by environment params)
    def set_replication_grants(slavecon)
      raise "Replication User and/or password variables not set!. Probably forgot to set them on the environment or rightscript?" if @rep_user == nil || @rep_pass == nil
      slavecon.query("GRANT REPLICATION SLAVE ON *.* TO '#{@rep_user}'@'%' IDENTIFIED BY '#{@rep_pass}'")
      slavecon.query("FLUSH PRIVILEGES")
      #TODO: Write it to my.cfg
    end
  
    # Reconfigure the replication parameters of a DB (through an already open connection).
    # It will change the master parameters, and restart the slave threads to begin 
    # replicating from the new master
    def reconfigure_replication_info( con , newmaster_host, rep_user, rep_pass, newmaster_file, newmaster_position)
      puts "Configuring replication and starting the slave threads"
  
      # must stop the threads if they're running in order to change the settings
      con.query("STOP SLAVE") 
      # does this fail if already stopped?
      con.query("STOP SLAVE") 
      
      # MySQL 5.1 seems to require this
      con.query("RESET SLAVE")
  
      #15 - Configure the old master to be the slave of the new one
      cmd = "CHANGE MASTER TO MASTER_HOST='#{newmaster_host}'"
      cmd = cmd +          ", MASTER_USER='#{rep_user}'"
      cmd = cmd +          ", MASTER_PASSWORD='#{rep_pass}'"
      cmd = cmd +          ", MASTER_LOG_FILE='#{newmaster_file}'"
      cmd = cmd +          ", MASTER_LOG_POS=#{newmaster_position}"
      puts "Reconfiguring replication params: \n#{cmd}"
      con.query(cmd)
      #TODO: Write it to master cfg
      #16 - Kick off replication on the old master (i.e., new slave)
      con.query("START SLAVE")
      started=false
      10.times do
        row = con.query("SHOW SLAVE STATUS").fetch_hash
        slave_IO = row["Slave_IO_Running"].strip.downcase
        slave_SQL = row["Slave_SQL_Running"].strip.downcase
        if( slave_IO == "yes" and slave_SQL == "yes" ) then
          started=true
          break
        else
          puts "threads at new slave not started yet...waiting a bit more..."
          sleep 2
        end
      end
      if( started )
        puts "OK, we have a new master and slave replication (from old master) is functioning."
      else
        puts "Error: slave threads in the master do not seem to be up and running..."
      end  
      return started
    end  


    def reconfig_replication_with_terminate(options = {})
      timeout = options[:timeout] || RightScale::DBUtils::QueryTimeout
      SystemTimer.timeout_after(timeout) do
        con = Mysql.new(options[:oldmaster], options[:user], options[:pass])
        reconfigure_replication_info( con,
          options[:newmaster],
          options[:replication_user],
          options[:replication_pass],
          options[:newmaster_file],
          options[:newmaster_position] )
      end
      return true
    rescue Exception => e
      puts "Error occured updating replication information on oldmaster: #{e}"
      return false
    end
    
    # takes options for host, user, pass, query, and timeout in seconds
    # Returns the unmodified result of connection.query
    def do_query_with_terminate(options = {})
      [:user,:query].each do |s|
        raise "ERROR: do_query_with_terminate, argument error: missing #{s}" if options[s] == nil
      end
      timeout = options[:timeout] || RightScale::DBUtils::QueryTimeout
      host = options[:host] || "" # Localhost by default
      result = nil
      puts "running query: #{options[:query]}"
      puts "timeout: #{timeout}"
      puts "host: #{host}"
      puts "options: #{options.inspect}"
      SystemTimer.timeout_after(timeout) do
        con = Mysql.new(host, options[:user], options[:pass])
        puts "Connected to host [#{host}]"
        result = con.query(options[:query])
        puts "Query completed."
      end 
      return result
    end
    

    # It will try to flush the outstanding data and get a global lock on the DB so
    # that we have a stable and consistend disk image (i.e., to backup/snapshot)
    # This function takes a timeout and number of allowed attempts to aquire the lock.
    # returns PID of a process that holds the lock if it succeeds. Which means that 
    #             the flush has been made and the lock is helod by that "waiting" process.
    #             The caller must ensure that the resulting PID is killed, to release 
    #             the locks. One can use the function release_lock_from_helper() provided 
    #             Otherwise the process will never release them
    # returns nil if the locks couldn't be retrieved in the timeout specified,
    # for the given amount of attempts.
    def flush_and_lock_db( dbhost, user, password, timeout, max_attempts)
      got_lock_message = "GOT_LOCK"
      release_lock_message = "RELEASE_LOCK"
      procs = []
      rd_pipes = []
      wr_pipes = []
      successful = -1
      begin
        max_attempts.times do |round|     
          rd,wr = IO.pipe
          rd_pipes[round] = rd
          wr_pipes[round] = wr
          pid = fork do 
            begin
              rd.close
              #puts "This is a proc. Info: #{$$}"  
              if password then
                con = Mysql.new(dbhost,user, password)
              else
                con = Mysql.new(dbhost,user)
              end
              con.query('FLUSH TABLES WITH READ LOCK')
              puts "proc #{$$} got the lock"
              wr.write(got_lock_message)
              # wait until be notified 
              begin 
                sleep(4) # we'll loop sleep while we await our fate (the parent to kill us)
                next
              rescue StandardError => e
                puts "Rescued something: "+e.to_s
                break # any other error and we're out...
              end while true
            ensure
              con.close if con
            end
            exit(-1)
          end
          # Parent...attempting a trial round
          procs[round] = pid
          successful = check_pipes_for_success( procs, rd_pipes, timeout , got_lock_message)
          break if successful != nil
        end
        if successful != nil then
          puts "Process #{procs[successful]} has the lock. terminating others." 
          procs.each_index do |pidx|
            Process.kill("SIGKILL",procs[pidx]) unless pidx == successful
          end
          return procs[successful]
        else
          puts "No...couldn't get the locks in the end...terminating all helper processes"
          procs.each_index do |pidx|
            puts "killing PID #{procs[pidx]}"
            Process.kill("SIGKILL",procs[pidx])
          end
          return nil
        end
      ensure 
      end
    end    

    ### Database manipulation 

    # Extract database file configuration from a MySQL database
    # The received 'con' is an open MySQL connection from which we must query the config
    def get_db_file_config_from(con)
  
      # Main data directory of the DB
      datadir = con.query( "show variables like 'datadir'" ).fetch_hash['Value']
  
      # InnoDB directory of the DB
      innodb_data_home_dir = con.query( "show variables like 'innodb_data_home_dir'" ).fetch_hash['Value']
      # List of files containing the InnoDB data
      fp = con.query( "show variables like 'innodb_data_file_path'" ).fetch_hash['Value']
      #  >> extract all the data files that exist in the master's file path. 
      #  >> Format: datafile_spec1[;datafile_spec2]...  
      #  >> where datafile_spec = file_name:file_size[:autoextend[:max:max_file_size]]
      innodb_data_files = fp.split(/;/).collect { |i|  i.split(/:/)[0] }
  
      # Not using DBD files at this point...: 
      # bdb_home = con.query( "show variables like 'bdb_home'" ).fetch_hash['Value']
  
      #Save retireved values onto a hash
      file_config = Hash.new
      file_config["datadir"] = datadir
      file_config["innodb_data_home_dir"] = innodb_data_home_dir
      file_config["innodb_data_files"] = innodb_data_files
      return file_config
    end

    # Checks if the mysql setup of a given host is in initial/pristine condition
    def is_mysql_pristine?( dbhost , db_config ) 
      datadir = db_config['datadir']
      cmd = "cd #{datadir}; find . -type d"
      cmd = "ssh #{dbhost} \"(#{cmd})\"" if dbhost
      res = `#{cmd}`
      raise RemoteExecException.new(dbhost,$?,res) if $? != 0
      dirs = res.split
      dirs.delete(".")
      dirs.delete("./mysql")
      dirs.delete("./test")
      dirs.delete("./performance_schema")
      # If there's any directory left, that means it was not pristine
      return dirs.length == 0
    end

    ###### Manipulation of mysql configuration file (my.cnf)

    # Given a path to a my.cnf file, load it into an array of arrays
    # First level array will contain the sections: one hash entry for each section with {:name,:contents}
    # second level (i.e., contents) will be an array with an hash on each entry: {:key, :value}
    def load_mycnf(mycnf_filename)
      file_contents = IO.read(mycnf_filename)
      contents = []
      section_idx=-1
      subsection_idx=0
      file_contents.each { |line|
        if line =~ /^\[([^\]]+)\]/ then
          section_idx = section_idx+1
          section = {:name => $1, :contents => []}
          contents[section_idx] = section
          subsection_idx = 0
        else
          #Safely ignore any contents before the first section
          if section_idx>=0 then
            contents[section_idx][:contents][subsection_idx] = line
            subsection_idx = subsection_idx + 1
          end
        end
      }
      return contents;
    end

    #Dump the contents of a mycnf structure (created with load_mycnf) out to a string
    # Internally used by save_mycnf
    def dump_mycnf( the_contents )
      out = ""
      the_contents.each { |sec|
        out << "[#{sec[:name]}]\n"
        sec_cont = sec[:contents]
    
        sec_cont.each { |line|
          out << line
        }
      }
      return out
    end

    #It will create(i.e., and overwrite) a file with the given contents from a mycnf_tree
    def save_mycnf( content_tree, filename )
      f = File.new(filename,"w")
      f.write dump_mycnf( content_tree )
      f.close
    end

    # Change the mycnf tree to have a new variable=value
    # If the value exists but it is commented, the comment will be left in place and
    # a new entry is added at the end of the section.
    # If the value is not set (or commented) it will also be added at the end of the section.
    def mycnf_setvariable(mycnf_tree, section_name ,variable ,value)
      section_contents = nil
      mycnf_tree.each { |sec|
        if sec[:name]==section_name then
          section_contents = sec[:contents] 
          break
        end
      }
      raise "Section not found" if !section_contents 
      #find the line containing the variable
      idx_match = nil
      pos_match = nil #position of the match (starting position of the variable in the line)
      section_contents.each_index { |idx|
        pos_match = section_contents[idx] =~ /#{variable}\s*=/
        if (pos_match ) then
          idx_match = idx
          break
        end
      }
      if idx_match then
        #We found a matching line...but it could be commented out
        comment_pos = section_contents[idx_match].index("#")
        if( ! comment_pos ) then
          #No comment, direct substitution of the line
          section_contents[idx_match] = "#{variable}=#{value} #Automatically generated by RightScale\n"
        else
          #There's a comment, is it before or after the variable match
          if( comment_pos > pos_match ) then
            #After...keep the comment but introduce the variable
            section_contents[idx_match] = "#{variable}=#{value} "+ section_contents[idx_match][comment_pos..-1]
          else
            # Before...(i.e., the variable is commented) let's leave the commented line untouched and stick at the end
            section_contents << "#{variable}=#{value} #Automatically generated by RightScale\n"
          end
        end
      else
        section_contents << "#{variable}=#{value} #Automatically generated by RightScale\n"
      end
    end


    # Change the mycnf tree to have a variable commented out (or unchange it if it doesn't exist)
    def mycnf_unsetvariable(mycnf_tree, section_name ,variable )
      section_contents = nil
      mycnf_tree.each { |sec|
        if sec[:name]==section_name then
          section_contents = sec[:contents] 
          break
        end
      }
      raise "Section not found" if !section_contents 
      #find the line containing the variable
      idx_match = nil
      pos_match = nil #position of the match (starting position of the variable in the line)
      section_contents.each_index { |idx|
        pos_match = section_contents[idx] =~ /#{variable}\s*=/
        if (pos_match ) then
          idx_match = idx
          break
        end
      }
      if idx_match then
        #We found a matching line...comment it out, and keep the contents after the comment
        section_contents[idx_match] = "# Commented by RightScale: #{section_contents[idx_match]}"
      end
    end

    #Sets a configuration variable on the mycnf.file
    # It does perform the full cycle of opening, parsing, changing and writing for only
    # one variable...if several vars need to be changed, it's better to use the finer grained
    # functions to load and parse...then perform all the changes...and then save
    def change_config_var( mycnf_filename, section , variable ,value)
      f = load_mycnf(mycnf_filename)
      mycnf_setvariable(f,  section , variable ,value )
      save_mycnf(f,@mycnf_filename)
    end

    #Comments a configuration variable on the mycnf.file
    # It does perform the full cycle of opening, parsing, changing and writing for only
    # one variable...if several vars need to be changed, it's better to use the finer grained
    # functions to load and parse...then perform all the changes...and then save
    def unset_config_var( mycnf_filename, section , variable )
      f = load_mycnf(mycnf_filename)
      mycnf_unsetvariable(f,  section , variable )
      save_mycnf(f,@mycnf_filename)
    end

    # Specific (utility) function that writes log-bin and server id in the my.cnf file
    def configure_mycnf_for_master_operation(mycnf_filename)
      mycnf_tree = load_mycnf(mycnf_filename)
      mycnf_setvariable(mycnf_tree, "mysqld","log-bin",@binlog_prefix)
      mycnf_setvariable(mycnf_tree, "mysqld","server-id","#{Time.now().to_i}")
      save_mycnf(mycnf_tree,mycnf_filename)
    end

    #connect and retrieve the size of the datadir directory
    def get_current_size_of_datadir_in_mb(dbhost,user,pw)    
      prefix = (dbhost!=nil) ? "ssh #{dbhost} ":""
      con = Mysql.new(dbhost, user, pw )
      db_config=get_db_file_config_from(con)
      res = `#{prefix} du -ms --exclude 'mysql-bin\.*' #{db_config["datadir"]}`
      raise RemoteExecException.new(nil,$?,"Error retrieving size of DB on host #{dbhost}:\n"+res) unless $? == 0
      mb = res.split(" ").first.chomp
      mb
    end
    
    
    ########################## PRIVATE ##########################
    private
    
    # Tries to bring up the DB once (in case it's stopped)
    # Returns true for success (i.e., the DB is left running) or false if it couldn't be started)
    # There's a similar call (ensure_db_started) that tries to start it more than once
    def ensure_db_started_internal(host=nil)
      status_res = execute_db_service_command( host , "status" )
      return true if status_res =~ /MySQL running/ || status_res =~ /mysqld\s.+is running/ || status_res =~ /Threads/
      execute_db_service_command( host , "start" )
      return true
    end
    
    def is_started?(host=nil)
      os_vals = get_os_service_values(host)
      status_res = execute_db_service_command( host , "status" )
      (status_res =~ /#{os_vals[:mysql_started_tag1]}/ ||  status_res =~ /#{os_vals[:mysql_started_tag2]}/)
    end
    
    def get_os_service_values(host)
      
      host_os = ENV['RS_DISTRO']
      host_os_version = `lsb_release -r` 
      
      if host_os == 'ubuntu'
        {
          :mysql_service => "mysql",
          :mysql_started_tag1 => "Threads",
          :mysql_started_tag2 => "start/running",
          :mysql_stoped_tag1 => "MySQL is stopped",
          :mysql_stoped_tag2 => "stop/waiting"
        }
      elsif  host_os_version =~ /6\.*/
      # CentOS 6.x vs 5.x we are assuming that all non ubuntu OS's are CentOS
      # TODO fix this
        {
          :mysql_service => "mysqld",
          :mysql_started_tag1 => "MySQL running",
          :mysql_started_tag2 => "mysqld\s.+is running",
          :mysql_stoped_tag1 => "mysqld\s.+is stopped",
          :mysql_stoped_tag2 => "MySQL is stopped"
        }
      else
        {
          :mysql_service => "mysql",
          :mysql_started_tag1 => "MySQL running",
          :mysql_started_tag2 => "mysqld\s.+is running",
          :mysql_stoped_tag1 => "mysqld\s.+is stopped",
          :mysql_stoped_tag2 => "MySQL is stopped"
        }
      end
    end
    
  end
end
