#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'json'
require 'pathname'
require 'rightscale_tools/ros'

module RightScale
  module Tools
    module Backup
      class ROS < Backup
        register :ros

        def initialize(cloud, mount_point, snapshot_mount_point, nickname, options)
          super(cloud, mount_point, snapshot_mount_point, nickname, options)

          # construct an unstored ROS so any exceptions that would be throw will be thrown early
          RightScale::Tools::ROS.factory(options[:storage_cloud], options[:storage_key], options[:storage_secret], options)

          @storage_cloud = options[:storage_cloud]
          @storage_key = options[:storage_key]
          @storage_secret = options[:storage_secret]
          @options = options.merge({:cloud => @cloud})
          @container = options[:storage_container]
          raise 'Missing :storage_container option' unless @container
        end

        def backup(lineage, options = {})
          ENV['STORAGE_ACCOUNT_ID'] = @storage_key
          ENV['STORAGE_ACCOUNT_SECRET'] = @storage_secret
          ENV['STORAGE_OPTIONS'] = JSON.dump @options

          cmd = [
            Pathname.new(File.join(File.dirname(__FILE__), '..', '..', '..', 'bin', 'ros_util')).realpath,
            'put_directory',
            '--container', @container,
            '--cloud', @storage_cloud,
            '--source', @snapshot_mount_point,
            '--dest', lineage
          ].join(' ')
          execute(cmd)
          true
        end

        def restore(lineage, options = {})
          timestamp = options[:timestamp]

          @logger.info "Restoring ROS backup from lineage: #{lineage.inspect} timestamp: #{timestamp.inspect} to #{@mount_point.to_s}"

          ENV['STORAGE_ACCOUNT_ID'] = @storage_key
          ENV['STORAGE_ACCOUNT_SECRET'] = @storage_secret
          ENV['STORAGE_OPTIONS'] = JSON.dump @options

          source = timestamp == nil || timestamp.empty? ? lineage : lineage + "-" + timestamp
          cmd = [
            Pathname.new(File.join(File.dirname(__FILE__), '..', '..', '..', 'bin', 'ros_util')).realpath,
            'get_directory',
            '--container', @container,
            '--cloud', @storage_cloud,
            '--source', source,
            '--dest', @mount_point
          ].join(' ')
          @logger.debug("  Running ROS restore command: #{cmd}")
          execute(cmd)
          true
        end

        # We are taking an ROS backup, so report it here
        def backup_type
          :ros
        end

      end
    end
  end
end
