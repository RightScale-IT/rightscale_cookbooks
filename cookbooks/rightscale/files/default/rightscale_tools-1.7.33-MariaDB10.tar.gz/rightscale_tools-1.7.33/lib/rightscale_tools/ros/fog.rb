#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'fog'

module RightScale
  module Tools
    module ROS
      class Fog < ROS
        register :fog

        include CommonMixin
        include FragmenterMixin

        def initialize(key, secret, options)
          super key, secret, options

          ros_options = {
            :logger => @logger
          }
          ros_options.merge! options

          @ros = get_connection(key, secret, ros_options)
        end

        def create_container(container, options = {})
          params = options.merge(:key => container)
          @ros.directories.create(params)
        end

        def create_container_if_not_exists(container, options = {})
          if @ros.directories.all.detect {|b| b.key == container}
            @logger.info "Storage container #{container} already exists, skipping create."
            false
          else
            @logger.info "Storage container #{container} not found, creating."
            create_container(container, options)
            true
          end
        end

        def get_object(container, filename, data = nil, fragmented = false, &block)
          @logger.debug("  get_object called with  container: #{container} data: #{data.inspect} filename: #{filename} fragmented: #{fragmented} block: #{block.inspect}")
          if fragmented
            get_object_from_fragments(container, filename, data, &block)
          elsif data
            get_file(container, filename) {|chunk| data.write(chunk)}
          elsif block
            get_file(container, filename, &block)
          else
            object = get_file(container, filename)
            object
          end
        end

        def get_object_link(container, filename)
          dir = get_directory(container)
          {:url => dir.files.get_https_url(filename, Time.now + 60)}
        end

        def get_latest_object_name(container, filename, fragmented = false)
          results = []
          dir = get_directory(container)
          dir.files.each do |file|
            if fragmented
              results << file.key.gsub(/#{Regexp.escape(INFO_SUFFIX)}$/, '') if file.key =~ /^#{Regexp.escape(filename)}.*#{Regexp.escape(INFO_SUFFIX)}$/
            else
              results << file.key if file.key =~ /^#{Regexp.escape(filename)}.*$/
            end
          end
          results.sort.last
        end

        def put_object(container, filename, data, fragmented = false)
          if fragmented
            case data
            when String
              data = StringIO.new data
            end
            put_object_to_fragments(container, filename, data)
          else
            put_file(container, filename, data)
          end
        end

        def put_object_link(container, filename, data = nil)
          dir = get_directory(container)
          {:url => dir.files.get_https_url(filename, Time.now + 60)}
        end

        def list_object_names(container, options = {}, &block)
          results = []
          options[:marker] = '' unless options.has_key? :marker
          dir = get_directory(container)
          dir.files.all(:prefix => options[:prefix]).each do |file|
            if !options[:prefix] || file.key =~ /^#{Regexp.escape(options[:prefix])}/
              block.call file.key if block
              results << file.key
            end
          end
          results
        end

        def delete_object(container, filename)
          file = file_obj(container, filename)
          file.destroy
        end

        def delete_container(container)
          dir = get_directory(container)
          dir.destroy
        end

      protected

        def config_hash(key, secret, ros_options)
          {
            :provider                         => 'Google',
            :google_storage_secret_access_key => "YOUR_SECRET_ACCESS_KEY",
            :google_storage_access_key_id     => "YOUR_SECRET_ACCESS_KEY_ID"
          }
        end

      private

        def get_connection(key, secret, ros_options)
          @config = config_hash(key, secret, ros_options)
          ::Fog::Storage.new(@config)
        end

        def get_directory(container)
          dir = @ros.directories.get(container)
          raise "ERROR: container #{container} not found." unless dir
          dir
        end

        def file_obj(container, filename)
          dir = get_directory(container)
          files = dir.files.get(filename)
          files
        end

        def get_file(container, filename, &block)
          @logger.debug "get_file: container: #{container} filename:#{filename}"
          file = file_obj(container, filename)
          @logger.debug "  file: #{file.inspect}"
          if block_given?
            yield file.body
          else
            file.body
          end
        end

        def put_file(container, filename, data)
          dir = get_directory(container)
          dir.files.create(
            :key    => filename,
            :body   => data
          )
        end

      end
    end
  end
end
