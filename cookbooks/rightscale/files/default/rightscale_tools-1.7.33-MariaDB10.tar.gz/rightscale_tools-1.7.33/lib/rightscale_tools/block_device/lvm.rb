#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'fileutils'
require 'pathname'
require 'rightscale_tools/backup'
require 'rightscale_tools/block_device/mixin/lvm_api'

module RightScale
  module Tools
    module BlockDevice
      class LVM < BlockDevice
        def initialize(cloud, mount_point, nickname, uuid, options)
          super(cloud, mount_point, nickname, uuid, options)


          # XXX: this is a bit linux specific
          @snapshot_mount_point = "/tmp/snapshot#{@mount_point.gsub('/', '_')}"
          @device = @platform.get_device_for_mount_point(@mount_point)
          clean_nickname = @nickname.downcase.gsub(/[^-._a-z0-9]/, '_')
          @device = "/dev/vg-rightscale-#{clean_nickname}/lvol0" unless @device
          _, _, @vgname, @lvname = @device.split('/')
          @snapshot_name = 'blockdevice_lvm_snapshot'
          @snapshot_device = "/dev/#{@vgname}/#{@snapshot_name}"
          @backup = {}

          # Setup secondary backup device if options given
          if options[:secondary_storage_cloud]
            secondary_options = options.merge({
              :endpoint => options[:secondary_endpoint],
              :storage_cloud => options[:secondary_storage_cloud],
              :storage_key => options[:secondary_storage_key],
              :storage_secret => options[:secondary_storage_secret],
              :storage_container => options[:secondary_storage_container]
            })
            # primary backup/restore is set up in subclasses
            @backup = {
              :secondary => RightScale::Tools::Backup.factory(:ros, @cloud, @mount_point, @snapshot_mount_point, @nickname, secondary_options)
            }
          end
        end

        def snapshot(level, lineage, options = {})
          backup_type = @backup[level.to_sym].backup_type
          case backup_type
          when :volume
            # Take a cloud volume snapshot -- which actually is the backup.
            sync
            execute("fsfreeze --freeze #{@mount_point}")
            @backup[level].backup(lineage, options)
            execute("fsfreeze --unfreeze #{@mount_point}")
          when :ros
            # Perform local LVM snapshot -- not safe on some volume types
            umount @snapshot_mount_point
            delete_snapshot
            sync
            # We allow one snapshot per LVM at a time.  Allocate 100% of the free space on the VG for the snapshot.
            @platform.lvcreate(@device, :snapshot => true, :name => @snapshot_name, :extents => '100%FREE')
          else
            raise "ERROR: Backup type of '#{backup_type}' not supported. Expected :volume or :ros."
          end
        end

        def backup(level, lineage, options = {})
          backup_type = @backup[level.to_sym].backup_type
          case backup_type
          when :volume
            # We already did a backup so just clean it up.
            @backup[level].cleanup(lineage, options)
          when :ros
            # This does the actual backup. NOTE: database is not locked at this point!
            mount_snapshot
            sync
            @backup[level.to_sym].backup(lineage, options)
            umount_snapshot
            delete_snapshot
            @backup[level.to_sym].cleanup(lineage, options)
          else
            raise "ERROR: Backup type of '#{backup_type}' not supported. Expected :volume or :ros."
          end
        end

        def restore(level, lineage, options = {})
          # Remove device(s) using our mount point.
          reset if options[:force]

          # Catching the initial vgs state
          state_before = @platform.get_volume_list

          # Create block device (if necessary)
          if create_before_restore?(level)
            create(options) unless @platform.get_device_for_mount_point(@mount_point)
          end

          # Restore data
          # in case of secondary backup - from ROS directly to attached block device
          @backup[level.to_sym].restore lineage, options

          # Restore via cloud snapshot
          unless create_before_restore?(level)
            # Legacy: rename 11H1 DBMgr snapshot volume group (if detected)
            legacy_vgrename("/dev/vg-ebs-rightscale/lvol0", @vgname)
            # Legacy: rename 11H2 DBMgr snapshot volume group (if detected)
            legacy_vgrename('/dev/vg-rightscale/lvol0', @vgname)

            # Catching vgs state after legacy_vgrename-s
            state_after = @platform.get_volume_list
            # Getting the diff between states
            state_diff = state_after - state_before
            raise "More than one volume group was restored: #{state_diff}" if state_diff.count > 1
            restored_vgname = state_diff.to_s

            # If the diff is found and the volume group name doesn't match the @vgname
            # renaming the volume group using legacy_vgrename
            legacy_vgrename("/dev/" + restored_vgname + "/lvol0", @vgname) if !state_diff.empty? and !restored_vgname.eql? @vgname

            # Enable device
            @platform.enable_volume(@device)
            raise "FATAL: mount failed!" unless mount
            @platform.set_mount_point_for_device(@device, @mount_point)

            restore_snapshot
            sync

            # Grow the filesystem doing a snapshot restore.
            # If volume does not need growing, a warning is given.
            # This should be done after the restore to confirm no snapshot is connected.
            @platform.grow_device(@mount_point, @vgname, options)
          end

        end

        protected

        # Check the options passed to create in one location.
        def check_create_options(options = {})
          stripe_count = options[:stripe_count].to_i
          volume_size = options[:volume_size].to_i
          vg_data_percentage = options[:vg_data_percentage].to_i
          @logger.info "Creating LVM with stripe count: #{stripe_count}, volume size: #{volume_size} and volume group data percentage: #{vg_data_percentage}"
          raise "Invalid stripe count - #{stripe_count}" unless stripe_count > 0
          raise "Invalid volume size - #{volume_size}" unless volume_size > 0
          raise "Invalid volume group data percentage - #{vg_data_percentage}" unless vg_data_percentage >= 50 and vg_data_percentage <= 100
          @logger.warn "WARNING: Allocating more than 90% of volume group for data.  There may not be enough space remaining for snapshots" if vg_data_percentage > 90 and vg_data_percentage < 100
          @logger.warn "WARNING: Allocating %100 of volume group for data.  Snapshots will fail" if vg_data_percentage >= 100
          return stripe_count, volume_size, vg_data_percentage
       end

        # Some backup types require a device to exist before restore
        # others create the device as part of the restore.
        # Let the subclasses for ROS, we must create block_device if it doesn't exist
        def create_before_restore?(level)
          level == :secondary
        end

        def delete_snapshot
          @platform.lvremove(@snapshot_device, :force => true, :ignore_failure => true)
        end

        # Restore the local LVM snapshot
        #
        # Merge snapshot (if available) then reactivate attached LVM volume
        def restore_snapshot

          if File.blockdev?(@snapshot_device)
            @logger.info "Detected local LVM snapshot backup -- restoring snapshot."
            # Merge the snapshot.
            # This will merge the snapshot into the block device volume
            # and delete snapshot device after merge process is completed.
            execute("lvconvert --merge #{@snapshot_device}")
            # Volume reactivation process start
            # The block device volume needs to be deactivated and activated again
            # to get the merge changes take affect.
            @platform.umount(@device)
            @platform.disable_volume(@device)
            @platform.enable_volume(@device)
            # After disabling the device its link/file is literally removed:
            # checking that the device exists before proceeding.
            60.downto(0) do |try|
              break if File.blockdev?(@device)
              raise "FATAL: Device '#{@device}' was not found!" if try.zero?
              log_info "  Device '#{@device}' was not found, retrying."
              sleep 1
            end
            @platform.mount(@device, @mount_point)
          end
        end

        # Mount the local LVM snapshot
        #
        # Mount snapshot only if it's available
        # === Return
        # true if there was a snapshot to mount; false if there is not
        def mount_snapshot
          mountable = File.blockdev?(@snapshot_device)
          if mountable
            # First mount RW, in case filesystem needs log repairs (i.e. xfs)
            @platform.mount_snapshot(@snapshot_device, @snapshot_mount_point)
            # Then remount RO
            @platform.mount_snapshot(@snapshot_device, @snapshot_mount_point, :options => ['remount', 'ro'])
          end
          mountable
        end

        # Unmount the local LVM snapshot
        #
        # Skips the unmount command if there is nothing mounted.
        def umount_snapshot
          log_info "attempting to umount #{@snapshot_mount_point}"
          if Pathname.new(@snapshot_mount_point).mountpoint?
            log_info `umount #{@snapshot_mount_point}`
            raise "ERROR umounting #{@snapshot_mount_point}" unless $?.success?
            log_info "successfully umounted #{@snapshot_mount_point}"
          else
            log_info "INFO: Filesystem #{@snapshot_mount_point} does not exist - skipping umount"
          end
        end

        def initialize_stripe(devices, vg_data_percentage = 60)
          @platform.pvcreate(devices, :force => true, :yes => true)
          @platform.vgcreate(@vgname, devices)
          @platform.lvcreate(@vgname, :name => @lvname, :stripes => devices.size, :stripesize => 256, :extents => "#{vg_data_percentage}%VG")
          @platform.mkfs @device
          mount
          @platform.set_mount_point_for_device(@device, @mount_point)
        end

        def sync
          @logger.info 'syncing filesystem...'
          @platform.sync
          @logger.info 'filesystem synched.'
        end

        def clean_lvm_metadata
          # Clean up leftover metadata.  This is a hack to get around
          # leftover metadata when the lvm operations don't work.
          logger.info 'Cleaning up LVM metadata'
          FileUtils.rm_f Dir.glob('/etc/lvm/archive/*')
          FileUtils.rm_f Dir.glob('/etc/lvm/backup/*')
          FileUtils.rm_f Dir.glob('/etc/lvm/cache/.cache')
        end

        def reset_devices(devices)
          sync
          @platform.remove_mount_point_for_device(@device)
          umount @mount_point
          umount @snapshot_mount_point
          #clean_lvm_metadata
          @platform.lvchange(@device, :available => 'n', :ignore_failure => true )
          @platform.lvremove(@device, :ignore_failure => true)
          @platform.vgremove(@vgname, :ignore_failure => true)
          @platform.pvremove(devices, :force_force => true, :yes => true, :ignore_failure => true)
          clean_lvm_metadata
          FileUtils.rm_rf(@device)
        end

        def mount
          @platform.mount(@device, @mount_point, :options => 'noatime', :ignore_failure => true)
        end

        def umount(mount_point)
          @logger.info "attempting to umount #{mount_point}"
          if @platform.umount mount_point
            @logger.info "successfully umounted #{mount_point}"
          elsif File.exists?(mount_point)
            @logger.warn "failure to umount filesystem #{mount_point}"
          else
            @logger.warn "failure to umount filesystem #{mount_point} does not exist!"
          end
        end

        # 'legacy_vgrename' used to rename 11H1 DBMgr snapshot volume groups
        def legacy_vgrename(old_device, new_name)
          old_name = old_device.split('/')[2]
          @platform.pvscan
          @platform.get_volume_list.each do |vgname|
            if vgname == old_name
              @logger.info "attached volume has legacy vgname '#{old_name}', renaming to '#{new_name}'"
              @platform.lvchange(old_device, :available => 'n', :retry_num => 5, :retry_sleep => 1)
              @platform.vgrename(vgname, new_name)
            end
          end
        end

        def mount_point_check
          device = @platform.get_device_for_mount_point(@mount_point)
          raise "#{device} already exists at #{@mount_point}" if device
        end

        def unique_volume_nickname
          "#{@nickname}_#{@uuid}"
        end

      end
    end
  end
end
