#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/swift'

module RightScale::Tools::ROS
  class SoftLayerAmsterdam < SoftLayer
    register :softlayer_amsterdam
    
    protected
    
    def hostname
      "ams01"
    end
    
  end
end
