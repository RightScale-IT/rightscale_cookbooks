#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/mixin/common'
require 'rightscale_tools/platform'

module RightScale
  module Tools
    module Backup
      class Backup
        include RightScale::Tools::Common

        # Register this backup/restore implementation class; this should only be called in the defintion of subclasses.
        #
        # @param [Symbol, String] type the type of backup storage the implemantation class supports, currently +:volume+ or +:ros+
        # @param [Array<Symbol, String>] clouds the clouds this backup/restore implementation class supports; an empty array means it supports all clouds
        #
        def self.register(type, *clouds)
          RightScale::Tools::Backup.register(type, clouds, self)
        end
        private_class_method :register

        # Constructs the backup/restore object; this should only be called by subclasses and the factory.
        #
        # @param [Symbol, String] cloud the cloud this backup/restore object should support and will be used on
        # @param [String] mount_point the mount point directory where the backup/restore object will backup from or restore to
        # @param [String] nickname the nickname for the backup/restore volumes
        # @param [Hash] options optional parameters
        #  * the +:endpoint+ option specifies the ROS endpoint URL to use
        #  * the +:storage_cloud+ option specifies the ROS storage cloud to use when the type is +:ros+
        #  * the +:storage_key+ option specifies the authentication key to use when the type is +:ros+
        #  * the +:storage_secret+ option specifies the authentication secret to use when the type is +:ros+
        #  * the +:storage_container+ option specifies the storage container to use when the type is +:ros+
        #
        def initialize(cloud, mount_point, snapshot_mount_point, nickname, options)
          @cloud = cloud.to_sym
          @snapshot_mount_point = snapshot_mount_point
          @mount_point = mount_point
          @nickname = nickname
          @platform = RightScale::Tools::Platform.factory options
          @logger = logger
        end

        # Perform a backup.
        #
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the +:description+ option overrides the description of the backup
        #
        # @return [Boolean]
        #
        def backup(lineage, options = {})
          not_implemented
        end

        # Clean backups.
        #
        # This allows you a way to remove old backups.
        # This is optional and does nothing by default.
        #
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the rotation options are +:max_snapshots+, +:keep_dailies+, +:keep_weeklies+, +:keep_monthlies+, and +:keep_yearlies+
        #
        # @return [Boolean]
        #
        def cleanup(lineage, options = {})
          # no-op
        end

        # Perform a restore.
        #
        # @param [String] lineage the backup lineage to restore from
        # @param [Hash] options optional parameters
        #  * the +:timestamp+ parameter specifies the latest Unix epoch timestamp of a backup to restore from instead of the absolute latest
        #  * the +:new_size_gb+ parameter specifies a size for the restored block device to grow to
        #  * the +:iops+ parameter specifies the I/O operations per second that the volume will support, this is only used on EC2
        #
        # @return [Boolean]
        #
        def restore(lineage, options = {})
          not_implemented
        end

        # What type of backup are we
        #
        # This defaults to volume, override if you are doing something else -- like ROS.
        def backup_type
          :volume
        end

      end

      # Register a backup/restore implementation class.
      #
      # @param [Symbol, String] type the type of backup storage the implementation class supports, currently +:volume+ or +:ros+
      # @param [Symbol, String, Array, nil] this_cloud the cloud or clouds this backup/restore implementation class supports; nil means it supports all clouds
      # @param [Class] implementation backup/restore implementation class
      #
      def self.register(type, this_cloud, implementation)
        case this_cloud
        when Array
          if this_cloud.empty?
            register(type, nil, implementation)
          else
            this_cloud.each {|cloud| register(type, cloud, implementation)}
          end
        when nil
          @@implementations ||= {}
          @@implementations[type.to_sym] = implementation
        else
          @@implementations ||= {}
          @@implementations[[type.to_sym, this_cloud.to_sym]] = implementation
        end
      end

      # Factory for creating backup/restore objects.
      #
      # @param [Symbol, String] type the type of backup storage the object should support, currently +:volume+ or +:ros+
      # @param [Symbol, String] this_cloud the cloud this backup/restore object should support and will be used on
      # @param [String] mount_point the mount point directory where the backup/restore object will backup from or restore to
      # @param [String] nickname the nickname for the backup/restore volumes
      # @param [Hash] options optional parameters to pass to the backup/restore object
      #  * the +:endpoint+ option specifies the ROS endpoint URL to use
      #  * the +:storage_cloud+ option specifies the ROS storage cloud to use when the type is +:ros+
      #  * the +:storage_key+ option specifies the authentication key to use when the type is +:ros+
      #  * the +:storage_secret+ option specifies the authentication secret to use when the type is +:ros+
      #  * the +:storage_container+ option specifies the storage container to use when the type is +:ros+
      #
      # @return [RightScale::Tools::Backup::Backup] the backup/restore object
      #
      def self.factory(type, this_cloud, mount_point, snapshot_mount_point, nickname, options = {})
        implementation = @@implementations[[type.to_sym, this_cloud.to_sym]]
        implementation = @@implementations[type.to_sym] unless implementation
        raise "Unsupported type/cloud combination for backup: #{type}/#{this_cloud}" unless implementation
        implementation.new this_cloud, mount_point, snapshot_mount_point, nickname, options
      end
    end
  end
end

require 'rightscale_tools/backup/ros'
require 'rightscale_tools/backup/volume_ec2'
require 'rightscale_tools/backup/volume_multicloud'
