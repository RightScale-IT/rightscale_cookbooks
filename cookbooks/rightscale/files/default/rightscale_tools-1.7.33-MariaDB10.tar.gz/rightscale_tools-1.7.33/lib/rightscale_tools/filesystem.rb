#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'set'
require 'rightscale_tools/mixin/common'

module RightScale
  module Tools
    module FileSystem
      class FileSystem
        include RightScale::Tools::Common

        # Constructs the file system object; this should only be called by subclasses and the factory.
        #
        def initialize
          @logger = logger
        end

        # Get the name of the file system.
        #
        # @return [String] the name of the file system
        #
        def name
          not_implemented
        end

        # Get the command to make the file system.
        #
        # @return [String] the command to make the file system
        #
        def mkfs_command
          not_implemented
        end

        # Get the command to grow the file system.
        #
        # @return [String] the command to grow the file system
        #
        def growfs_command
          not_implemented
        end

        # Get type of parameter that the command to grow the file system takes. Currently, the parameter can be +:device+ or +:mount_point+.
        #
        # @return [Symbol] the type of parameter that the command to grow the file system takes
        #
        def growfs_parameter_type
          not_implemented
        end

        # Get the mount snapshot options for the file system.
        #
        # @return [Array<String>, nil] the mount snapshot options for the file system or +nil+ if there are no mount snapshot options needed
        #
        def mount_snapshot_options
          not_implemented
        end
      end

      # Factory for creating file system objects using the highest priority file system available. The priority order for file systems is: xfs, ext3.
      #
      # @return [RightScale::Tools::FileSystem::FileSystem] the file system object
      #
      def self.factory
        filesystems = IO.readlines('/proc/filesystems').map do |entry|
          entry.split
        end.reject do |entry|
          entry[0] == 'nodev'
        end.map {|entry| entry[0]}.to_set

        if filesystems.include? 'xfs'
          RightScale::Tools::FileSystem::XFS.new
        elsif filesystems.include? 'ext3'
          RightScale::Tools::FileSystem::EXT3.new
        else
          raise "Unable to find suitable filesystem support. Available filesystems: #{filesystems.inspect}"
        end
      end
    end
  end
end

require 'rightscale_tools/filesystem/xfs.rb'
require 'rightscale_tools/filesystem/ext3.rb'
