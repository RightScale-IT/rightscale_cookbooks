#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'stringio'
require 'timeout'

module RightScale
  module Tools
    module ROS
      module FragmenterMixin
        FRAGMENT_SUFFIX = '.part'
        INFO_SUFFIX = '.info'

        FRAGMENT_SIZE = 10 * 1024 * 1024 # 10 MB
        MAX_PROCESSES = 10
        MAX_RETRIES = 25
        MAX_READ = 8192
        # max expected time for chunk: for example with 100MB chunks and a min of 1 MB/s ->  (100MB)*(1/1MB/s) -> 100 sec
        # for multi-cloud transfers, 10MB chunks with min of 0.065 MB/s
        MAX_TRANSFER_TIME = FRAGMENT_SIZE / (1024 * 65)

        # Retrieve a fragmented object.
        #
        # @param [String] container the name of the container with the object
        # @param [String] filename the name of the fragmented object
        # @param [Data] data output stream to write the object to, can be nil if a block is passed
        # @param [Proc] block optional block to handle chunks of the object when they are received
        #
        def get_object_from_fragments(container, filename, data, &block) # :yields: chunk
          @logger.debug("get_object_from_fragments called with container: #{container} filename: #{filename} data: #{data.inspect} block: #{block.inspect}")
          get_object(container, filename + INFO_SUFFIX).split("\n").each do |fragment|
            get_object_from_fragment(container, fragment, data, &block)
          end
        end

        # Put a fragmented object.
        #
        # @param [String] container the name of the container to put the object in
        # @param [String] filename the name of the object
        # @param [Data] data input stream of data to put in the object
        #
        def put_object_to_fragments(container, filename, data)
          start = Time.now
          total = 0
          fragments = []
          children = []

          begin
            fragment = filename + FRAGMENT_SUFFIX + '%05d' % fragments.size
            fragments << fragment
            buffer = StringIO.new(data.read(FRAGMENT_SIZE))
            total += buffer.size
            children << Process.detach(Process.fork do
              begin
                put_object_to_fragment(container, fragment, buffer)
                Process.exit! 0
              rescue Exception => e
                @logger.error("Error uploading fragment #{fragment}... #{e}")
                @logger.error("Backtrace: #{e.backtrace}")
                @logger.close
                Process.exit! 2
              end
            end)
            if children.size >= MAX_PROCESSES
              # Wait for one of the fragments to complete.
              child = nil # reset loop condition
              child = children.detect do |kid| 
                @logger.debug("Waiting to start next fragment after #{fragment}... #{kid.inspect}")
                kid.join(1) # block for up to a second
              end until child
              @logger.debug "Fragment ended. #{child.inspect}"
              status = child.value
              if status
                raise "Uploader process #{status.pid} returned an error: #{status.exitstatus}" unless status.exitstatus == 0
                @logger.debug("PID #{status.pid} finished successfully")
              else
                puts "Somehow unable to get status from fork: #{child.inspect}, oh well."
              end
              children.delete child
              @logger.debug "Number of upload processes running is #{children.size}"
            end
          end until data.eof
          children.each do |child|
            status = child.value
            if status
              raise "Uploader process #{status.pid} returned an error: #{status.exitstatus}" unless status.exitstatus == 0
              @logger.info("PID #{status.pid} finished successfully")
            else
              puts "Somehow unable to get status from fork: #{child.inspect}, oh well."
            end
          end
          delete_stale_object_fragments(container, filename, fragments.size)

          info = StringIO.open do |info|
            fragments.each {|fragment| info << "#{fragment}\n"}
            info.string
          end
          put_object(container, filename + INFO_SUFFIX, info)

          elapsed = Time.now - start
          rate = total / (1024 * 1024 * elapsed)
          @logger.info("Content uploaded successfully in #{elapsed} seconds [#{rate} MB/s]")
        end

        def delete_stale_object_fragments(container, prefix, first_fragment)
          index = prefix.size + FRAGMENT_SUFFIX.size
          deleted = 0
          list_object_names(container, :prefix => prefix + FRAGMENT_SUFFIX) do |filename|
            if filename[index .. -1].to_i >= first_fragment
              delete_object(container, filename)
              @logger.debug("DELETING #{filename}")
              deleted += 1
            end
          end
          @logger.debug("deleted #{deleted} stale fragments") if deleted > 0
        end

        private

        def get_object_from_fragment(container, fragment, data, &block)
          buffer = StringIO.new
          error = StringIO.new
          1.upto(MAX_RETRIES) do |attempt|
            buffer.string = ''
            error.string = ''
            delay = (attempt - 1) * 2
            sleep(delay) unless delay == 0

            cmd = StringIO.open do |cmd|
              cmd << 'curl --silent --show-error --location --write-out "%{http_code}" --output /dev/stderr'
              @logger.debug("  Setting up command in get_object_from_fragment: #{cmd}")
              @logger.info("  Setting up command in get_object_from_fragment: #{cmd}")
              link = get_object_link(container, fragment)
              if link[:headers] && link[:headers].is_a?(Hash)
                link[:headers].each {|key, value| cmd << " --header '#{key}: #{value}'"}
              end
              cmd << " '#{link[:url]}'"
              cmd.string
            end

            @logger.info("Attempt #{attempt} executing: #{cmd}")

            begin
              output_read, output_write = IO.pipe
              error_read, error_write = IO.pipe
              child = Process.detach(Process.fork do
                begin
                  output_read.close
                  error_read.close
                  STDOUT.reopen output_write
                  STDERR.reopen error_write
                  Process.exec cmd
                rescue Exception => e
                  @logger.error "Error executing #{cmd}: #{e}"
                  Process.exit! 2
                end
              end)

              begin
                output_write.close
                error_write.close
                fds = [output_read, error_read]
                until fds.empty?
                  if (active_fds = IO.select(fds, nil, nil, 10)) != nil
                    active_fds[0].each do |fd|
                      begin
                        # these are swapped on purpose
                        case fd
                        when output_read
                          error << fd.readpartial(MAX_READ)
                        when error_read
                          buffer << fd.readpartial(MAX_READ)
                        end
                      rescue EOFError
                        fds.delete fd
                        fd.close
                      end
                    end
                  else
                    raise Timeout::Error, 'Read timeout'
                  end
                end
              ensure
                status = child.value
              end
            rescue Timeout::Error
              @logger.error "Timeout running #{cmd}"
              raise if attempt == MAX_RETRIES
              @logger.info "Retrying..."
              next
            rescue Exception => e
              @logger.error "Error running #{cmd}: '#{e}'"
              raise if attempt == MAX_RETRIES
              @logger.info "Retrying..."
              next
            end

            break if status.exitstatus == 0 && error.string.to_i < 300
            if error.string =~ /The requested URL returned error: ([0-9]{3})$/
              @logger.error("Error #{$1} while downloading file")
            else
              @logger.error("Error #{error.string} while downloading file")
            end
            @logger.error("Error output: '#{buffer.string}'")
            raise Timeout::Error, "Maximum retries (#{MAX_RETRIES})...aborting" if attempt == MAX_RETRIES
          end

          if block
            block.call buffer.string
          else
            data.write(buffer.string)
          end
          @logger.info("File #{fragment} downloaded")
        end

        def put_object_to_fragment(container, fragment, data)
          start = Time.now
          output = StringIO.new
          error = StringIO.new
          1.upto(MAX_RETRIES) do |attempt|
            data.rewind # Make sure IO stream is at position 0
            @logger.debug "Data for #{fragment}: Size: #{data.size} Pos:#{data.pos} EOF?:#{data.eof?}"
            output.string = ''
            error.string = ''
            delay = (attempt - 1) * 2
            unless delay == 0
              # Retry backoff with slight randomization
              delay += rand(3)  
              sleep(delay)
            end

            cmd = StringIO.open do |cmd|
              cmd << "curl --silent --show-error --location --write-out '%{http_code}' --output /dev/stderr --upload-file - --max-time #{MAX_TRANSFER_TIME}"
              cmd << " --header 'Transfer-Encoding:'"
              cmd << " --header 'Content-Length: #{data.size}'"
              link = put_object_link(container, fragment, data)
              if link[:headers] && link[:headers].is_a?(Hash)
                link[:headers].each {|key, value| cmd << " --header '#{key}: #{value}'"}
              end
              cmd << " '#{link[:url]}'"
              cmd.string
            end

            @logger.info("Attempt #{attempt} executing: #{cmd}")

            begin
              data_read, data_write = IO.pipe
              output_read, output_write = IO.pipe
              error_read, error_write = IO.pipe
              child = Process.detach(pid = Process.fork do
                begin
                  data_write.close
                  output_read.close
                  error_read.close
                  STDIN.reopen data_read
                  STDOUT.reopen output_write
                  STDERR.reopen error_write
                  Process.exec cmd
                rescue Exception => e
                  @logger.error "Error executing #{cmd}: #{e}"
                  Process.exit! 2
                end
              end)

              begin
                data_read.close
                output_write.close
                error_write.close
                ofds = [output_read, error_read]
                ifds = [data_write]

                begin
                  until ofds.empty? && ifds.empty?
                    if (active_fds = IO.select(ofds, ifds, nil, MAX_TRANSFER_TIME)) != nil
                      active_fds[0].each do |fd|
                        begin
                          # these are swapped on purpose
                          case fd
                          when output_read
                            error << fd.readpartial(MAX_READ)
                          when error_read
                            output << fd.readpartial(MAX_READ)
                          end
                        rescue EOFError
                          ofds.delete fd
                          fd.close
                        end
                      end
                      active_fds[1].each do |fd|
                        pos = data.pos
                        begin
                          pos += fd.write_nonblock(data.read)
                        rescue Errno::EINTR
                          redo
                        rescue Errno::EAGAIN, Errno::EWOULDBLOCK
                          next
                        ensure
                          data.pos = pos
                        end
                        if data.eof?
                          ifds.delete fd
                          fd.close
                        end
                      end
                    else
                      raise Timeout::Error, 'Read/write timeout'
                    end
                  end
                rescue Exception
                  begin
                    Process.kill(9, pid) if child.alive?
                  rescue Exception => e
                    @logger.warn "Error killing #{pid}: #{e}"
                  end
                  raise
                end
              ensure
                status = child.value
              end
            rescue Timeout::Error
              @logger.error "Timeout running #{cmd}"
              raise if attempt == MAX_RETRIES
              @logger.info "Retrying..."
              next
            rescue Exception => e
              @logger.error "Error running #{cmd}: '#{e}'"
              @logger.error "Backtrace: #{e.backtrace}"
              raise if attempt == MAX_RETRIES
              @logger.info "Retrying..."
              next
            end

            break if status.exitstatus == 0 && error.string.to_i < 300
            if error.string =~ /The requested URL returned error: ([0-9]{3})$/
              @logger.error("Error #{$1} while uploading file")
            else
              @logger.error("Error #{error.string} while uploading file")
            end
            @logger.error("Error output: '#{output.string}'")
            raise Timeout::Error, "Maximum retries (#{MAX_RETRIES})...aborting" if attempt == MAX_RETRIES
          end

          elapsed = Time.now - start
          rate = data.size / (1024 * 1024 * elapsed)
          @logger.info("Fragment #{fragment} uploaded successfully. Rate: #{rate} MB/s")
        end
      end
    end
  end
end
