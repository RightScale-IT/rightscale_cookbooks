#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'right_api_client'
require 'timeout'

module RightScale
  module Tools
    module API
      class Client15 < Client
        register '1.5'

        # Gets the underlying {RightApi::Client}.
        #
        # @return [RightApi::Client] the underlying {RightApi::Client}
        #
        attr_accessor :client

        def initialize(options)
          super options

          api_token = ENV['RS_API_TOKEN']
          raise 'RightScale API token environment variable RS_API_TOKEN is unset' unless api_token
          account_id, instance_token = api_token.split /:/
          api_url = "https://#{ENV['RS_SERVER']}"
          options = {
            :account_id => account_id,
            :instance_token => instance_token,
            :api_url => api_url
          }.merge options

          @client = RightApi::Client.new options
          @client.log(@logger)
        end

        def attached_devices(nickname = nil)
          volume_attachments(nickname).map do |attachment|
            attachment.show.device
          end
        end

        def volume_attachments(nickname = nil)
          attachments = @client.volume_attachments.index(:filter => ["instance_href==#{instance_href}"]).reject do |attachment|
            attachment.show.device.include? 'unknown'
          end
          attachments.reject! {|attachment| attachment.volume.show.name != nickname} if nickname
          attachments
        end

        def attachment_state(attachment)
          @client.volume_attachments(:id => attachment.href.split('/').last).show.state
        end

        def reset_attachments(nickname = nil)
          @logger.info "preparing for volume detach"
          volumes = volume_attachments(nickname).map do |attachment|
            volume = attachment.volume
            status = volume.show.status
            state = attachment_state(attachment)
            @logger.info "  volume attachment status is #{status.inspect}"

            # 15 minute timeout
            Timeout::timeout(900) do
              while (state != 'attached' || status != 'in-use')
                @logger.info "  reseting - waiting for volume to be attached and in-use before detaching - status is #{state} / #{status}"
                sleep 2
                status = volume.show.status
                state = attachment_state(attachment)
              end
            end

            @logger.info "  volume attachment status is #{status.inspect}"
            @logger.info "  performing volume detach..."
            attachment.destroy
            while ((status = volume.show.status) == 'in-use')
              @logger.info "resetting - waiting for volume to detach - status is: #{status}"
              sleep 2
            end
            volume
          end

          # Delete the volumes from the cloud
          @logger.info "preparing for volume destroy"
          volumes.each do |volume|
            status = volume.show.status
            @logger.info "  volume status is #{status.inspect}"

            # 15 minute timeout
            Timeout::timeout(900) do
              while (status != 'available' && status != 'error')
                @logger.info "  reseting - waiting for volume to be available for deletion - status is #{status}"
                sleep 2
                status = volume.show.status
              end
            end

            @logger.info "  volume status is #{status.inspect}"

            # Rescue 422 errors with following error message "Volume still has 'n' dependent snapshots"
            # and add warning statements to indicate volume deletion failure. This is a workaround for
            # Rackspace Open Cloud limitation where a volume cannot be destroyed if it has dependent snapshots.
            begin
              @logger.info "  performing volume destroy..."
              volume.destroy
            rescue RightApi::Exceptions::ApiException => e
              http_code = e.message.match("HTTP Code: ([0-9]+)")[1]
              if http_code == "422"
                @logger.warn "#{e.message}" if e.message =~ /Volume still has \d+ dependent snapshots/
              else
                raise
              end
            end
          end
        end

        # Finds the latest volume backup.
        #
        # @param [String] lineage the backup lineage
        # @param [Boolean] from_master only find master backups
        # @param [String] timestamp latest timestamp in epoch seconds that the backup should have
        #
        # @return [RightApiClient::Resource] the latest backup
        #
        def find_latest_backup(lineage, from_master = nil, timestamp = nil)
          # the 1.5 API does not do an inclusive search for timestamp so increment by 1
          timestamp = timestamp ? Time.at(timestamp.to_i + 1) : Time.now
          filter = [ "latest_before==#{timestamp.utc.strftime('%Y/%m/%d %H:%M:%S %z')}", "committed==true", "completed==true" ]
          filter << "from_master==true" if from_master
          backup = @client.backups.index(:lineage => lineage, :filter => filter )
          raise "FATAL: no backups found in lineage: '#{lineage}' from_master: '#{from_master}' timestamp: '#{timestamp}'; please check the lineage and try again." if backup.empty?
          backup.first.show
        end

        def instance_href
          @instance_href ||= @client.get_instance.href
        end

        def cloud_href
          @cloud_href ||= @client.get_instance.links.detect {|link| link['rel'] == 'cloud'}['href']
        end
      end
    end
  end
end
