#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'right_aws'

module RightScale
  module Tools
    module ROS
      class S3 < ROS
        register :s3, :ec2

        include CommonMixin
        include FragmenterMixin

        def initialize(key, secret, options)
          super key, secret, options

          ros_options = {
            :logger => @logger,
            :endpoint_url => options[:endpoint]
          }

          @ros = RightAws::S3Interface.new(key, secret, ros_options)
        end

        def create_container(container, options = {})
          @ros.create_bucket(container, options)
        end

        def create_container_if_not_exists(container, options = {})
          # If we're running on EC2 create a bucket in the same aws cloud.
          meta_data_cache = '/var/spool/cloud/meta-data-cache.rb'
          require meta_data_cache if File.exists? meta_data_cache

          # Default to us-east
          location = case ENV['EC2_PLACEMENT_AVAILABILITY_ZONE'] || ''
                     when /eu-/
                       'eu'
                     when /us-west/
                       'us-west-1'
                     when /southeast/
                       'ap-southeast-1'
                     when /northeast/
                       'ap-northeast-1'
                     end
          options[:location] = location if location

          if @ros.list_all_my_buckets.detect {|b| b[:name] == container}
            false
          else
            @logger.info "storage container #{container} not found, creating."
            create_container(container, options)
            true
          end
        end

        def get_object(container, filename, data = nil, fragmented = false, &block)
          if fragmented
            get_object_from_fragments(container, filename, data, &block)
          elsif data
            @ros.get(container, filename) {|chunk| data.write(chunk)}
          elsif block
            @ros.get(container, filename, &block)
          else
            object = @ros.get(container, filename)
            object ? object[:object] : nil
          end
        end

        def get_object_link(container, filename)
          {:url => @ros.get_link(container, filename)}
        end

        def get_latest_object_name(container, filename, fragmented = false)
          results = []
          @ros.incrementally_list_bucket(container, :marker => '', :prefix => filename) do |result|
            result[:contents].each do |file|
              if fragmented
                results << file[:key].gsub(/#{Regexp.escape(INFO_SUFFIX)}$/, '') if file[:key] =~ /#{Regexp.escape(INFO_SUFFIX)}$/
              else
                results << file[:key]
              end
            end
          end
          result = results.sort.last
          raise "No object found in container '#{container}' with prefix '#{filename}'" unless result
          result
        end

        def put_object(container, filename, data, fragmented = false)
          if fragmented
            case data
            when String
              data = StringIO.new data
            end
            put_object_to_fragments(container, filename, data)
          else
            @ros.put(container, filename, data)
          end
        end

        def put_object_link(container, filename, data = nil)
          {:url => @ros.put_link(container, filename)}
        end

        def list_object_names(container, options = {}, &block)
          results = []
          options[:marker] = '' unless options.has_key? :marker
          @ros.incrementally_list_bucket(container, options) do |result|
            result[:contents].each do |file|
              block.call file[:key] if block
              results << file[:key]
            end
          end
          results
        end

        def delete_object(container, filename)
          @ros.delete(container, filename)
        end

        def delete_container(container)
          @ros.delete_bucket(container)
        end
      end
    end
  end
end
