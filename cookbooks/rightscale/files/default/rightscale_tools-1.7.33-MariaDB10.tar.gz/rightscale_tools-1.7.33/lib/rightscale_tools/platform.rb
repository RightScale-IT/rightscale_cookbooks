#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/mixin/common'

module RightScale
  module Tools
    module Platform

      class Platform
        include RightScale::Tools::Common

        attr_reader :platform, :version

        def initialize(platform, version, options = {})
          @logger = logger
          @platform = platform
          @version = version
          @cloud = options[:cloud]
          @hypervisor = options[:hypervisor]
        end

        def create_partition(device, first, last)
          not_implemented
        end

        def destroy_partition(device)
          not_implemented
        end

        def get_lock_file_name(name)
          not_implemented
        end

        def get_device_for_mount_point(mount_point)
          not_implemented
        end

        def set_mount_point_for_device(device, mount_point)
          not_implemented
        end

        def remove_mount_point_for_device(device)
          not_implemented
        end

        def get_root_device
          not_implemented
        end
        
        def make_device_label(device, label_type)
          not_implemented
        end

        def get_device_partition_info(device)
          not_implemented
        end

        def get_current_devices
          not_implemented
        end

        def get_device_type
          not_implemented
        end

        def get_next_devices(count, exclusions = [])
          not_implemented
        end

        def mount(mount_point_or_device, mount_point = nil, options = {})
          not_implemented
        end

        def mount_snapshot(device, mount_point, options = {})
          not_implemented
        end

        def umount(mount_point_or_device)
          not_implemented
        end

        def lvcreate(devices, options = {})
          not_implemented
        end

        def lvchange(device, options = {})
          not_implemented
        end

        def lvremove(device, options = {})
          not_implemented
        end

        def pvcreate(devices, options = {})
          not_implemented
        end

        def pvremove(devices, options = {})
          not_implemented
        end

        def pvscan(options = {})
          not_implemented
        end

        def vgcreate(vgname, devices, options = {})
          not_implemented
        end

        def vgremove(device, options = {})
          not_implemented
        end

        def vgrename(old_name, new_name, options = {})
          not_implemented
        end

        def vgs(devices, options = {})
          not_implemented
        end

        def mkfs(device, options = {})
          not_implemented
        end

        def sync
          not_implemented
        end

        def enable_volume(device)
          not_implemented
        end

        def disable_volume(device)
          not_implemented
        end

        def get_devices_for_volume(device)
          not_implemented
        end

        def grow_device(mount_point, vgname, options = {})
          not_implemented
        end

        def scan_for_attachments
          not_implemented
        end

      end

      def self.factory(options = {})
        platform = `lsb_release -is`.chomp
        version = `lsb_release -rs`.chomp

        RightScale::Tools::Platform::Linux.new(platform, version, options)
      end
    end
  end
end

require 'rightscale_tools/platform/linux.rb'
