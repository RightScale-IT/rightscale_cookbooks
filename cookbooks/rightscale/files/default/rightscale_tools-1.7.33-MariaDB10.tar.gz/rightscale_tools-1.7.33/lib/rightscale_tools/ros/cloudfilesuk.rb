#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/cloudfiles'

module RightScale::Tools::ROS
  class CloudFilesUK < CloudFiles
    register :cloudfilesuk, :cloud_files_uk, :rackspaceuk

    def initialize(key, secret, options)
      options[:endpoint] ||= "https://lon.auth.api.rackspacecloud.com/v1.0"
      super key, secret, options
    end
  end
end
