#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

module RightScale
  module Tools
    module ROS
      module CommonMixin
        def get_object_to_file(container, filename, local_filename, fragmented = false)
          File.open(local_filename, "w") do |file|
            get_object(container, filename, file, fragmented)
          end
        end

        def put_object_from_file(container, filename, local_filename, fragmented = false)
          File.open(local_filename, "r") do |file|
            put_object(container, filename, file, fragmented)
          end
        end

      end
    end
  end
end
