#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/fog'

module RightScale
  module Tools
    module ROS
      class Google < Fog

      register :google, :gc, :google

      EXPIRES=240 # signature expires after 4min

      # The url dir.files.get_https_url trick from will not work here as it does with S3
      # This is due to the signature including the http method (i.e.PUT vs. GET).
      # So we have to generate our own url and signature for the header
      # For more information see https://developers.google.com/storage/docs/reference/v1/developer-guidev1
      def put_object_link(container, filename, data = nil)
        begin
          dir = get_directory(container)
          expires = Time.now.to_i + EXPIRES


          #url = dir.files.get_https_url(filename, expires)

          @logger.debug "filename: #{filename}"

          # Leverage Fog routines to construct the url and signature
          params = {
            :method   => 'PUT',
            :host     => "commondatastorage.googleapis.com",
            :path     => "#{container}/#{filename}",
            :headers  => {
              'Date' => ::Fog::Time.now.to_date_header,
              'Host' => 'commondatastorage.googleapis.com'
            }
          }

          # Construct URL
          url = https_url(params, expires)
          @logger.debug "Computed URL=#{url}"

          # Calculate signature
          signature = @ros.signature(params)
          @logger.debug "Calculated Signature=#{signature}"

        rescue Exception => e
          @logger.error "FAILURE: #{e.message}"
          @logger.error "BACKTRACE:\n#{e.backtrace}"
          raise e
        end

        # Create url hash for curl with required Authorization header
        headers = params[:headers].merge!('Authorization' => "GOOG1 #{@config[:google_storage_access_key_id]}:#{signature}")

        {
          :url => url,
          :headers => headers
        }
      end

#XXX merge duplicated code from put_object_link
      def get_object_link(container, filename)
        begin
          dir = get_directory(container)
          expires = Time.now.to_i + EXPIRES

          @logger.debug "filename: #{filename}"

          # Leverage Fog routines to construct the url and signature
          params = {
            :method   => 'GET',
            :host     => "commondatastorage.googleapis.com",
            :path     => "#{container}/#{filename}",
            :headers  => {
              'Date' => ::Fog::Time.now.to_date_header,
              'Host' => 'commondatastorage.googleapis.com'
            }
          }
          # Construct URL
          url = https_url(params, expires)
          @logger.debug "Computed URL=#{url}"

          # Calculate signature
          signature = @ros.signature(params)
          @logger.debug "Calculated Signature=#{signature}"

        rescue Exception => e
          @logger.error "FAILURE: #{e.message}"
          @logger.error "BACKTRACE:\n#{e.backtrace}"
          raise e
        end

        # Create url hash for curl with required Authorization header
        headers = params[:headers].merge!('Authorization' => "GOOG1 #{@config[:google_storage_access_key_id]}:#{signature}")

        {
          :url => url,
          :headers => headers
        }

      end

      protected

        def config_hash(key, secret, ros_options)
          {
            :provider                         => 'Google',
            :google_storage_secret_access_key => secret,
            :google_storage_access_key_id     => key,
            :port => 443,
            :scheme => 'https'
          }
        end

      private

        def https_url(params, expires)
          params[:path] = CGI.escape(params[:path]).gsub('%2F', '/')
          "https://#{params[:host]}/#{params[:path]}"
        end

      end
    end
  end
end
