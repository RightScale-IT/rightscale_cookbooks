#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/block_device/lvm'

module RightScale
  module Tools
    module BlockDevice
      class LVMSoftlayer < LVMRackspace
        register :lvm, :softlayer

        PARTITION_ENDINGS_OFFSET=512

        def create(options = {})
          mount_point_check

          data_device = get_data_device
          if @platform.get_current_devices.include?(data_device)
            initialize_stripe([data_device])
          else
            on_create_error(e)
          end
        end

        def reset
          device = get_data_device
          reset_devices([device])
        end

        protected

        def get_data_device
          "/dev/xvdc"
        end

        def on_create_error(e)
          raise "Unable to get data drive information. Please be sure you are using a SoftLayer 'Storage' image. #{e.message}"
        end

        def create_before_restore?(level)
          true
        end
      end
    end
  end
end
