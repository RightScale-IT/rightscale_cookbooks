#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

# XXX: evil hack to make evil hacks work that are not working because of colliding evil hacks!
ActiveSupport.send(:remove_const, 'CoreExtensions') if defined? ActiveSupport::CoreExtensions

require 'right_rackspace'

module RightScale
  module Tools
    module ROS
      class CloudFiles < ROS
        register :cloudfiles, :cloud_files, :rackspace, :"rackspace-ng"

        include CommonMixin
        include FragmenterMixin

        def initialize(key, secret, options)
          super key, secret, options

          ros_options = {
            :logger => @logger,
            :auth_endpoint => options[:endpoint]
          }
          ros_options[:use_snet] = options[:rackspace_use_snet] if @cloud == :rackspace

          @ros = Rightscale::Rackspace::CloudFilesInterface.new(key, secret, ros_options)
        end

        def create_container(container, options = {})
          @ros.create_container(container, options)
        end

        def create_container_if_not_exists(container, options = {})
          existed = false
          @ros.incrementally_list_containers do |containers|
            existed = containers.detect {|c| c['name'] == container}
          end
          if existed
            false
          else
            @logger.info "storage container #{container} not found, creating."
            create_container(container, options)
            true
          end
        end

        def get_object(container, filename, data = nil, fragmented = false, &block)
          if fragmented
            get_object_from_fragments(container, filename, data, &block)
          elsif data
            @ros.get_object(container, filename) {|chunk| data.write(chunk)}
          else
            @ros.get_object(container, filename, &block)
          end
        end

        def get_object_link(container, filename)
          @ros.get_object_link(container, filename)
        end

        def get_latest_object_name(container, filename, fragmented = false)
          results = []
          @ros.incrementally_list_objects(container) do |resultz|
            resultz.each do |result|
              if fragmented
                results << result['name'].gsub(/#{Regexp.escape(INFO_SUFFIX)}$/, '') if result['name'] =~ /^#{Regexp.escape(filename)}.*#{Regexp.escape(INFO_SUFFIX)}$/
              else
                results << result['name'] if result['name'] =~ /^#{Regexp.escape(filename)}.*$/
              end
            end
          end
          result = results.sort.last
          raise "No object found in container '#{container}' with prefix '#{filename}'" unless result
          result
        end

        def put_object(container, filename, data, fragmented = false)
          case data
          when String
            data = StringIO.new data
          end
          if fragmented
            put_object_to_fragments(container, filename, data)
          else
            @ros.put_object(container, filename, data.read)
          end
        end

        def put_object_link(container, filename, data = nil)
          @ros.put_object_link(container, filename)
        end

        def list_object_names(container, options = {}, &block)
          results = []
          @ros.incrementally_list_objects(container) do |resultz|
            resultz.each do |result|
              if options.has_key? :prefix
                if result['name'] =~ /^#{Regexp.escape(options[:prefix])}/
                  block.call result['name'] if block
                  results << result['name']
                end
              else
                block.call result['name'] if block
                results << result['name']
              end
            end
          end
          results
        end

        def delete_object(container, filename)
          @ros.delete_object(container, filename)
        end

        def delete_container(container)
          @ros.delete_container(container)
        end
      end
    end
  end
end
