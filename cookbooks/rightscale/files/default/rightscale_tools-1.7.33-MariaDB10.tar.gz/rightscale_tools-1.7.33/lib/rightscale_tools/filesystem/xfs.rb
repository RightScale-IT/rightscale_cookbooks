#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

module RightScale
  module Tools
    module FileSystem
      class XFS < FileSystem
        def name
          "xfs"
        end

        def mkfs_command
          "mkfs.xfs"
        end

        def growfs_command
          "xfs_growfs"
        end

        def growfs_parameter_type
          :mount_point
        end

        def mount_snapshot_options
          ["nouuid"]
        end
      end
    end
  end
end
