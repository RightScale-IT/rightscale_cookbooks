#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'right_api_client'
require 'timeout'

require 'rightscale_tools/backup/volume'

module RightScale
  module Tools
    module Backup
      class VolumeMultiCloud < Volume
        register :volume, :cloudstack, :eucalyptus, :openstack, :azure,
          :"rackspace-ng", :ec2_gateway, :gc, :google

        def initialize(cloud, mount_point, snapshot_mount_point, nickname, options = {})
          super(cloud, mount_point, snapshot_mount_point, nickname, options)

          @api = RightScale::Tools::API.factory('1.5', options)
        end

        protected

        def backup_volume(lineage, description, from_master)
          # Setup backup options
          hrefs = @api.volume_attachments(@nickname).map do |attachment|
            attachment.show.href
          end
          time_suffix = "_"+Time.now.strftime("%Y%m%d%H%M")
          params = {
            :backup => {
              :lineage => lineage,
              :name => @nickname+"_"+time_suffix,
              :description => description,
              :volume_attachment_hrefs => hrefs
            }
          }
          params[:from_master] = from_master if from_master

          # Create volume backup
          new_backup = @api.client.backups.create(params)
          while (completed = new_backup.show.completed) != true
            @logger.info "waiting for backup to complete - completed is #{completed}"
            sleep 2
          end
          @logger.info "Backup completed"
          new_backup.update(:backup => {:committed => "true"})

          true
        end
        
        def cleanup_volume(lineage, rotation_options)

          # Perform snapshot cleanup
          if rotation_options[:keep_last] == "-1"
            @logger.info "Skipping cleanup of backups"
          else
            # Rescue 422 errors with error message of "Volume Snapshot status
            # must be available or error" and add warning statements to indicate
            # snapshot deletion failure.  Use case is when multiple backups on
            # the same lineages occur and a pending snapshot is listed to be
            # deleted from the 'keep' criteria.  Seen on Rackspace Open Cloud.
            begin
              @logger.info "Performing cleanup of backups"
              params = {:cloud_href => @api.cloud_href, :lineage => lineage}
              params.merge! rotation_options
              @api.client.backups.cleanup(params)
            rescue RightApi::Exceptions::ApiException => e
              http_code = e.message.match("HTTP Code: ([0-9]+)")[1]
              if http_code == "422" &&
                e.message =~ /Volume Snapshot status must be available or error/
                @logger.warn e.message
              else
                raise
              end
            end

          end

          true          
        end

        # Restore a backup and waits for restore to complete.
        #
        # @param [String] lineage Lineage from which backup must be restored.
        # @param [Hash] options Optional parameters for backup restore.
        #
        # @return [Boolean] true if restore completed successfully
        #
        # @raise [RestClient::Exception] Attachment timeouts (error code: 504)
        # are rescued and retried.
        # @raise [RestClient::Exception] Other restore issues.
        # @raise [RuntimeError] If restore status is "failed".
        #
        def restore_volume(lineage, options = {})
          timestamp = options[:timestamp]
          from_master = options[:from_master]
          restore_volume_type = options[:volume_type]

          @logger.info "Restoring volume backup" +
            " from lineage: #{lineage.inspect}" +
            " timestamp: #{timestamp.inspect}" +
            " from_master: #{from_master}" +
            " volume_type: #{restore_volume_type.inspect}"

          # Find snapshot based on given options
          backup = @api.find_latest_backup(
            lineage,
            from_master,
            timestamp
          )
          devices_size_before_restore = @platform.get_current_devices.size

          params = {
            :instance_href => @api.instance_href,
            :backup => {
              :name => @nickname
            }
          }

          if @cloud == :"rackspace-ng"
            volume_types = @api.client.volume_types.index
            volume_type = volume_types.detect do |type|
              type.name == restore_volume_type
            end
            params[:backup][:volume_type_href] = volume_type.href
          end

          # Restore stripe of volumes
          # 15 Minute timeout for restore to complete
          Timeout::timeout(900) do
            begin
              restore = backup.restore(params)
            rescue RestClient::Exception => e
              if e.http_code == 504
                @logger.warn "timeout waiting for attachment -" +
                  " #{e.message}... retrying..."
                sleep 2
                retry
              end
              raise
            end

            begin
              status, summary = restore.show.summary.split(':', 2).first
              while status != "completed"
                raise "restore failed: #{summary}" if status == "failed"
                @logger.info "waiting for restore to complete -" +
                  " status is #{status}"
                sleep 2
                status, summary = restore.show.summary.split(':', 2).first
              end
            rescue RestClient::Exception => e
              if e.http_code == 504
                @logger.warn "timeout waiting for attachment -" +
                  " #{e.message}... retrying..."
                sleep 2
                retry
              end
              raise
            end
          end

          @platform.scan_for_attachments

          true
        end
      end
    end
  end
end
