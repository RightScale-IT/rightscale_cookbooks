#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/mixin/common'

module RightScale
  module Tools
    module ROS
      class ROS
        include RightScale::Tools::Common

        # Register this storage cloud ROS implementation class; this should only be called in the definition of subclasses.
        #
        # @param [Array<Symbol, String>] storage_clouds storage cloud names that this ROS implementation class supports
        #
        def self.register(*storage_clouds)
          RightScale::Tools::ROS.register(storage_clouds, self)
        end
        private_class_method :register

        # Constructs the storage cloud ROS object; this should only be called by subclasses and the factory.
        #
        # @param [String] key the API key or user name used to authenticate with the storage cloud
        # @param [String] secret the API secret key or password used to authenticate with the storage cloud
        # @param [Hash] options optional parameters
        #  * the +:cloud+ option specifies the cloud the instance is running on
        #  * the +:endpoint+ option specifies the endpoint URL to use
        #  * RightScale::ROS::CloudFiles takes the boolean option +:rackspace_use_snet+
        #
        def initialize(key, secret, options)
          raise 'Missing ROS key' unless key && !key.empty?
          raise 'Missing ROS secret' unless secret && !secret.empty?
          set_cloud(options)
          @logger = logger
        end

        # Creates a container.
        #
        # @param [String] container the name of the container to create
        # @param [Hash] options optional parameters
        #
        def create_container(container, options = {})
          not_implemented
        end

        # Creates a container if it does not already exist.
        #
        # @param [String] container the name of the container to create
        # @param [Hash] options optional parameters
        #
        # @return [Boolean] true if the container was created, false otherwise
        #
        def create_container_if_not_exists(container, options = {})
          not_implemented
        end

        # Gets an object. If passed a block, chunks of the object are yielded to the block when they are received.
        # If fragmented is true either data or a block must be passed.
        #
        # @param [String] container the name of the container with the object
        # @param [String] filename the name of the object
        # @param [Data] data optional output stream to write the object to
        # @param [Boolean] fragmented retrieve a fragmented object if true
        # @param [Proc] block optional block to handle chunks of the object when they are received
        #
        # @return [String, nil] if neither data or a block are passed, the contents of the object are returned as a String.
        #
        def get_object(container, filename, data = nil, fragmented = false, &block) # :yields: chunk
          not_implemented
        end

        # Gets an object and writes it to a local file.
        #
        # @param [String] container the name of the container with the object
        # @param [String] filename the name of the object
        # @param [String] local_filename the name of the local file to write to
        # @param [Boolean] fragmented retrieve a fragmented object if true
        #
        def get_object_to_file(container, filename, local_filename, fragmented = false)
          not_implemented
        end

        # Get the retrieval hyperlink for an object.
        #
        # @param [String] container the name of the container with the object
        # @param [String] filename the name of the object
        #
        # @return [Hash] the retrieval hyperlink for the object
        #
        def get_object_link(container, filename)
          not_implemented
        end

        # Get the name of the latest object name.
        #
        # @param [String] container the name of the container with the object
        # @param [String] filename the beginning of the name of the object
        # @param [Boolean] fragmented retrieve a fragmented object if true
        #
        # @return [String] the latest object name
        #
        def get_latest_object_name(container, filename, fragmented = false)
          not_implemented
        end

        # Put an object.
        #
        # @param [String] container the name of the container to put the object in
        # @param [String] filename the name of the object
        # @param [String, Data] data string or input stream of data to put in the object
        # @param [Boolean] fragmented separate the object into 10MB fragments if true
        #
        def put_object(container, filename, data, fragmented = false)
          not_implemented
        end

        # Put an object that is read from a local file.
        #
        # @param [String] container the name of the container to put the object in
        # @param [String] filename the name of the object
        # @param [String] local_filename the name of the local file to read from
        # @param [Boolean] fragmented separate the object into 10MB fragments if true
        #
        def put_object_from_file(container, filename, local_filename, fragmented = false)
          not_implemented
        end

        # Get the put hyperlink for an object.
        #
        # @param [String] container the name of the container to put the object in
        # @param [String] filename the name of the object
        # @param [String, Data] data string or input stream of data to put in the object
        #
        # @return [Hash] the put hyperlink for the object
        #
        def put_object_link(container, filename, data = nil)
          not_implemented
        end

        # List the names of objects in a container.
        #
        # @param [String] container the name of the container
        # @param [Hash] options optional parameters
        #  * the option +:prefix+ is a string that returned objects should start with
        # @param [Proc] block optional block to handle object names as they are retrieved
        #
        # @return [Array<String>] list of object names in the container
        #
        def list_object_names(container, options = {}, &block) # :yields: name
          not_implemented
        end

        # Delete an object from a container.
        #
        # @param [String] container the name of the container to delete the object from
        # @param [String] filename the name of the object
        #
        def delete_object(container, filename)
          not_implemented
        end

        # Deletes extra fragments of a fragmented object.
        #
        # @param [String] container the name of the container to delete fragments from
        # @param [String] prefix the name of the fragmented object
        # @param [Integer] first_fragment the number of the first fragment to delete
        #
        def delete_stale_object_fragments(container, prefix, first_fragment)
          not_implemented
        end
        
        # Delete a container.
        #
        # @param [String] container the name of the container to delete
        #
        def delete_container(container)
          not_implemented
        end

        protected
        
        # Stores the name of the cloud the instance is running on
        #
        # @param [Hash] options optional parameters
        #  * the +:cloud+ option specifies the cloud the instance is running on
        #
        def set_cloud(options)
          @cloud = options[:cloud]
          @cloud = @cloud.to_sym if @cloud
        end
        
      end

      # Register a storage cloud ROS implementation class.
      #
      # @param [Symbol, String, Array<Symbol, String>] storage_cloud storage cloud names that the ROS implementation class supports
      # @param [Class] implementation storage cloud ROS implementation class
      #
      def self.register(storage_cloud, implementation)
        case storage_cloud
        when Array
          storage_cloud.each {|cloud| register(cloud, implementation)}
        else
          @@implementations ||= {}
          @@implementations[storage_cloud.to_sym] = implementation
        end
      end

      # Factory for creating storage cloud ROS objects.
      #
      # @param [Symbol, String] storage_cloud storage cloud name that the ROS object should support
      # @param [String] key the API key or user name used to authenticate with the storage cloud
      # @param [String] secret the API secret key or password used to authenticate with the storage cloud
      # @param [Hash{Symbol => Symbol, String, Number, Boolean}] options optional parameters to pass to the ROS object
      #  * the +:cloud+ option specifies the cloud the instance is running on
      #  * the +:endpoint+ option specifies the endpoint URL to use
      #  * RightScale::ROS::CloudFiles takes the boolean option +:rackspace_use_snet+
      #
      # @return [RightScale::Tools::ROS::ROS] the storage cloud ROS object
      #
      def self.factory(storage_cloud, key, secret, options = {})
        case storage_cloud
        when String
          storage_cloud = storage_cloud.downcase
        end
        implementation = @@implementations[storage_cloud.to_sym]
        raise "Unsupported ROS storage cloud: #{storage_cloud}" unless implementation
        implementation.new key, secret, options
      end
    end
  end
end

require 'rightscale_tools/ros/mixin/common_mixin.rb'
require 'rightscale_tools/ros/mixin/fragmenter_mixin.rb'
require 'rightscale_tools/ros/azure'
require 'rightscale_tools/ros/cloudfiles'
require 'rightscale_tools/ros/cloudfilesuk'
require 'rightscale_tools/ros/s3'
require 'rightscale_tools/ros/swift'
require 'rightscale_tools/ros/softlayer'
require 'rightscale_tools/ros/softlayer_singapore'
require 'rightscale_tools/ros/softlayer_amsterdam'
require 'rightscale_tools/ros/fog'
require 'rightscale_tools/ros/local'
require 'rightscale_tools/ros/google'
