#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/fog'
require 'fog'

module RightScale
  module Tools
    module ROS
      class Swift < Fog
        register :swift, :openstack, :hp

        def initialize(key, secret, options)
          super key, secret, options
        end

        def put_object_link(container, filename, data = nil)
          object_link(container, filename)
        end

        def get_object_link(container, filename)
          object_link(container, filename)
        end

      protected

        def config_hash(key, secret, ros_options)
          # Tenant id is included in key
          tenant_id, key = key.split(':')
          @logger.info "Calculating tenant id from key: #{tenant_id}"

          hash = {
            :provider => "HP",
            :hp_account_id => key,
            :hp_secret_key => secret,
            :hp_auth_uri => ros_options[:endpoint],
            :hp_tenant_id => tenant_id
          }

          # There is no way to differentiate openstack and hp cloud from the
          # running instance. ros_options[:storage_cloud] is set by the
          # block_device/devices/default/backup/primary/cloud input in the ST.
          unless ros_options[:storage_cloud] == "hp"
            hash.merge!({:hp_use_upass_auth_style => true})
          end

          hash
        end

      private

        # The url dir.files.get_https_url is not supported for swift as it is with S3
        # We must get the file URL plus add the authentication token to the headers
        def object_link(container, filename)
          begin
            {
              :url => get_file_url(container, filename),
              :headers => get_headers(@config)
            }
          rescue Exception => e
            @logger.error "FAILURE: #{e.message}"
            @logger.error "BACKTRACE:\n#{e.backtrace}"
            raise e
          end
        end

        # Call Keystone authentication service for X-Auth-Token
        # NOTE: not all swift services have a Keystone auth service
        # for more information see
        # https://api-docs.hpcloud.com/hpcloud-object-storage/1.0/content/differences-object-api.html
        #
        # XXX: how dow we detect swift vs swift with keystone?
        def get_headers(config)
          # Call the control services authentication
          options = @config.merge!(:hp_service_type => "object-store")
          begin
            credentials = ::Fog::HP.authenticate_v2(options, {})
          rescue Exception => e
            @logger.error("Authentication Failure")
            raise e
          end
          @logger.debug "credentials=#{credentials.inspect}"
          {'X-Auth-Token' => credentials[:auth_token]}
        end

        # Get file url with or without snet host uri
        def get_file_url(container, filename)
          @logger.debug "filename: #{filename}"
          dir = get_directory(container)

          # Manipulate URL with or without snet
          uri = URI.parse(dir.files.get_url(filename))
          host = uri.host
          url = "#{uri.scheme}://#{host}:#{uri.port}#{uri.path}"
          @logger.debug "Computed URL=#{url}"
          url
        end

      end
    end
  end
end
