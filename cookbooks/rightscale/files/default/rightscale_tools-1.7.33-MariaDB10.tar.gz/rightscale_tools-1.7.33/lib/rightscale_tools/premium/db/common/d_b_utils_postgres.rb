#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rubygems'
require 'system_timer'

require File.dirname(__FILE__) +  '/../common/d_b_utils.rb'

module RightScale 
  class DBUtilsPostgres
    include RightScale::DBUtils

    DBMountPoint = "/mnt/pgsql"
    MASTER_FILE="rs_snapshot_position.yaml"
    attr_reader :rep_user, :rep_pass, :conf_filename, :data_directory
    
    def initialize(params = {})
      ### Variables
      # PostgreSQL user and password to use at the slave DB to perform replication
      # This needs to match the deltaset that configure the master DB...
      # This user needs superuser access
      @rep_user=params[:rep_user].to_s.downcase
      @rep_pass=params[:rep_pass]

      # if running outside runrightscripts.rb, this variable is unset.
      ENV['RS_DISTRO'] = `lsb_release -is`.chomp.downcase unless ENV['RS_DISTRO']
      # Default position of the postgresql.conf configuration file
      case ENV['RS_DISTRO'].to_s
        when "ubuntu"; 
          @conf_filename = "/etc/postgresql/9.0/main/postgresql.conf"
          @data_directory = "/var/lib/postgresql/9.0/main"
          @service_name = "postgresql"
        when "centos"; 
          @conf_filename = "/var/lib/pgsql/9.0/data/postgresql.conf"
          @data_directory = "/var/lib/pgsql/9.0/data"
          @service_name = "postgresql-9.0"
        else; 
          raise "FATAL: Unsupported Distro: #{ENV['RS_DISTRO']}"
      end    
    end


    ### Miscelaneous  ###

    # Util function that returns true if Major (x.x) version numbers are the same
    # Intended for the results of "select version from pg_catalog.version();" to be passed as version params.
    def compatible_versions?(db_version, db_arch, snapshot_version, snapshot_arch)
      raise "ERROR: unexpected version format for db_version param (#{db_version})" unless db_version =~ /(\d+\.)(\d+)(\.\d+)*/
      raise "ERROR: unexpected version format for snapshot_version param (#{snapshot_version})" unless snapshot_version =~ /(\d+\.)(\d+)(\.\d+)*/
      # compare version array containing only Major number
      ( (db_version.split('.').slice(0,2) == snapshot_version.split('.').slice(0,2)) && (db_arch == snapshot_arch) ) 
    end

    def db_info(host=nil)
      _host = (host!=nil) ? "-h #{host}" : ""

      res = `env PGCONNECT_TIMEOUT=30 psql -h /var/run/postgresql -U postgres #{_host} -qt -c "select version from pg_catalog.version()"`
      raise RemoteExecException.new(host,$?,res) if $? != 0
      res_split = res.split(' ')

      _db_info = Hash.new
      _db_info['version'] = res_split[1]
      _db_info['arch'] = res_split[res_split.length-1]

      return _db_info
    end

    def detect_if_master?(host=nil)
      _host = (host!=nil) ? "-h #{host}" : ""

      # Returns nothing if master
      res = `env PGCONNECT_TIMEOUT=30 psql -h /var/run/postgresql -U postgres #{_host} -qt -c "SELECT pg_last_xlog_receive_location()"`.strip
      raise RemoteExecException.new(host,$?,res) if $? != 0
      return $res == ""
    end
    
    # Attempts to start the DB several times (sleeping in between)
    def ensure_db_started(host=nil)      
      success = false
      5.times {|attempt|
        success = ensure_db_started_internal(host)
        break if success 
        puts "Error starting DB: attempt #{attempt}. Trying again..."
        attempt +=1
        sleep 2
      }
      
      if( success == true )
        puts "Database started OK."
      else
        puts "Error starting DB. Giving up..."
        raise RemoteExecException.new(nil,$?,"Error starting DB") 
      end  
      success      
    end

    def ensure_db_ready
      # 1- Check if the host has PostgreSQL running 
      raise "DB was not up and couldn't be started. Aborting..." if  ensure_db_started == false
      30.times {|attempt|
        res = `env PGCONNECT_TIMEOUT=30 psql -h /var/run/postgresql -U postgres -q -c "SELECT NOW()"`
        break if $? == 0
        puts "Error: DB not ready yet. Attempt #{attempt}. Trying again..."
        attempt +=1
        sleep 10
      }

      if( $? == 0 )
        puts "Database is ready."
      else
        puts "Error: DB has still not completed recovery. Giving up..."
        raise RemoteExecException.new(nil,$?,"Timeout while waiting for recovery.")
      end
      $? == 0
    end
    
    # It executes a service postgresql stop on the specified node
    # It returns the output of the status command on success or an exception if failure
    def db_service_stop( host=nil )
      return execute_db_service_command( host , "stop" )
    end

    # It executes a service postgresql start on the specified node (if it's not running already)
    # It returns the output of the status command on success or an exception if failure
    def db_service_start( host=nil )
      return execute_db_service_command( host , "start" )
    end

    # It executes a service postgresql 'command' on the specified node
    # It returns the output of the status command after performing the action (or a RemoteExecException if an error or inconsistency is detected
    def execute_db_service_command( host , action )
      if host != nil
        if `ssh #{host} lsb_release -i`.downcase =~ /ubuntu/
          host_os = "ubuntu"
        else
          host_os = "centos"
        end
      else
        host_os = ENV['RS_DISTRO']
      end

      if host_os == 'ubuntu'
        pgsql_service = "postgresql"
        pgsql_started_tag = "Running clusters: \d+"
        pgsql_stopped_tag = "Running clusters:$"
      else
        pgsql_service = "postgresql-9.0"
        pgsql_started_tag = "is running"
        pgsql_stopped_tag = "is stopped"
      end

      exec_prefix = (host!=nil) ? "ssh #{host} ":"" 
        action_res = `#{exec_prefix} service #{pgsql_service} #{action}`
      action_errno = $?
      status_res = `#{exec_prefix} service #{pgsql_service} status`
  
      if( action == "stop" )
        #If we stopped the DB but the status says it is running, throw an exception with the output of the initial action
        raise RemoteExecException.new(host,action_errno,"Error stopping DB:\n"+action_res) if status_res =~ /#{pgsql_started_tag}/ 
      elsif (action == "start")
        #If we started the DB but the status says it is stopped, throw an exception with the output of the initial action
        raise RemoteExecException.new(
          host,
          action_errno,
          "Error starting DB:\n#{action_res}"
        ) if status_res =~ /#{pgsql_stopped_tag}/
      end
      #if the action succesded (or it is another not stop/start action), just return the result of the status
      return status_res
    end

    # Reconfigure the replication parameters.
    def reconfigure_replication_info(newmaster_host)
      File.open("/mnt/pgsql/9.0/main/recovery.conf", File::CREAT|File::TRUNC|File::RDWR) do |f|
        f.puts("standby_mode='on'\nprimary_conninfo='host=#{newmaster_host} user=#{@rep_user} password=#{@rep_pass}'\ntrigger_file='/mnt/pgsql/9.0/main/recovery.trigger'")
      end
      return $? == 0
    end  

    def reconfig_conf()
      source_dir="/opt/rightscale/postgres-conf"
      `#{source_dir}/makemyconf.rb --template=#{source_dir}/postgresql.conf.erb --attributes=#{source_dir}/postgres_attributes.rb --attributes=#{source_dir}/postgres_tuning.rb --ebs`
      return $? == 0
    end

    def rsync_db(newmaster_host)
      puts `ssh #{newmaster_host} "env PGCONNECT_TIMEOUT=30 psql -h /var/run/postgresql -U postgres -c \\\"SELECT pg_start_backup('sync')\\\""`
      puts `rsync -aqz #{newmaster_host}:/mnt/pgsql/9.0/main/ /mnt/pgsql/9.0/main/ --exclude postmaster.pid --exclude pg_log`
      puts `ssh #{newmaster_host} "env PGCONNECT_TIMEOUT=30 psql -h /var/run/postgresql -U postgres -c \\\"SELECT pg_stop_backup()\\\""`
      return $? == 0
    end

    def write_trigger()
      File.open("/mnt/pgsql/9.0/main/recovery.trigger", File::CREAT|File::TRUNC|File::RDWR) do |f|
        f.puts(" ")
      end
    end
 
    ### Database manipulation 

    # Checks if the setup of a given host is in initial/pristine condition
    def is_db_pristine?( dbhost ) 
      host = (dbhost!=nil) ? "-h #{dbhost} ":""
      res = `env PGCONNECT_TIMEOUT=30 psql #{host} -h /var/run/postgresql -U postgres -qt -c "select count(*) from pg_catalog.pg_database d WHERE d.datname NOT IN ('postgres', 'template0', 'template1')"`.strip
      raise RemoteExecException.new(dbhost,$?,res) if $? != 0
      return res == "0"
    end

    ########################## PRIVATE ##########################
    private
    
    # Tries to bring up the DB once (in case it's stopped)
    # Returns true for success (i.e., the DB is left running) or false if it couldn't be started)
    # There's a similar call (ensure_db_started) that tries to start it more than once
    def ensure_db_started_internal(host=nil)
      host ="localhost" if host == nil
      status_res = execute_db_service_command( host , "status" )
      return true if status_res =~ /Running clusters: \d+/ || status_res =~ /\s.+is running/
      execute_db_service_command( host , "start" )
      return true
    end
    
  end
end
