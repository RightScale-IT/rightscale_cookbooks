#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/backup/volume'

module RightScale
  module Tools
    module Backup
      class VolumeEC2 < Volume
        register :volume, :ec2

        def initialize(cloud, mount_point, snapshot_mount_point, nickname, options)
          super(cloud, mount_point, snapshot_mount_point, nickname, options)

          @api = RightScale::Tools::API.factory('1.0', options)
        end

        protected

        # Restore a backup and waits for restore to complete.
        #
        # @param [String] lineage Lineage from which backup must be restored.
        # @param [Hash] options Optional parameters for backup restore.
        #
        # @return [Boolean] true if restore completed successfully
        #
        # @raise [RuntimeError] If restore fails.
        #
        def restore_volume(lineage, options = {})
          timestamp = options[:timestamp]
          new_size_gb = options[:new_size_gb]
          from_master = options[:from_master]
          iops = options[:iops]

          @logger.info "Restoring volume backup" +
            " from lineage: #{lineage.inspect}" +
            " timestamp: #{timestamp.inspect}" +
            " new_size_gb: #{new_size_gb.inspect}" +
            " from_master: #{from_master}" +
            " iops: #{iops.inspect}"

          # Find snapshot based on given options
          latest_backups = @api.find_latest_ebs_backup(
            lineage,
            from_master,
            timestamp
          )
          if latest_backups.nil?
            @logger.info "No existing snapshot found" +
              " for the specified lineage. Aborting ..."
            exit(-1)
          end

          # Restore stripe of volumes
          @logger.info "Restoring... #{latest_backups.inspect}"
          if new_size_gb
            new_size_gb_float =
              (new_size_gb.to_f / latest_backups.size.to_f).ceil
          end
          @logger.debug "New size: #{new_size_gb_float}"

          devices = @platform.get_next_devices(latest_backups.size)
          @logger.info "Restore to devices: #{devices.inspect}"
          latest_backups.zip devices do |snapshot, device|
            # create volume from snap
            create_result = @api.create_volume_from_snap(
              snapshot["aws_id"],
              @nickname,
              new_size_gb_float,
              iops
            )
            if create_result.nil?
              raise "FATAL: error occurred -" +
                " create_volume_from_snap(#{snapshot['aws_id']}," +
                " #{@nickname}, #{new_size_gb_float})"
            end
            attach_result = @api.attach_volume_retry(
              create_result['aws_id'],
              device
            )
          end

          # Wait for devices to attach, after completing ALL the api calls
          devices.each { |device| @api.wait_for_attachment(device) }
          true
        end

        def backup_volume(lineage, description, from_master)

          # Setup backup options
          devices = get_devices_for_volume.to_a
          @logger.info "Backing up the following devices: #{devices.inspect}"
          create_opts = {
              :lineage => lineage,
              :description => description,
              :devices => devices.map {|device| @api.map_device_for_ec2(device)}
          }
          create_opts.merge({ :from_master => from_master }) if from_master
          @logger.info "Backup options: #{create_opts.inspect}"

          # Create EBS backup
          result = @api.create_ebs_backup(create_opts)
          raise "FATAL: unable to create snapshots!" if result.nil?
          aws_ids = result['aws_ids']
          raise "FATAL: result not recognized #{result}" unless aws_ids.is_a?(Array)
          aws_ids.each do |snap|
            @api.update_snapshot(snap, "committed")
          end
          @logger.info "Snapshot complete"

          true
        end

        def cleanup_volume(lineage, rotation_options)

          # Perform snapshot cleanup
          if rotation_options[:max_snapshots] == "-1"
            @logger.info "Skipping cleanup of EBS snapshots"
          else
            @logger.info "Performing cleanup of snapshots"
            options = {
              :keep_last => rotation_options[:max_snapshots],
              :dailies => rotation_options[:keep_dailies],
              :weeklies => rotation_options[:keep_weeklies],
              :monthlies => rotation_options[:keep_monthlies],
              :yearlies => rotation_options[:keep_yearlies]
            }
            @logger.info "Cleanup options: #{options.inspect}"
            lst = @api.cleanup_ebs_backups(lineage,options)
            @logger.info "Cleanup resulted in deleting #{lst.length} snapshots : #{lst.inspect}"
          end
          true
        end

        private

        def get_devices_for_volume
          device_name = @platform.get_device_for_mount_point(@mount_point)
          @logger.debug "Device name: #{device_name}"
          list = @platform.get_devices_for_volume(device_name)
          @logger.debug "Physical device list: #{list}"
          list << device_name if list.empty?
          list
        end

      end
    end
  end
end
