#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/api'
require 'rightscale_tools/block_device/lvm'

module RightScale
  module Tools
    module BlockDevice
      class LVMEC2 < LVM
        register :lvm, :ec2

        include LVMAPIMixin

        def initialize(cloud, mount_point, nickname, uuid, options)
          super(cloud, mount_point, nickname, uuid, options)

          @api = RightScale::Tools::API.factory('1.0', options)
          @backup[:primary] = RightScale::Tools::Backup.factory(:volume, @cloud, @mount_point, @snapshot_mount_point, unique_volume_nickname, options)
        end

        def create(options = {})
          mount_point_check

          stripe_count, volume_size, vg_data_percentage = check_create_options(options)

          reset if options[:force]

          devices = @platform.get_next_devices(stripe_count)
          each_volume_size = (volume_size.to_f / stripe_count.to_f).ceil
          devices.each do |device|
            volume = @api.create_volume(unique_volume_nickname, each_volume_size, options[:iops])
            raise volume unless volume['aws_id']
            @api.attach_volume_retry(volume['aws_id'], device)
          end
          devices.each {|device| @api.wait_for_attachment(device)}

          initialize_stripe(devices,vg_data_percentage)
        end
      end
    end
  end
end
