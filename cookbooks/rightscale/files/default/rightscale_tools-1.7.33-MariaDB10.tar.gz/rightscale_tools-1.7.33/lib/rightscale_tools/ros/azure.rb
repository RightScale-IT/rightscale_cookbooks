#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'right_cloud_api'
require 'cloud/azure/storage/manager'

module RightScale
  module Tools
    module ROS
      class Azure < ROS
        register :azure

        include CommonMixin
        include FragmenterMixin

        AZURE_STORAGE_API_VERSION = "2012-02-12"

        def initialize(key, secret, options)
          options[:endpoint] ||= "https://#{key}.blob.core.windows.net"
          super key, secret, options

          ros_options = {
            :api_version => AZURE_STORAGE_API_VERSION,
            :logger => @logger
          }
          @ros = RightScale::CloudApi::Azure::Storage::Manager.new(key, secret, options[:endpoint], ros_options)
        end

        def create_container(container, options = {})
          @ros.CreateContainer(:Container => container)
        end

        def create_container_if_not_exists(container, options = {})
          params = {}
          marker = nil
          begin
            params[:Marker] = marker if marker
            results = @ros.ListContainers(params)["EnumerationResults"]
            containers = results["Containers"]
            if containers
              containers = containers["Container"]
              containers = [containers] unless containers.kind_of? Array
              exists = containers.index { |result| result["Name"] == container }
            end
            marker = results["NextMarker"]
          end until exists || marker == nil

          unless exists
            @logger.info "storage container #{container} not found, creating."
            create_container(container, options)
            true
          else
            false
          end
        end

        def get_object(container, filename, data = nil, fragmented = false, &block)
          if fragmented
            get_object_from_fragments(container, filename, data, &block)
          elsif data
            chunk = @ros.GetBlob(:Container => container, :Blob => filename)
            data.write(chunk)
          elsif block
            block.call @ros.GetBlob(:Container => container, :Blob => filename)
          else
            @ros.GetBlob(:Container => container, :Blob => filename)
          end
        end

        def get_object_link(container, filename)
          catch ROS_AZURE_OBJECT_LINK do
            @ros.GetBlob(:Container => container, :Blob => filename, :options => {
              :after_routine_callback => method(:ros_azure_object_link).to_proc
            })
          end
        end

        def get_latest_object_name(container, filename, fragmented = false)
          params = {:Container => container, :Prefix => filename}
          marker = nil
          results = []
          begin
            params[:Marker] = marker if marker
            resultz = @ros.ListBlobs(params)["EnumerationResults"]
            blobs = resultz["Blobs"]
            if blobs
              blobs = blobs["Blob"]
              blobs = [blobs] unless blobs.kind_of? Array
              blobs.each do |result|
                blob = result["Name"]
                if fragmented
                  results << blob[0 .. -INFO_SUFFIX.size - 1] if blob.end_with? INFO_SUFFIX
                else
                  results << blob
                end
              end
            end
            marker = resultz["NextMarker"]
          end until marker == nil
          result = results.sort.last
          raise "No object found in container '#{container}' with prefix '#{filename}'" unless result
          result
        end

        def put_object(container, filename, data, fragmented = false)
          if fragmented
            put_object_to_fragments(container, filename, data)
          else
            @ros.PutBlob(:Container => container, :Blob => filename, :BlobType => 'BlockBlob', :body => data, :headers => {'content-type' => 'application/octet-stream'})
          end
        end

        def put_object_link(container, filename, data = nil)
          catch ROS_AZURE_OBJECT_LINK do
            @ros.PutBlob(:Container => container, :Blob => filename, :BlobType => 'BlockBlob', :body => data, :headers => {'content-type' => 'application/octet-stream'}, :options => {
              :after_routine_callback => method(:ros_azure_object_link).to_proc
            })
          end
        end

        def list_object_names(container, options = {}, &block)
          params = {:Container => container}
          params[:Prefix] = options[:prefix] if options.has_key? :prefix
          marker = nil
          results = []
          begin
            params[:Marker] = marker if marker
            resultz = @ros.ListBlobs(params)["EnumerationResults"]
            blobs = resultz["Blobs"]
            if blobs
              blobs = blobs["Blob"]
              blobs = [blobs] unless blobs.kind_of? Array
              results += blobs.map do |result|
                blob = result["Name"]
                block.call blob if block
                blob
              end
            end
            marker = resultz["NextMarker"]
          end until marker == nil
          results
        end

        def delete_object(container, filename)
          @ros.DeleteBlob(:Container => container, :Blob => filename)
        end

        def delete_container(container)
          @ros.DeleteContainer(:Container => container)
        end

      private
        ROS_AZURE_OBJECT_LINK = :ros_azure_object_link

        def ros_azure_object_link(args)
          if args[:routine].kind_of? RightScale::CloudApi::RequestAnalyzer
            data = args[:manager].data
            uri = data[:connection][:uri].dup
            request = data[:request][:instance]
            uri.path = request.path
            throw ROS_AZURE_OBJECT_LINK, {
              :url => uri.to_s,
              :headers => request.headers.reject { |_, value| value.empty? }
            }
          end
        end
      end
    end
  end
end
