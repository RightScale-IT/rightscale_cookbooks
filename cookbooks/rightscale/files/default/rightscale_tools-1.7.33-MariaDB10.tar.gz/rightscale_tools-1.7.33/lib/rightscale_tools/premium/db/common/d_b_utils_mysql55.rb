#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rubygems'
require 'mysql'
require 'system_timer'

require File.dirname(__FILE__) +  '/../common/d_b_utils.rb'
require File.dirname(__FILE__) +  '/../common/d_b_utils_mysql.rb'

module RightScale
  class DBUtilsMysql55 < RightScale::DBUtilsMysql
    
    def get_os_service_values(host)
      
      if host != nil
        if `ssh #{host} lsb_release -i`.downcase =~ /ubuntu/
          host_os = "ubuntu"
        else
          host_os = "centos"
        end
      else
        host_os = ENV['RS_DISTRO']
      end
      
      if host_os == 'ubuntu'
        {
        :mysql_service => "mysql",
        :mysql_started_tag1 => "Threads",
        :mysql_started_tag2 => "start/running",
        :mysql_stoped_tag1 => "MySQL is stopped",
        :mysql_stoped_tag2 => "stop/waiting"
        }
      else
        {
        :mysql_service => "mysqld", # MySQL 5.1 used "mysql"
        :mysql_started_tag1 => "MySQL running",
        :mysql_started_tag2 => "mysqld\s.+is running",
        :mysql_stoped_tag1 => "mysqld\s.+is stopped",
        :mysql_stoped_tag2 => "MySQL is stopped"
        }
      end
    end
    
  end
end
