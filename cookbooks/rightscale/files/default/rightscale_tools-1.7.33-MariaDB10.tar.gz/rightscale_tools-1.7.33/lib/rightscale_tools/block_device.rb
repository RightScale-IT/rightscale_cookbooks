#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/platform'

module RightScale
  module Tools
    module BlockDevice
      class BlockDevice
        include RightScale::Tools::Common

        # Register this block device implmentation class; this should only be called in the definition of subclasses.
        #
        # @param [Symbol, String] type the type of block device this implementation supports, currently only +:lvm+
        # @param [Array<Symbol, String>] clouds the clouds this block device implementation supports
        #
        def self.register(type, *clouds)
          RightScale::Tools::BlockDevice.register(type, clouds, self)
        end
        private_class_method :register

        # Constructs the block device object; this should only be called by subclasses and the factory.
        #
        # @param [Symbol, String] cloud the cloud this block device should support and will be used on
        # @param [String] mount_point the mount point directory where the block device object will mount to
        # @param [String] nickname the nickname for the block device volume
        # @param [String] uuid some unique identifier for the block device volume (since nicknames may not be unique)
        # @param [Hash] options optional parameters
        #  * the +:primary_endpoint+ option specifies the ROS endpoint URL to use if the primary storage type is +:ros+
        #  * the +:primary_storage_cloud+ option specifies the ROS storage cloud to use if the primary storage type is +:ros+
        #  * the +:primary_storage_key+ option specifies the authentication key to use when the primary storage type is +:ros+
        #  * the +:primary_storage_secret+ option specifies the authentication secret to use when the primary storage type is +:ros+
        #  * the +:primary_storage_container+ option specifies the storage container to use when the primary storage type is +:ros+
        #  * the +:secondary_endpoint+ option specifies the ROS endpoint URL to use for secondary storage
        #  * the +:secondary_storage_cloud+ option specifies the ROS storage cloud to use for secondary storage
        #  * the +:secondary_storage_key+ option specifies the authentication key to use for secondary storage
        #  * the +:secondary_storage_secret+ option specifies the authentication secret to use for secondary storage
        #  * the +:secondary_storage_container+ option specifies the storage container to use for secondary storage
        #  * the +:hypervisor+ option specifies the hypervisor that the instance is running under
        #
        def initialize(cloud, mount_point, nickname, uuid, options)
          @mount_point = mount_point
          @nickname = nickname
          raise "ERROR: you must pass a nickname for your block device." unless @nickname
          @uuid = uuid
          raise "ERROR: you must pass a uuid for your block device." unless @uuid
          raise "ERROR: you must pass a string value for UUID." unless @uuid.is_a?(String)
          @platform = RightScale::Tools::Platform.factory options
          @cloud = cloud.to_sym
          @logger = logger
          @backup_lock_file = @platform.get_lock_file_name("block_device_backup_#{@mount_point.gsub('/', '_')}.lock")
        end

        # Creates and mounts the block device.
        #
        # @param [Hash] options optional parameters
        #  * the +:stripe_count+ option specifies the number of volumes to use in an LVM stripe
        #  * the +:volume_size+ option specifies the total size of the block device volume
        #  * the +:force+ option specifies that {#reset} should be called before creating
        #  * the +:iops+ parameter specifies the I/O operations per second that the volume will support, this is only used on EC2
        #
        def create(options = {})
          not_implemented
        end

        # Takes a snapshot of the block device. This must be called before {#backup}, {#primary_backup}, or {#secondary_backup}.
        #
        # On some configurations, this actually takes the backup and the backup method is a no-op.
        # This can only be done on primary backups.  The backup method must also be fast, since the application
        # will be locked during this time.
        #
        # @param [Symbol] level the level of backup to perform, can be +:primary+ or +:secondary+
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the +:description+ option overrides the description of the backup
        #  * the rotation options are +:max_snapshots+, +:keep_dailies+, +:keep_weeklies+, +:keep_monthlies+, and +:keep_yearlies+
        #
        def snapshot(level, lineage = nil, options = {})
          not_implemented
        end

        # Performs a primary or secondary backup of the last snapshot. This must only be called after {#snapshot} has been called.
        #
        # @param [Symbol] level the level of backup to perform, can be +:primary+ or +:secondary+
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the +:description+ option overrides the description of the backup
        #  * the rotation options are +:max_snapshots+, +:keep_dailies+, +:keep_weeklies+, +:keep_monthlies+, and +:keep_yearlies+
        #
        def backup(level, lineage, options = {})
          not_implemented
        end

        # Performs a primary backup of the last snapshot. This must only be called after {#snapshot} has been called.
        #
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the +:description+ option overrides the description of the backup
        #  * the rotation options are +:max_snapshots+, +:keep_dailies+, +:keep_weeklies+, +:keep_monthlies+, and +:keep_yearlies+
        #
        def primary_backup(lineage, options = {})
          backup(:primary, lineage, options)
        end

        # Performs a secondary backup of the last snapshot. This must only be called after {#snapshot} has been called.
        #
        # @param [String] lineage the backup lineage to backup to
        # @param [Hash] options optional parameters
        #  * the +:description+ option overrides the description of the backup
        #  * the rotation options are +:max_snapshots+, +:keep_dailies+, +:keep_weeklies+, +:keep_monthlies+, and +:keep_yearlies+
        #
        def secondary_backup(lineage, options = {})
          backup(:secondary, lineage, options)
        end

        # Performs a primary or secondary restore.
        #
        # @param [Symbol] level the level of backup to perform, can be +:primary+ or +:secondary+
        # @param [String] lineage the backup lineage to restore from
        # @param [Hash] options optional parameters
        #  * the +:force+ parameter specifis that {#reset} should be called before restoring
        #  * the +:timestamp+ parameter specifies the latest Unix epoch timestamp of a backup to restore from instead of the absolute latest
        #  * the +:vg_data_percentage+ specifies how much of the restored block device is available for data
        #  * the +:new_size_gb+ specifies a size for the restored block device to grow to
        #  * the +:iops+ parameter specifies the I/O operations per second that the volume will support, this is only used on EC2
        #
        def restore(level, lineage, options = {})
          not_implemented
        end

        # Performs a primary restore.
        #
        # @param [String] lineage the backup lineage to restore from
        # @param [Hash] options optional parameters
        #  * the +:force+ parameter specifis that {#reset} should be called before restoring
        #  * the +:timestamp+ parameter specifies the latest Unix epoch timestamp of a backup to restore from instead of the absolute latest
        #  * the +:vg_data_percentage+ specifies how much of the restored block device is available for data
        #  * the +:new_size_gb+ specifies a size for the restored block device to grow to
        #  * the +:iops+ parameter specifies the I/O operations per second that the volume will support, this is only used on EC2
        #
        def primary_restore(lineage, options = {})
          @logger.debug("Doing primary restore for lineage: #{lineage} and options: #{options.inspect}")
          restore(:primary, lineage, options)
        end

        # Performs a secondary restore.
        #
        # @param [String] lineage the backup lineage to restore from
        # @param [Hash] options optional parameters
        #  * the +:force+ parameter specifis that {#reset} should be called before restoring
        #  * the +:timestamp+ parameter specifies the latest Unix epoch timestamp of a backup to restore from instead of the absolute latest
        #  * the +:vg_data_percentage+ specifies how much of the restored block device is available for data
        #  * the +:new_size_gb+ specifies a size for the restored block device to grow to
        #  * the +:iops+ parameter specifies the I/O operations per second that the volume will support, this is only used on EC2
        #
        def secondary_restore(lineage, options = {})
          restore(:secondary, lineage, options)
        end

        # Unmounts and removes the block device.
        #
        def reset
          not_implemented
        end
      end

      # Register a block device implementation class.
      #
      # @param [Symbol, String] type the type of block device this implementation supports, currently only +:lvm+
      # @param [Symbol, String, Array<Symbol, String>] this_cloud the cloud or clouds this block device implementation supports
      # @param [Class] implementation block device implementation class
      #
      def self.register(type, this_cloud, implementation)
        case this_cloud
        when Array
          this_cloud.each {|cloud| register(type, cloud, implementation)}
        else
          @@implementations ||= {}
          @@implementations[[type.to_sym, this_cloud.to_sym]] = implementation
        end
      end

      # Factory for creating block device objects.
      #
      # @param [Symbol, String] type the type of block device the object should support, currently only +:lvm+
      # @param [Symbol, String] this_cloud the cloud this block device object should support and will be used on
      # @param [String] mount_point the mount point directory where the block device object will mount to
      # @param [String] nickname the nickname for the block device volume
      # @param [String] uuid some unique identifier for the block device volume (since nicknames may not be unique)
      # @param [Hash] options optional parameters to pass to the block device object
      #  * the +:primary_endpoint+ option specifies the ROS endpoint URL to use if the primary storage type is +:ros+
      #  * the +:primary_storage_cloud+ option specifies the ROS storage cloud to use if the primary storage type is +:ros+ (this is currently only used on Rackspace and SoftLayer and when the hypervisor is KVM)
      #  * the +:primary_storage_key+ option specifies the authentication key to use when the primary storage type is +:ros+
      #  * the +:primary_storage_secret+ option specifies the authentication secret to use when the primary storage type is +:ros+
      #  * the +:primary_storage_container+ option specifies the storage container to use when the primary storage type is +:ros+
      #  * the +:secondary_endpoint+ option specifies the ROS endpoint URL to use for secondary storage
      #  * the +:secondary_storage_cloud+ option specifies the ROS storage cloud to use for secondary storage
      #  * the +:secondary_storage_key+ option specifies the authentication key to use for secondary storage
      #  * the +:secondary_storage_secret+ option specifies the authentication secret to use for secondary storage
      #  * the +:secondary_storage_container+ option specifies the storage container to use for secondary storage
      #  * the +:hypervisor+ option specifies the hypervisor that the instance is running under
      #
      # @return [RightScale::Tools::BlockDevice::BlockDevice] the block device object
      #
      def self.factory(type, this_cloud, mount_point, nickname, uuid, options = {})
        raise 'Missing type' unless type
        raise 'Missing this_cloud' unless this_cloud
        implementation = @@implementations[[type.to_sym, this_cloud.to_sym]]
        raise "Unsupported type/cloud combination for block device: #{type}/#{this_cloud}" unless implementation
        options[:cloud] = this_cloud
        implementation.new(this_cloud, mount_point, nickname, uuid, options)
      end
    end
  end
end

require 'rightscale_tools/block_device/lvm_ec2'
require 'rightscale_tools/block_device/lvm_multicloud'
require 'rightscale_tools/block_device/lvm_rackspace'
require 'rightscale_tools/block_device/lvm_softlayer'
