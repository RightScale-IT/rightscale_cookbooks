#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rightscale_tools/ros/cloudfiles'

module RightScale::Tools::ROS
  class SoftLayer < CloudFiles
    register :softlayer, :softlayer_dallas

    def initialize(key, secret, options)
      set_cloud(options)
      @logger = logger
      options[:endpoint] ||= default_endpoint
      super key, secret, options
    end
    
    protected
    
    def hostname
      "dal05"
    end
    
    def default_endpoint
      if @cloud == :softlayer
        # Use private network endpoint
        @logger.info "Using private network for transfer"
        "https://#{hostname}.objectstorage.service.networklayer.com/auth/v1.0/"
      else
        # Use public network endpoint
        @logger.info "Using public network for transfer"
        "https://#{hostname}.objectstorage.softlayer.net/auth/v1.0/"
      end
    end
    
  end
end
