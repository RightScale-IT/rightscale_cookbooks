#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

require 'rest_client'
require 'cgi'
require 'json'
require 'system_timer'

require 'rightscale_tools/platform'

class RestClient::Request
  alias_method :orig_default_headers, :default_headers

  def default_headers
    headers = orig_default_headers
    headers[:accept_encoding] = nil
    headers
  end
end

module RightScale
  module Tools
    module API
      class Client10 < Client
        register '1.0'

        def initialize(options)
          super options

          RestClient.log = @logger

          @url = ENV['RS_API_URL']
          raise 'RightScale API URL environment variable RS_API_URL is unset' unless @url
          @params = {:api_version => 1.0}
          # Let's wait a max of 15 secs for a snapshot call to finish...and bail out if it doesn't happen.
          @snapshot_timeout = 15
          @platform = RightScale::Tools::Platform.factory options
        end

        def create_volume(nickname, size, iops)
          params = {
            :nickname => nickname,
            :size => size,
            :description => 'Created by RightScale Tools.'
          }.merge @params
          params[:aws_iops] = iops if iops
          @logger.info "calling create_ebs_volume with parameters: #{params.inspect}"
          body = RestClient.post(@url + '/create_ebs_volume.js', params)
          @logger.info "create_ebs_volume returned: #{body}"
          JSON.load(body)
        rescue RestClient::Exception => e
          @logger.error e.response
          raise
        end

        def attached_devices(nickname = nil)
          volume_attachments(nickname).
            map {|attachment| attachment['aws_device']}.
            map {|mapped_device| unmap_device_for_ec2(mapped_device)}
        end

        def attach_volume(volume_id, device)
          mapped_device = map_device_for_ec2(device)
          params = {:aws_id => volume_id, :device => mapped_device}.merge @params
          @logger.info "calling attach_ebs_volume with parameters: #{params.inspect}"
          body = RestClient.put(@url + '/attach_ebs_volume.js', params)
          @logger.info "attach_ebs_volume returned: #{body}"
          JSON.load(body)
        rescue RestClient::Exception => e
          @logger.error e.response
          raise
        end

        def attach_volume_retry(volume_id, device, seconds = 200)
          retry_call(seconds) {attach_volume(volume_id, device)}
        end

        # Deletes a volume given its aws_id. the wait parameter, specifies if we need to
        # keep on attempting to deleting it in case it's still 'in-use'
        def delete_volume(volume_id, wait = true)
          params = {:aws_id => volume_id, }.merge @params
          @logger.info "calling delete_ebs_volume with parameters: #{params.inspect}"
          request_uri = @url + '/delete_ebs_volume.js?' + requestify(params)
          success = false
          20.times do |attempt|
            begin
              body = RestClient.delete request_uri
              @logger.info "delete_ebs_volume returned: #{body}"
              break success = true
            rescue Exception => e
              @logger.info "exception deleting volume: #{e}; retrying"
            end
            sleep 5
          end
          raise "couldn't delete volume #{volume_id}" unless success
        end

        def detach_volume(device)
          mapped_device = map_device_for_ec2(device)
          params = {:device => mapped_device}.merge @params
          @logger.info "calling detach_ebs_volume with parameters: #{params.inspect}"
          body = RestClient.put(@url + '/detach_ebs_volume.js', params)
          @logger.info "detach_ebs_volume returned: #{body}"
          JSON.load(body)
        rescue RestClient::Exception => e
          @logger.error e.response
          raise
        end

        def detach_volume_retry(device, seconds = 200)
          retry_call(seconds) {detach_volume(device)}
        end

        def volume_attachments(nickname = nil)
          @logger.info "calling ec2_ebs_volumes with parameters: #{@params.inspect}"
          request_uri = @url + '/ec2_ebs_volumes.js?' + requestify(@params)
          body = RestClient.get(request_uri)
          @logger.info "ec2_ebs_volumes returned: #{body}"
          attachments = JSON.load(body)
          attachments.reject! {|attachment| attachment['nickname'] != nickname} if nickname
          attachments
        rescue RestClient::Exception => e
          @logger.error e.response
          raise
        end

        def wait_for_attachment(device)
          @logger.info "waiting for device #{device} to attach"
          success = false
          300.times do |attempt|
            break success = true if File.blockdev?(device)
            sleep 1
          end
          raise "timeout while waiting for #{device} to attach" unless success
          @logger.info "#{device} attached; waiting for the API to agree"
          success = false
          mapped_device = map_device_for_ec2(device)
          90.times do |attempt|
            attachment = volume_attachments.detect {|attachment| attachment['aws_device'] == mapped_device}
            status = attachment['aws_attachment_status'] if attachment
            @logger.info "waited #{attempt * 10}s for device #{device} to attach, status: #{status || 'unknown'}"
            break success = true if status == 'attached'
            sleep 10
          end
          raise 'timeout while waiting for device to attach' unless success
        end

        def wait_for_detachment(device, attempts = 120)
          success = false
          attempts.times do |attempt|
            break success = true if !File.blockdev? device
            sleep 1
          end
          @logger.warn "block device #{device} did not detach after #{attempts} seconds" unless success
          success
        end

        def reset_attachments(nickname = nil)
          devices = attached_devices(nickname)
          volumes = devices.map {|device| detach_volume_retry(device)}
          devices.each {|device| wait_for_detachment(device)}

          # wait for detach using API call
          timeout = 0
          @logger.info "waiting up to 900 seconds for instance to detach all volumes with the nickname: #{nickname}"
          while timeout < 900 && !(found_attachment = attached_devices(nickname)).empty?
            @logger.info "detaching #{found_attachment.inspect} waited #{timeout}s"
            timeout += sleep 10
          end
          @logger.warn 'instance still has volumes attached after 900 seconds' unless timeout < 900

          volumes.each {|volume| delete_volume(volume['aws_id'], false) if volume}
        end

        # Calls to the EC2 API expect devices to be in form /dev/sdX and may err out otherwise
        # /dev/sda maps -> /dev/xvde because RHEL messed up, but this behavior may change later
        def map_device_for_ec2(device)
          case @platform.platform
          when /^RedHat/, "CentOS"
            if @platform.version.to_f.between?(6.1, 6.2)
              # see https://bugzilla.redhat.com/show_bug.cgi?id=729586
              # xvda - xvdd are reserved, mappings get offset by 4 letters
              device_number = /\/xvd([a-z]+)$/.match(device)[1]
              mapped_device_number = ("a"..device_number).to_a[-5]
              # Do a sub starting from right so we don't replace
              # the e in /dev/xxx when we shouldn't
              device.
                sub("/xvd", "/sd").
                reverse.
                sub(device_number.reverse, mapped_device_number.reverse).
                reverse
            else
              device.sub("/xvd", "/sd")
            end
          else
            device.sub("/xvd", "/sd")
          end
        end

        def unmap_device_for_ec2(mapped_device)
          case @platform.platform
          when /^RedHat/, "CentOS"
            if @platform.version.to_f.between?(6.1, 6.2)
              mapped_device_number = /\/sd([a-z]+)$/.match(mapped_device)[1]
              device_number = (mapped_device_number.."zz").to_a[4]
              mapped_device.
                sub("/sd", "/xvd").
                reverse.
                sub(mapped_device_number.reverse, device_number.reverse).
                reverse
            else
              mapped_device.sub("/sd", "/" + @platform.get_device_type)
            end
          else
            mapped_device.sub("/sd", "/" + @platform.get_device_type)
          end
        end

        #
        # Restore functions
        #
        def find_latest_ebs_backup(lineage, from_master = nil, timestamp = nil)
          Timeout::timeout(60) do
            seconds = 0
            while true
              begin
                params = {:lineage => lineage}.merge @params
                params[:from_master] = from_master if from_master
                params[:timestamp] = timestamp if timestamp
		@logger.info "Making a RightScale API call to find the latest ebs backup lineage = '#{lineage}', from_master = '#{from_master}', timestamp = '#{timestamp}'"
                request_uri = @url + "/find_latest_ebs_backup.js" + "?" + requestify(params)
                body = RestClient.get(request_uri)
                json = body.nil? ? nil : JSON.load(body)
                break json
              rescue RestClient::Exception => e
                if e.http_code == 422
                  seconds += 10
                  @logger.info "CAUGHT EXCEPTION in find_latest_ebs_backup. #{e}, retrying in #{seconds} seconds"
                  sleep(seconds)
                else
                  raise e
                end
              rescue Exception => e
                raise e
              end
            end
          end
        rescue Exception => e
          display_exception(e, "find_latest_ebs_backup(#{lineage}, #{from_master}, #{timestamp})")
          raise
        end

        def create_volume_from_snap(snap, nickname, sizegb, iops)
          params = {:nickname => nickname, :aws_id => snap}.merge @params
          params[:size] = sizegb if sizegb
          params[:aws_iops] = iops if iops
          @logger.info "Making a RightScale API call to create a new ebs volume from snapshot #{snap}"
          @logger.debug "HERE IS THE URL: #{@url}/create_ebs_volume_from_snap.js (PARAMS: #{params.inspect})"
          body = RestClient.post @url + "/create_ebs_volume_from_snap.js", params
          json = JSON.load(body)
          @logger.info "CREATED_VOLUME_FROM_SNAP: #{JSON::pretty_generate(json)}"
          json
        rescue Exception => e
          display_exception(e, "create_volume_from_snap(#{snap}, #{nickname}, #{sizegb})")
          raise
        end

        #
        # Backup functions
        #

        # Options: devices, suffix, description, tag, max_snapshots, prefix_override (if we want to use a prefix different than the volume name)
        def create_ebs_backup(options = {})
          time_suffix = "_" + Time.now.strftime("%Y%m%d%H%M")
          params = options.merge({ :commit => "explicit", :suffix => time_suffix }).merge @params
          @logger.info "Performing RightScale API call to create a new snapshot"
          @logger.info "PARAMS: #{params.inspect}"
          json = nil
          SystemTimer.timeout_after(@snapshot_timeout) do
            body = RestClient.post @url + "/create_ebs_backup.js", params
            json = body.nil? ? nil: JSON.load(body)
            @logger.info "CREATED_SNAPS: #{JSON::pretty_generate(json)}"
          end
          json
        rescue Exception => e
          display_exception(e, "create_ebs_backup(#{options.inspect})")
          raise
        end

        # Set EBS snapshot commit state: commit_state=[committed|uncommitted]
        def update_snapshot(aws_id,commit_state)
          params = {:aws_id => aws_id, :commit_state => commit_state}.merge @params
          json = nil
          SystemTimer.timeout_after(@snapshot_timeout) do
            body = RestClient.put @url + "/update_ebs_snapshot.js", params
            @logger.info "UPDATED SNAP: #{aws_id}"
          end
          json
        rescue Exception => e
          display_exception(e, "update_snapshot(#{aws_id}, #{commit_state})")
          raise
        end

        def cleanup_ebs_backups(prefix, options={})
          @logger.info "options: #{options.inspect}"
          raise "keep_last parameter is required" unless options[:keep_last]
          raise "dailies parameter is required" unless options[:dailies]
          raise "weeklies parameter is required" unless options[:weeklies]
          raise "monthlies parameter is required" unless options[:monthlies]
          raise "yearlies parameter is required" unless options[:yearlies]
          params = {:lineage => prefix, :api_version => 1.0}
          params.merge!(options)
          @logger.info "Making RightScale API call to clean old EBS snapshots"
          #@logger.info "HERE IS THE URL: #{@url}/cleanup_ebs_snapshots.js (PARAMS: #{params.inspect})"
          body = RestClient.put @url+"/cleanup_ebs_backups.js",params
          json = JSON.load(body)
          @logger.info "Snapshots deleted: #{JSON::pretty_generate(json)}" if json.length > 0
          json
        rescue Exception => e
          display_exception(e, "cleanup_ebs_backups #{prefix}, #{options.inspect}")
          raise
        end

        private

        def retry_call(seconds = 200, &block)
          caller[0] =~ /`(.*?)'/
          call = $1
          retry_seconds = 0
          result = nil
          while retry_seconds < seconds
            begin
              result = block.call
              break if result
            rescue Exception => e
              @logger.info "caught exception in #{call}: #{e}; retrying #{retry_seconds} of #{seconds} seconds"
            end

            retry_seconds += sleep 30
          end
          raise "timeout occurred waiting for #{call}" unless result

          result
        end

        # Convert the given parameters to a request string. The parameters may
        # be a string, +nil+, or a Hash.
        def requestify(parameters, prefix = nil)
          case parameters
          when Hash
            return nil if parameters.empty?
            parameters.map {|key, value| requestify(value, add_prefix(prefix, key))}.join('&')
          when Array
            parameters.map {|value| requestify(value, add_prefix(prefix, ''))}.join('&')
          else
            return "#{CGI.escape(prefix)}=#{CGI.escape(parameters.to_s)}" unless prefix.nil?
            parameters
          end
        end

        def add_prefix(prefix, name)
          prefix ? "#{prefix}[#{name}]" : name.to_s
        end
      end
    end
  end
end
