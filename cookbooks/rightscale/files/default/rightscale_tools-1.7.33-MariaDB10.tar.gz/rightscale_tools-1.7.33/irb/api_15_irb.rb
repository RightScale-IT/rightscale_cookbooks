#!/opt/rightscale/sandbox/bin/ruby
#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

# A quick way to login to the API and jump into IRB so you can experiment with the client.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', "lib"))

require 'rubygems'
require 'irb'
require 'rightscale_tools'
require '/var/spool/cloud/user-data.rb'

@api = RightScale::Tools::API.factory('1.5')
@client = @api.client

@api.logger.level = Logger::DEBUG

IRB.start
