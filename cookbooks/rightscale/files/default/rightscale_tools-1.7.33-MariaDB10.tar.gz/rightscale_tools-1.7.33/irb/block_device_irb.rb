#!/opt/rightscale/sandbox/bin/ruby
#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))

require 'rubygems'
require 'irb'
require 'rightscale_tools'
require 'trollop'
require '/var/spool/cloud/user-data.rb'

options = Trollop::options do
  opt :cloud, "Override the cloud", :type => :string
  opt :no_secondary, "Don't use secondary storage"
end

@cloud = options[:cloud] || IO.read('/etc/rightscale.d/cloud').chomp
@ohai = File.executable?('/usr/bin/rs_ohai') ? '/usr/bin/rs_ohai' : '/opt/rightscale/sandbox/bin/ohai'
@virtualization = Hash[JSON.load `#{@ohai} virtualization 2>/dev/null | grep -v '^[RU].*\.$'`]
@options = {
  :hypervisor => @virtualization['system'] || @virtualization['emulator'],
  :primary_storage_cloud => :cloudfiles,
  :primary_storage_key => ENV['RACKSPACE_USERNAME_TEST'],
  :primary_storage_secret => ENV['RACKSPACE_AUTH_KEY_TEST']
}
unless options[:no_secondary]
  @options.merge({
    :secondary_storage_cloud => :s3,
    :secondary_storage_key => ENV['AWS_ACCESS_KEY_ID_TEST'],
    :secondary_storage_secret => ENV['AWS_SECRET_ACCESS_KEY_TEST'],
    :secondary_storage_container => 'dtrefactor'
  })
end
@bd = RightScale::Tools::BlockDevice.factory(:lvm, @cloud, '/mnt/waffle', 'dtrefactor', @options)
@create_options = {
  :stripe_count => 1,
  :volume_size => 2,
  :vg_data_percentage => 60
}

@bd.logger.level = Logger::DEBUG

def create
  @bd.create(@create_options)
end

def snapshot
  @bd.snapshot(:primary, 'waffle', @create_options)
end

def reset
  @bd.reset
end

def populate
  File.open('/mnt/waffle/banana', 'wb') do |file|
    file.puts 'Hello!'
  end
end

def primary_backup
  @bd.primary_backup('waffle')
end

def secondary_backup
  @bd.secondary_backup('waffle')
end

def primary_restore
  @bd.primary_restore('waffle', @create_options)
end

def secondary_restore
  @bd.secondary_restore('waffle', @create_options)
end

IRB.start
