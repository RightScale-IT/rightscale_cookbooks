#!/opt/rightscale/sandbox/bin/ruby
#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

# A quick way to login to the API and jump into IRB so you can experiment with the client.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', "lib"))

require 'rubygems'
require 'irb'
require 'trollop'
require 'rightscale_tools'

options = Trollop::options do
  opt :storage_cloud, "ROS Storage Cloud", :required => true, :type => String
  opt :endpoint, "ROS Endpoint", :type => String
end

module RightScale::Tools::Common
  @@logger = Logger.new(STDERR)
  @@logger.level = Logger::DEBUG
end

@ros = RightScale::Tools::ROS.factory(options[:storage_cloud], ENV['STORAGE_KEY'], ENV['STORAGE_SECRET'], :endpoint => options[:endpoint])
@ros_ros = @ros.instance_variable_get('@ros')

IRB.start
