#!/opt/rightscale/sandbox/bin/ruby
#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))

require 'rubygems'
require 'irb'
require 'rightscale_tools'
require '/var/spool/cloud/user-data.rb'

@cloud = IO.read('/etc/rightscale.d/cloud').chomp
@ohai = File.executable?('/usr/bin/rs_ohai') ? '/usr/bin/rs_ohai' : '/opt/rightscale/sandbox/bin/ohai'
@virtualization = Hash[JSON.load `#{@ohai} virtualization 2>/dev/null`]
@options = {
  :hypervisor => @virtualization['system'] || @virtualization['emulator'],
  :primary_storage_cloud => :cloudfiles,
  :primary_storage_key => ENV['RACKSPACE_USERNAME_TEST'],
  :primary_storage_secret => ENV['RACKSPACE_AUTH_KEY_TEST'],
}
@bd = [
  RightScale::Tools::BlockDevice.factory(:lvm, @cloud, '/mnt/waffle', 'multiblock1', @options),
  RightScale::Tools::BlockDevice.factory(:lvm, @cloud, '/mnt/pancake', 'multiblock2', @options)
]
@create_options = {
  :stripe_count => 1,
  :volume_size => 2,
  :vg_data_percentage => 60
}

def create
  @bd.each {|bd| bd.create(@create_options)}
end

def snapshot
  @bd.each {|bd| bd.snapshot(:primary, "multiblock_lineage_#{index}")}
end

def reset
  @bd.each {|bd| bd.reset}
end

def populate
  ['waffle', 'pancake'].each do |name|
    File.open("/mnt/#{name}/banana", 'wb') do |file|
      file.puts "Hello #{name}!"
    end
  end
end

def backup
  @bd.each_with_index {|bd, index| bd.primary_backup("multiblock_lineage_#{index}")}
end

def restore
  @bd.each_with_index {|bd, index| bd.primary_restore("multiblock_lineage_#{index}", @create_options)}
end

IRB.start
