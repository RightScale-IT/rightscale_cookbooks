# RightScale Tools Gem

## DESCRIPTION

The RightScale Tools Gem provides scripts and libraries for dealing with remote
object stores such as S3 and CloudFiles, block device volume management
including EBS and volumes on CloudStack and Eucalyptus, and database management
for MySQL.

## REQUIREMENTS

* json
* trollop
* right_aws
* right_rackspace
* right_api_client
* rest-client
* system_timer

## LICENSE

Copyright RightScale, Inc. All rights reserved.
All access and use subject to the RightScale Terms of Service available at
http://www.rightscale.com/terms.php and, if applicable, other agreements
such as a RightScale Master Subscription Agreement.

Maintained by the RightScale White Team
