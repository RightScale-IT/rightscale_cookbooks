#!/opt/rightscale/sandbox/bin/ruby
#
# RightScale Tools
#
# Copyright RightScale, Inc. All rights reserved.
# All access and use subject to the RightScale Terms of Service available at
# http://www.rightscale.com/terms.php and, if applicable, other agreements
# such as a RightScale Master Subscription Agreement.

$LOAD_PATH.unshift(File.join(File.dirname(__FILE__), '..', 'lib'))

require "rubygems"
require "right_popen"
require "rightscale_tools"
require "/var/spool/cloud/user-data.rb"
require 'fileutils'

lineage = "rspeclineage555"
mount_point = "/mnt/storage"
handle = RightScale::Tools::BlockDevice.factory(:lvm, :cloudstack, mount_point, "rspec_test")

# reset state to pristine
# unmount, detach, delete any volumes
#handle.action_reset

options = {
  :max_snapshots => 1,
  :keep_dailies => 1,
  :keep_weeklies => 1,
  :keep_monthlies => 1,
  :keep_yearlies => 1
}

# Create, backup, reset, restore
puts "Performing create..."
handle.create({ :volume_size => 1, :stripe_count => 2 })
FileUtils.touch("#{mount_point}/testfile")
puts "Performing primary backup..."
handle.snapshot(:primary, lineage, options)
handle.backup_primary(lineage, options)
sleep 60
puts "Performing reset..."
handle.action_reset
sleep 5
puts `ls #{mount_point}`
raise "ERROR: file should not exist!" if File.exists?("#{mount_point}/testfile")
puts "Performing restore..."
handle.primary_restore(lineage)
raise "ERROR: file should exist!" unless File.exists?("#{mount_point}/testfile")
puts "PASS!"
